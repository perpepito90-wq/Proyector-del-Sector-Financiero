namespace SistemaBancarioCore.Models
{
    /// <summary>
    /// Cliente registrado para el cumplimiento KYC (Conoce a tu Cliente). Guarda la
    /// identidad, el país, si es persona expuesta políticamente (PEP), el nivel de
    /// riesgo calculado y el estado de verificación.
    /// </summary>
    public class Cliente
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = null!;
        public string TipoDocumento { get; set; } = null!;   // CC / CE / Pasaporte
        public string Documento { get; set; } = null!;
        public string Pais { get; set; } = null!;
        public bool EsPEP { get; set; }                        // persona expuesta políticamente
        public string NivelRiesgo { get; set; } = "Bajo";      // Bajo / Medio / Alto
        public string EstadoKYC { get; set; } = "Pendiente";   // Pendiente / Verificado / Rechazado
        public DateTime FechaRegistro { get; set; }
    }
}
