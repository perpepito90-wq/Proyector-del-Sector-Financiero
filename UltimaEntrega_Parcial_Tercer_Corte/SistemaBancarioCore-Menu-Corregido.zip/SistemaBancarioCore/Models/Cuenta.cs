using System.ComponentModel.DataAnnotations.Schema;

namespace SistemaBancarioCore.Models
{
    /// <summary>
    /// Cuenta bancaria persistida en base de datos. Representa el objetivo de
    /// "gestión de cuentas" del proyecto.
    /// </summary>
    public class Cuenta
    {
        public int Id { get; set; }
        public string Numero { get; set; } = null!;
        public string Titular { get; set; } = null!;
        public string Tipo { get; set; } = null!;          // Ahorros / Corriente
        [Column(TypeName = "decimal(18,2)")]
        public decimal Saldo { get; set; }
        public string Estado { get; set; } = "Activa";      // Activa / Bloqueada / Cerrada
        public DateTime FechaApertura { get; set; }
    }
}
