using System.ComponentModel.DataAnnotations.Schema;

namespace SistemaBancarioCore.Models
{
    /// <summary>
    /// Transacción (movimiento) persistida de una cuenta. Representa el objetivo de
    /// "gestión de transacciones". Se relaciona con la cuenta por CuentaId.
    /// </summary>
    public class MovimientoBancario
    {
        public int Id { get; set; }
        public int CuentaId { get; set; }
        public DateTime Fecha { get; set; }
        public string Tipo { get; set; } = null!;           // Depósito / Retiro / Transferencia
        public string Descripcion { get; set; } = null!;
        [Column(TypeName = "decimal(18,2)")]
        public decimal Monto { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal SaldoResultante { get; set; }
    }
}
