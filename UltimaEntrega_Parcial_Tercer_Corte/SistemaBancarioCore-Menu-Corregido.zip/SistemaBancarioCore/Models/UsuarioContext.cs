﻿using Microsoft.EntityFrameworkCore;

namespace SistemaBancarioCore.Models
{
    public class UsuarioContext : DbContext
    {
        public UsuarioContext(DbContextOptions<UsuarioContext> options) : base(options)
        {
        }

        public DbSet<Usuario> Usuarios { get; set; }

        // Semana 4 - tabla de configuracion SMTP (para el envio de correos).
        public DbSet<ConfiguracionCorreo> ConfiguracionesCorreo { get; set; }

        // Persistencia del core bancario: cuentas, transacciones, prestamos e inversiones.
        public DbSet<Cuenta> Cuentas { get; set; }
        public DbSet<MovimientoBancario> Movimientos { get; set; }
        public DbSet<PrestamoBancario> Prestamos { get; set; }
        public DbSet<Inversion> Inversiones { get; set; }

        // Etapa 2 - deteccion de fraude: alertas generadas por el motor antifraude.
        public DbSet<AlertaFraude> AlertasFraude { get; set; }

        // Etapa 3 - cumplimiento KYC: registro de clientes verificados.
        public DbSet<Cliente> Clientes { get; set; }
    }
}
