using System.ComponentModel.DataAnnotations.Schema;

namespace SistemaBancarioCore.Models
{
    /// <summary>
    /// Alerta generada por el motor antifraude al evaluar una transacción. Se persiste
    /// como evidencia para el cumplimiento (AML) y el monitoreo.
    /// </summary>
    public class AlertaFraude
    {
        public int Id { get; set; }
        public int CuentaId { get; set; }
        public string CuentaNumero { get; set; } = null!;
        public DateTime Fecha { get; set; }
        public string Tipo { get; set; } = null!;          // Depósito / Retiro / Transferencia
        [Column(TypeName = "decimal(18,2)")]
        public decimal Monto { get; set; }
        public int Puntaje { get; set; }                    // riesgo acumulado por la cadena de reglas
        public string Decision { get; set; } = null!;       // Aprobada / Revisar / Bloqueada
        public string Motivos { get; set; } = null!;        // reglas que se dispararon
        public string Estado { get; set; } = "Pendiente";   // Pendiente / Revisada
    }
}
