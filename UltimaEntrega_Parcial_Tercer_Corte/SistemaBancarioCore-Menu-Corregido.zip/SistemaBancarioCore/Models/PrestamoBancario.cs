using System.ComponentModel.DataAnnotations.Schema;

namespace SistemaBancarioCore.Models
{
    /// <summary>
    /// Préstamo persistido en base de datos. Representa el objetivo de
    /// "gestión de préstamos".
    /// </summary>
    public class PrestamoBancario
    {
        public int Id { get; set; }
        public string Numero { get; set; } = null!;
        public string Titular { get; set; } = null!;
        [Column(TypeName = "decimal(18,2)")]
        public decimal Monto { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal TasaMensual { get; set; }
        public int PlazoMeses { get; set; }
        public string Estado { get; set; } = "Radicada";   // ciclo de vida de la solicitud
        public DateTime FechaSolicitud { get; set; }
    }
}
