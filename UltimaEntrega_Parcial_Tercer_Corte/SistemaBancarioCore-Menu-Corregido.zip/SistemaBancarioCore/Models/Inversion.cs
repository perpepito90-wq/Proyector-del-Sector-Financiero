using System.ComponentModel.DataAnnotations.Schema;

namespace SistemaBancarioCore.Models
{
    /// <summary>
    /// Inversión (CDT) persistida en base de datos. Representa el objetivo de
    /// "gestión de inversiones".
    /// </summary>
    public class Inversion
    {
        public int Id { get; set; }
        public string Numero { get; set; } = null!;
        public string Titular { get; set; } = null!;
        [Column(TypeName = "decimal(18,2)")]
        public decimal Monto { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal TasaAnual { get; set; }
        public int PlazoMeses { get; set; }
        public DateTime FechaApertura { get; set; }
    }
}
