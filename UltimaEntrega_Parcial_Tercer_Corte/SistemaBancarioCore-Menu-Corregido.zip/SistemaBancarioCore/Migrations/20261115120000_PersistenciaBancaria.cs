using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SistemaBancarioCore.Migrations
{
    /// <inheritdoc />
    public partial class PersistenciaBancaria : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cuentas",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Numero = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Titular = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Tipo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Saldo = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Estado = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FechaApertura = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cuentas", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Movimientos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CuentaId = table.Column<int>(type: "int", nullable: false),
                    Fecha = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Tipo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Descripcion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Monto = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    SaldoResultante = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Movimientos", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Prestamos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Numero = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Titular = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Monto = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    TasaMensual = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    PlazoMeses = table.Column<int>(type: "int", nullable: false),
                    Estado = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FechaSolicitud = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Prestamos", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Inversiones",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Numero = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Titular = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Monto = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    TasaAnual = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    PlazoMeses = table.Column<int>(type: "int", nullable: false),
                    FechaApertura = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Inversiones", x => x.Id);
                });

            // ---- Datos de ejemplo (para que las pantallas muestren informacion desde el inicio) ----
            migrationBuilder.InsertData(
                table: "Cuentas",
                columns: new[] { "Id", "Numero", "Titular", "Tipo", "Saldo", "Estado", "FechaApertura" },
                values: new object[,]
                {
                    { 1, "AHO-0001", "Ana Pérez", "Ahorros", 3650000m, "Activa", new DateTime(2026, 10, 15) },
                    { 2, "COR-0002", "Carlos Ruiz", "Corriente", 1200000m, "Activa", new DateTime(2026, 10, 20) },
                    { 3, "AHO-0003", "Lucía Gómez", "Ahorros", 500000m, "Activa", new DateTime(2026, 11, 2) }
                });

            migrationBuilder.InsertData(
                table: "Movimientos",
                columns: new[] { "CuentaId", "Fecha", "Tipo", "Descripcion", "Monto", "SaldoResultante" },
                values: new object[,]
                {
                    { 1, new DateTime(2026, 11, 1), "Depósito", "Depósito en efectivo", 2000000m, 2000000m },
                    { 1, new DateTime(2026, 11, 3), "Depósito", "Transferencia recibida", 2000000m, 4000000m },
                    { 1, new DateTime(2026, 11, 5), "Retiro", "Retiro en cajero", 350000m, 3650000m },
                    { 2, new DateTime(2026, 11, 2), "Depósito", "Depósito inicial", 1500000m, 1500000m },
                    { 2, new DateTime(2026, 11, 6), "Retiro", "Pago de servicios", 300000m, 1200000m },
                    { 3, new DateTime(2026, 11, 2), "Depósito", "Apertura de cuenta", 500000m, 500000m }
                });

            migrationBuilder.InsertData(
                table: "Prestamos",
                columns: new[] { "Numero", "Titular", "Monto", "TasaMensual", "PlazoMeses", "Estado", "FechaSolicitud" },
                values: new object[,]
                {
                    { "PRE-0001", "Ana Pérez", 8000000m, 1.8m, 12, "Aprobada", new DateTime(2026, 10, 20) },
                    { "PRE-0002", "Carlos Ruiz", 4000000m, 2.0m, 6, "En revisión", new DateTime(2026, 11, 10) }
                });

            migrationBuilder.InsertData(
                table: "Inversiones",
                columns: new[] { "Numero", "Titular", "Monto", "TasaAnual", "PlazoMeses", "FechaApertura" },
                values: new object[] { "CDT-0001", "Lucía Gómez", 10000000m, 8.0m, 12, new DateTime(2026, 9, 15) });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(name: "Cuentas");
            migrationBuilder.DropTable(name: "Movimientos");
            migrationBuilder.DropTable(name: "Prestamos");
            migrationBuilder.DropTable(name: "Inversiones");
        }
    }
}
