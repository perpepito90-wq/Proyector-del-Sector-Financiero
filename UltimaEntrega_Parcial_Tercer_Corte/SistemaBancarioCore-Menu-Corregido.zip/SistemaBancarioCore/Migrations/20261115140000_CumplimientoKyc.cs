using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SistemaBancarioCore.Migrations
{
    /// <inheritdoc />
    public partial class CumplimientoKyc : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Clientes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TipoDocumento = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Documento = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Pais = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EsPEP = table.Column<bool>(type: "bit", nullable: false),
                    NivelRiesgo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EstadoKYC = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FechaRegistro = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clientes", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Clientes",
                columns: new[] { "Nombre", "TipoDocumento", "Documento", "Pais", "EsPEP", "NivelRiesgo", "EstadoKYC", "FechaRegistro" },
                values: new object[,]
                {
                    { "Ana Pérez", "CC", "123456789", "Colombia", false, "Bajo", "Verificado", new DateTime(2026, 10, 15) },
                    { "Carlos Ruiz", "CE", "987654321", "Colombia", true, "Alto", "Pendiente", new DateTime(2026, 10, 20) },
                    { "Lucía Gómez", "Pasaporte", "P00112233", "México", false, "Bajo", "Verificado", new DateTime(2026, 11, 2) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(name: "Clientes");
        }
    }
}
