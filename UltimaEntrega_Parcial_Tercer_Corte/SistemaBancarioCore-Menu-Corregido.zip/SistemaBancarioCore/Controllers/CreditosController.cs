using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Creditos;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Solicitudes de crédito. Demuestra el patrón State: la solicitud cambia su
    /// comportamiento según su estado (Radicada, En revisión, Aprobada, Rechazada,
    /// Desembolsada). Cada estado decide qué transiciones son válidas, sin switch.
    /// </summary>
    [Authorize]
    public class CreditosController : Controller
    {
        private readonly ServicioCreditos _servicio = new ServicioCreditos();

        public IActionResult Index()
        {
            ViewData["resultado"] = _servicio.Estado();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Accion(string accion)
        {
            ViewData["resultado"] = _servicio.Accion(accion ?? string.Empty);
            return View("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Reiniciar()
        {
            ViewData["resultado"] = _servicio.Reiniciar();
            return View("Index");
        }
    }
}
