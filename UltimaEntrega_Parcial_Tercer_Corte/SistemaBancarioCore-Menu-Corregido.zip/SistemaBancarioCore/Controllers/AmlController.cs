using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Cumplimiento;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Cumplimiento AML (Antilavado de Activos): monitoreo de operaciones de alto
    /// valor y consolidación de las alertas de fraude, con un tablero de resumen.
    /// </summary>
    [Authorize]
    public class AmlController : Controller
    {
        private readonly ServicioCumplimiento _svc;
        public AmlController(ServicioCumplimiento svc) => _svc = svc;

        public IActionResult Index()
        {
            ViewData["resumen"] = _svc.Resumen();
            ViewData["operaciones"] = _svc.OperacionesAltoValor();
            ViewData["alertas"] = _svc.Alertas();
            return View();
        }
    }
}
