using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Atencion;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Mesa de atención al cliente. Demuestra el patrón Mediator: cliente, asesor y
    /// supervisor se comunican a través de una sala (el mediador) que decide el
    /// enrutamiento de cada mensaje, sin que los participantes se conozcan entre sí.
    /// </summary>
    [Authorize]
    public class AtencionController : Controller
    {
        private readonly ServicioAtencion _servicio = new ServicioAtencion();

        public IActionResult Index()
        {
            ViewData["resultado"] = _servicio.Simular("Cliente", string.Empty);
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Enviar(string rol, string texto)
        {
            ViewData["resultado"] = _servicio.Simular(string.IsNullOrWhiteSpace(rol) ? "Cliente" : rol, texto);
            ViewData["rol"] = rol;
            return View("Index");
        }
    }
}
