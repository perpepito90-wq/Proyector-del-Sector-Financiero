using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Banca;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Gestión de cuentas y transacciones con persistencia real en base de datos.
    /// </summary>
    [Authorize]
    public class CuentasBancoController : Controller
    {
        private readonly ServicioBanca _svc;
        public CuentasBancoController(ServicioBanca svc) => _svc = svc;

        public IActionResult Index()
        {
            ViewData["cuentas"] = _svc.Cuentas();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AbrirCuenta(string titular, string tipo, decimal montoInicial)
        {
            var cuenta = _svc.AbrirCuenta(titular, tipo ?? "Ahorros", montoInicial);
            TempData["aviso"] = $"Cuenta {cuenta.Numero} abierta y guardada en la base de datos.";
            return RedirectToAction("Index");
        }

        public IActionResult Movimientos(int id)
        {
            var cuenta = _svc.Cuenta(id);
            if (cuenta == null) return RedirectToAction("Index");
            ViewData["cuenta"] = cuenta;
            ViewData["movimientos"] = _svc.Movimientos(id);
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult RegistrarMovimiento(int cuentaId, string tipo, decimal monto, string? descripcion)
        {
            var (ok, mensaje) = _svc.RegistrarMovimiento(cuentaId, tipo ?? "Depósito", monto, descripcion);
            TempData["aviso"] = mensaje;
            TempData["avisoOk"] = ok;
            return RedirectToAction("Movimientos", new { id = cuentaId });
        }
    }
}
