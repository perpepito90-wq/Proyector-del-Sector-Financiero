using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Cumplimiento;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Cumplimiento KYC (Conoce a tu Cliente): registro de clientes con verificación
    /// de identidad y cálculo del nivel de riesgo (país, PEP, documento).
    /// </summary>
    [Authorize]
    public class KycController : Controller
    {
        private readonly ServicioCumplimiento _svc;
        public KycController(ServicioCumplimiento svc) => _svc = svc;

        public IActionResult Index()
        {
            ViewData["clientes"] = _svc.Clientes();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult RegistrarCliente(string nombre, string tipoDocumento, string documento, string pais, bool esPEP)
        {
            var c = _svc.RegistrarCliente(nombre, tipoDocumento ?? "CC", documento, pais, esPEP);
            TempData["aviso"] = $"Cliente {c.Nombre} registrado. Riesgo {c.NivelRiesgo}, estado KYC: {c.EstadoKYC}.";
            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Verificar(int id)
        {
            _svc.Verificar(id);
            TempData["aviso"] = "Cliente verificado.";
            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Rechazar(int id)
        {
            _svc.Rechazar(id);
            TempData["aviso"] = "Cliente rechazado.";
            return RedirectToAction("Index");
        }
    }
}
