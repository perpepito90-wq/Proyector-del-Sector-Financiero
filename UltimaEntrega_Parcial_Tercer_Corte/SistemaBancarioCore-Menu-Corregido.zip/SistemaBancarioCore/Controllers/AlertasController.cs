using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Alertas;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Alertas de cuenta. Demuestra el patrón Observer: una cuenta (sujeto) notifica
    /// automáticamente a varios observadores (notificación, auditoría y monitor de
    /// saldo) cada vez que cambia su saldo, sin conocer las clases concretas.
    /// </summary>
    [Authorize]
    public class AlertasController : Controller
    {
        private readonly ServicioAlertas _servicio = new ServicioAlertas();

        public IActionResult Index()
        {
            ViewData["resultado"] = _servicio.Estado();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Ejecutar(string tipo, decimal monto)
        {
            ViewData["resultado"] = _servicio.Ejecutar(tipo ?? "Deposito", monto);
            ViewData["tipo"] = tipo;
            return View("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Reiniciar()
        {
            ViewData["resultado"] = _servicio.Reiniciar();
            return View("Index");
        }
    }
}
