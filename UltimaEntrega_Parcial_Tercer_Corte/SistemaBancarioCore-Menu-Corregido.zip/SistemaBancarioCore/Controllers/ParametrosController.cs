using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Parametros;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Parámetros operativos del sistema. Demuestra el patrón Memento: se pueden
    /// guardar "puntos de restauración" del estado de la configuración y volver a
    /// cualquiera de ellos (deshacer), sin exponer la estructura interna del estado.
    /// </summary>
    [Authorize]
    public class ParametrosController : Controller
    {
        private readonly ServicioParametros _servicio = new ServicioParametros();

        public IActionResult Index()
        {
            ViewData["resultado"] = _servicio.Estado();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Aplicar(decimal limiteDiario, decimal montoMaximo,
            decimal tasaBase, bool modoMantenimiento, string? etiqueta)
        {
            ViewData["resultado"] = _servicio.Aplicar(
                limiteDiario, montoMaximo, tasaBase, modoMantenimiento, etiqueta);
            return View("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Restaurar(int indice)
        {
            ViewData["resultado"] = _servicio.Restaurar(indice);
            return View("Index");
        }
    }
}
