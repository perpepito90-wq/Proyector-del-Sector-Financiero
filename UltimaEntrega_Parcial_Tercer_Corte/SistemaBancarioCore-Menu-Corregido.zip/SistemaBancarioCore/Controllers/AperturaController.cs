using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Apertura;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Apertura de productos. Demuestra el patrón Template Method: el proceso de
    /// apertura sigue siempre el mismo esqueleto (validar, crear, auditar, notificar)
    /// y solo cambian los pasos específicos según el producto (ahorros, CDT, préstamo).
    /// </summary>
    [Authorize]
    public class AperturaController : Controller
    {
        private readonly ServicioApertura _servicio = new ServicioApertura();

        public IActionResult Index()
        {
            ViewData["esqueleto"] = _servicio.Esqueleto;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Ejecutar(string tipo, string nombre, string documento, decimal montoInicial, int plazoMeses)
        {
            var datos = new SolicitudApertura
            {
                Nombre = nombre ?? string.Empty,
                Documento = documento ?? string.Empty,
                MontoInicial = montoInicial,
                PlazoMeses = plazoMeses
            };
            ViewData["esqueleto"] = _servicio.Esqueleto;
            ViewData["resultado"] = _servicio.Abrir(tipo ?? "Ahorros", datos);
            ViewData["tipo"] = tipo;
            return View("Index");
        }
    }
}
