using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Banca;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>Gestión de inversiones (CDT) con persistencia real en base de datos.</summary>
    [Authorize]
    public class InversionesBancoController : Controller
    {
        private readonly ServicioBanca _svc;
        public InversionesBancoController(ServicioBanca svc) => _svc = svc;

        public IActionResult Index()
        {
            ViewData["inversiones"] = _svc.Inversiones();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Crear(string titular, decimal monto, decimal tasaAnual, int plazoMeses)
        {
            var i = _svc.CrearInversion(titular, monto, tasaAnual, plazoMeses);
            TempData["aviso"] = $"Inversión {i.Numero} abierta y guardada en la base de datos.";
            return RedirectToAction("Index");
        }
    }
}
