using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Amortizacion;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Simulador de crédito. Demuestra el patrón Strategy: el mismo simulador calcula
    /// el plan de pagos con distintos métodos de amortización (francés, alemán,
    /// interés global) intercambiables en tiempo de ejecución, sin condicionales.
    /// </summary>
    [Authorize]
    public class AmortizacionController : Controller
    {
        private readonly ServicioAmortizacion _servicio = new ServicioAmortizacion();

        public IActionResult Index()
        {
            ViewData["resultado"] = _servicio.Simular("Frances", 6_000_000m, 1.5m, 6);
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Simular(string estrategia, decimal monto, decimal tasaMensual, int plazoMeses)
        {
            ViewData["resultado"] = _servicio.Simular(estrategia ?? "Frances", monto, tasaMensual, plazoMeses);
            return View("Index");
        }
    }
}
