using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Certificaciones;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Emisión de certificaciones bancarias. Demuestra el patrón Proxy: el
    /// controlador usa la interfaz ICertificacionService sin saber que detrás hay
    /// un CertificacionProxy que controla el acceso por rol (Protection), cachea el
    /// resultado (Caching) y crea el servicio real solo cuando se necesita (Virtual).
    /// </summary>
    [Authorize]
    public class CertificacionesController : Controller
    {
        // Estático: un único proxy para que el caché y el objeto real (lazy) persistan.
        private static readonly ICertificacionService _servicio = new CertificacionProxy();

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Emitir(string numeroCuenta, string titular, string tipo, string rol, bool esPropia)
        {
            var solicitud = new SolicitudCertificacion
            {
                NumeroCuenta = string.IsNullOrWhiteSpace(numeroCuenta) ? "CTA-1000" : numeroCuenta,
                Titular = string.IsNullOrWhiteSpace(titular) ? "Titular de la cuenta" : titular,
                Tipo = string.IsNullOrWhiteSpace(tipo) ? "Certificación de cuenta" : tipo,
                Usuario = User?.Identity?.Name ?? string.Empty,
                Rol = string.IsNullOrWhiteSpace(rol) ? "CLIENTE" : rol,
                EsPropia = esPropia
            };

            ViewData["resultado"] = _servicio.Emitir(solicitud);
            ViewData["solicitud"] = solicitud;
            return View("Index");
        }
    }
}
