using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Banca;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>Gestión de préstamos con persistencia real en base de datos.</summary>
    [Authorize]
    public class PrestamosBancoController : Controller
    {
        private readonly ServicioBanca _svc;
        public PrestamosBancoController(ServicioBanca svc) => _svc = svc;

        public IActionResult Index()
        {
            ViewData["prestamos"] = _svc.Prestamos();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Crear(string titular, decimal monto, decimal tasaMensual, int plazoMeses)
        {
            var p = _svc.CrearPrestamo(titular, monto, tasaMensual, plazoMeses);
            TempData["aviso"] = $"Préstamo {p.Numero} radicado y guardado en la base de datos.";
            return RedirectToAction("Index");
        }
    }
}
