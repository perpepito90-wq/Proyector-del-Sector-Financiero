using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Caja;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Ventanilla de caja. Demuestra el patrón Command: cada operación (depósito,
    /// retiro, transferencia) se encapsula como un comando con Ejecutar/Deshacer, lo
    /// que permite registrarla, encolarla y revertir la última ejecutada.
    /// </summary>
    [Authorize]
    public class CajaController : Controller
    {
        private readonly ServicioCaja _servicio = new ServicioCaja();

        public IActionResult Index()
        {
            ViewData["resultado"] = _servicio.Estado();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Enviar(string tipo, decimal monto, string modo, string? beneficiario)
        {
            ViewData["resultado"] = _servicio.Enviar(tipo ?? "Deposito", monto, modo ?? "Ejecutar", beneficiario);
            ViewData["tipo"] = tipo;
            ViewData["modo"] = modo;
            return View("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Procesar()
        {
            ViewData["resultado"] = _servicio.Procesar();
            return View("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Deshacer()
        {
            ViewData["resultado"] = _servicio.Deshacer();
            return View("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Reiniciar()
        {
            ViewData["resultado"] = _servicio.Reiniciar();
            return View("Index");
        }
    }
}
