using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Movimientos;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Extracto de movimientos de una cuenta. Demuestra el patrón Iterator: el
    /// controlador recorre el historial con un iterador y puede cambiar el orden
    /// del recorrido (cronológico, por monto, solo créditos, solo débitos) sin
    /// conocer cómo está almacenada la colección.
    /// </summary>
    [Authorize]
    public class MovimientosController : Controller
    {
        private readonly ServicioMovimientos _servicio = new ServicioMovimientos();

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Ver(string numeroCuenta, string criterio)
        {
            numeroCuenta = string.IsNullOrWhiteSpace(numeroCuenta) ? "CTA-1000" : numeroCuenta;
            criterio = string.IsNullOrWhiteSpace(criterio) ? "cronologico" : criterio;

            IHistorialMovimientos historial = _servicio.ObtenerHistorial(numeroCuenta);

            ViewData["movs"] = _servicio.Recorrer(historial, criterio);
            ViewData["numeroCuenta"] = numeroCuenta;
            ViewData["criterio"] = criterio;
            ViewData["total"] = historial.Cantidad;
            return View("Index");
        }
    }
}
