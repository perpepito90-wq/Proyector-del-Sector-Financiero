using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Cuentas;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Cartera de cuentas. Demuestra el patrón Flyweight: miles de cuentas comparten
    /// unos pocos objetos TipoProducto (estado intrínseco) a través del catálogo
    /// (Flyweight Factory), en lugar de duplicar esos datos en cada cuenta.
    /// </summary>
    [Authorize]
    public class CarteraController : Controller
    {
        private readonly ServicioCartera _servicio = new ServicioCartera();

        public IActionResult Index()
        {
            ViewData["catalogo"] = CatalogoProductos.Catalogo();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Generar(int cantidad)
        {
            ViewData["catalogo"] = CatalogoProductos.Catalogo();
            ViewData["resultado"] = _servicio.GenerarCartera(cantidad);
            return View("Index");
        }
    }
}
