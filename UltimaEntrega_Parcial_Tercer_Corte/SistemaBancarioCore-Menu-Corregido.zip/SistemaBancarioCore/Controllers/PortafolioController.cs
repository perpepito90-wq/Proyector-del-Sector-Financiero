using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Portafolio;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Portafolio del cliente. Demuestra el patrón Visitor: sobre la misma colección
    /// de productos (ahorros, corriente, CDT, préstamo) se aplican distintas
    /// operaciones (resumen, rendimiento, patrimonio) sin modificar las clases de
    /// los productos; cada operación es un visitante.
    /// </summary>
    [Authorize]
    public class PortafolioController : Controller
    {
        private readonly ServicioPortafolio _servicio = new ServicioPortafolio();

        public IActionResult Index()
        {
            ViewData["resultado"] = _servicio.Ejecutar("Resumen");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Ejecutar(string visitante)
        {
            ViewData["resultado"] = _servicio.Ejecutar(visitante ?? "Resumen");
            return View("Index");
        }
    }
}
