namespace SistemaBancarioCore.Services.Portafolio
{
    /// <summary>
    /// VISITOR concreto: genera un resumen descriptivo de cada producto. Cada
    /// sobrecarga sabe qué datos mostrar según el tipo.
    /// </summary>
    public class VisitanteResumen : IVisitanteProducto
    {
        private readonly List<string> _lineas = new List<string>();
        public string Nombre => "Resumen del portafolio";
        public IReadOnlyList<string> Lineas => _lineas;
        public string Resumen => $"{_lineas.Count} producto(s) en el portafolio.";

        public void Visitar(CuentaAhorros c) =>
            _lineas.Add($"Cuenta de ahorros {c.Numero} de {c.Titular} — saldo {c.Saldo:N0} (tasa {c.TasaAnual:0.0}%).");
        public void Visitar(CuentaCorriente c) =>
            _lineas.Add($"Cuenta corriente {c.Numero} de {c.Titular} — saldo {c.Saldo:N0} (cupo sobregiro {c.CupoSobregiro:N0}).");
        public void Visitar(Cdt c) =>
            _lineas.Add($"CDT {c.Numero} de {c.Titular} — monto {c.Saldo:N0} a {c.PlazoMeses} meses (tasa {c.TasaAnual:0.0}%).");
        public void Visitar(Prestamo p) =>
            _lineas.Add($"Préstamo {p.Numero} de {p.Titular} — saldo pendiente {p.Saldo:N0} (tasa {p.TasaAnual:0.0}%).");
    }

    /// <summary>
    /// VISITOR concreto: calcula el rendimiento anual estimado para el cliente. Los
    /// activos rinden intereses; el préstamo representa un costo.
    /// </summary>
    public class VisitanteRendimiento : IVisitanteProducto
    {
        private readonly List<string> _lineas = new List<string>();
        private decimal _neto = 0m;
        public string Nombre => "Rendimiento anual estimado";
        public IReadOnlyList<string> Lineas => _lineas;
        public string Resumen => $"Rendimiento neto anual estimado del cliente: {_neto:N0}.";

        public void Visitar(CuentaAhorros c)
        {
            var interes = c.Saldo * c.TasaAnual / 100m;
            _neto += interes;
            _lineas.Add($"Ahorros {c.Numero}: + {interes:N0} de intereses.");
        }
        public void Visitar(CuentaCorriente c) =>
            _lineas.Add($"Corriente {c.Numero}: sin rendimiento.");
        public void Visitar(Cdt c)
        {
            var interes = c.Saldo * c.TasaAnual / 100m * c.PlazoMeses / 12m;
            _neto += interes;
            _lineas.Add($"CDT {c.Numero}: + {interes:N0} al vencimiento ({c.PlazoMeses} meses).");
        }
        public void Visitar(Prestamo p)
        {
            var costo = p.Saldo * p.TasaAnual / 100m;
            _neto -= costo;
            _lineas.Add($"Préstamo {p.Numero}: − {costo:N0} de intereses que paga el cliente.");
        }
    }

    /// <summary>
    /// VISITOR concreto: calcula estadísticas de patrimonio. Suma activos y pasivos
    /// según el tipo de producto y obtiene el patrimonio neto.
    /// </summary>
    public class VisitantePatrimonio : IVisitanteProducto
    {
        private readonly List<string> _lineas = new List<string>();
        private decimal _activos = 0m;
        private decimal _pasivos = 0m;
        public string Nombre => "Patrimonio del cliente";
        public IReadOnlyList<string> Lineas => _lineas;
        public string Resumen =>
            $"Activos {_activos:N0} − Pasivos {_pasivos:N0} = Patrimonio neto {_activos - _pasivos:N0}.";

        private void Activo(string etiqueta, decimal monto)
        {
            _activos += monto;
            _lineas.Add($"{etiqueta}: + {monto:N0} (activo).");
        }
        public void Visitar(CuentaAhorros c) => Activo($"Ahorros {c.Numero}", c.Saldo);
        public void Visitar(CuentaCorriente c) => Activo($"Corriente {c.Numero}", c.Saldo);
        public void Visitar(Cdt c) => Activo($"CDT {c.Numero}", c.Saldo);
        public void Visitar(Prestamo p)
        {
            _pasivos += p.Saldo;
            _lineas.Add($"Préstamo {p.Numero}: − {p.Saldo:N0} (pasivo).");
        }
    }
}
