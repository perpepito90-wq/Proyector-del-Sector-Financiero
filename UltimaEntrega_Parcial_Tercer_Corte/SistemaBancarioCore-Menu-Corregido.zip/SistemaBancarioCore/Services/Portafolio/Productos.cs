namespace SistemaBancarioCore.Services.Portafolio
{
    /// <summary>ELEMENT concreto: cuenta de ahorros.</summary>
    public class CuentaAhorros : IProductoFinanciero
    {
        public string Tipo => "Cuenta de ahorros";
        public string Numero { get; }
        public string Titular { get; }
        public decimal Saldo { get; }
        public decimal TasaAnual { get; }

        public CuentaAhorros(string numero, string titular, decimal saldo, decimal tasaAnual)
        { Numero = numero; Titular = titular; Saldo = saldo; TasaAnual = tasaAnual; }

        // Doble despacho: el tipo de 'this' escoge la sobrecarga correcta del visitante.
        public void Aceptar(IVisitanteProducto v) => v.Visitar(this);
    }

    /// <summary>ELEMENT concreto: cuenta corriente.</summary>
    public class CuentaCorriente : IProductoFinanciero
    {
        public string Tipo => "Cuenta corriente";
        public string Numero { get; }
        public string Titular { get; }
        public decimal Saldo { get; }
        public decimal CupoSobregiro { get; }

        public CuentaCorriente(string numero, string titular, decimal saldo, decimal cupoSobregiro)
        { Numero = numero; Titular = titular; Saldo = saldo; CupoSobregiro = cupoSobregiro; }

        public void Aceptar(IVisitanteProducto v) => v.Visitar(this);
    }

    /// <summary>ELEMENT concreto: certificado de depósito a término (CDT).</summary>
    public class Cdt : IProductoFinanciero
    {
        public string Tipo => "CDT";
        public string Numero { get; }
        public string Titular { get; }
        public decimal Saldo { get; }
        public decimal TasaAnual { get; }
        public int PlazoMeses { get; }

        public Cdt(string numero, string titular, decimal monto, decimal tasaAnual, int plazoMeses)
        { Numero = numero; Titular = titular; Saldo = monto; TasaAnual = tasaAnual; PlazoMeses = plazoMeses; }

        public void Aceptar(IVisitanteProducto v) => v.Visitar(this);
    }

    /// <summary>ELEMENT concreto: préstamo (pasivo del cliente).</summary>
    public class Prestamo : IProductoFinanciero
    {
        public string Tipo => "Préstamo";
        public string Numero { get; }
        public string Titular { get; }
        public decimal Saldo { get; }   // saldo pendiente (deuda)
        public decimal TasaAnual { get; }

        public Prestamo(string numero, string titular, decimal saldoPendiente, decimal tasaAnual)
        { Numero = numero; Titular = titular; Saldo = saldoPendiente; TasaAnual = tasaAnual; }

        public void Aceptar(IVisitanteProducto v) => v.Visitar(this);
    }
}
