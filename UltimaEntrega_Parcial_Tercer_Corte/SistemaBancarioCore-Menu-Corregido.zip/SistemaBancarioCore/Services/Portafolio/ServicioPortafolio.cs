using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.Portafolio
{
    /// <summary>Estado que se muestra en pantalla tras aplicar un visitante.</summary>
    public class ResultadoPortafolio
    {
        public IReadOnlyList<IProductoFinanciero> Productos { get; set; } = new List<IProductoFinanciero>();
        public string Visitante { get; set; } = string.Empty;
        public string VisitanteNombre { get; set; } = string.Empty;
        public List<string> Lineas { get; set; } = new List<string>();
        public string Resumen { get; set; } = string.Empty;
    }

    /// <summary>
    /// Cliente del patrón: arma el portafolio (elementos) y aplica el visitante
    /// elegido recorriendo los productos con Aceptar(visitante).
    /// </summary>
    public class ServicioPortafolio
    {
        private static List<IProductoFinanciero> CrearPortafolio() => new List<IProductoFinanciero>
        {
            new CuentaAhorros("AHO-1001", "Ana Pérez", 6_500_000m, 1.8m),
            new CuentaCorriente("COR-2001", "Ana Pérez", 3_200_000m, 2_000_000m),
            new Cdt("CDT-3001", "Ana Pérez", 10_000_000m, 8.0m, 12),
            new Prestamo("PRE-4001", "Ana Pérez", 4_000_000m, 18.0m)
        };

        private static IVisitanteProducto CrearVisitante(string clave) => clave switch
        {
            "Rendimiento" => new VisitanteRendimiento(),
            "Patrimonio" => new VisitantePatrimonio(),
            _ => new VisitanteResumen()
        };

        public ResultadoPortafolio Ejecutar(string visitanteClave)
        {
            var productos = CrearPortafolio();
            var visitante = CrearVisitante(visitanteClave);

            foreach (var p in productos)
                p.Aceptar(visitante);   // doble despacho: cada producto llama a la visita que le corresponde

            Logger.Instancia.Auditoria($"Portafolio: visitante '{visitante.Nombre}' aplicado a {productos.Count} productos");

            return new ResultadoPortafolio
            {
                Productos = productos,
                Visitante = visitanteClave,
                VisitanteNombre = visitante.Nombre,
                Lineas = new List<string>(visitante.Lineas),
                Resumen = visitante.Resumen
            };
        }
    }
}
