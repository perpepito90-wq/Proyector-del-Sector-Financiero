namespace SistemaBancarioCore.Services.Portafolio
{
    /// <summary>
    /// ELEMENT. Un producto del portafolio. Expone Aceptar(visitante), que delega en
    /// el visitante la operación concreta (doble despacho). Así se pueden agregar
    /// operaciones nuevas sin modificar estas clases.
    /// </summary>
    public interface IProductoFinanciero
    {
        string Tipo { get; }
        string Numero { get; }
        string Titular { get; }
        decimal Saldo { get; }
        void Aceptar(IVisitanteProducto visitante);
    }
}
