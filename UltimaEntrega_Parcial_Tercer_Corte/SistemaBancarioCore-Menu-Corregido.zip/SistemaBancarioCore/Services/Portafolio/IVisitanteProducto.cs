namespace SistemaBancarioCore.Services.Portafolio
{
    /// <summary>
    /// VISITOR. Declara una operación de visita por cada tipo concreto de producto.
    /// Una nueva operación sobre el portafolio (reporte, cálculo, estadística) es un
    /// nuevo visitante; no hay que tocar las clases de productos.
    /// </summary>
    public interface IVisitanteProducto
    {
        string Nombre { get; }
        IReadOnlyList<string> Lineas { get; }
        string Resumen { get; }

        void Visitar(CuentaAhorros cuenta);
        void Visitar(CuentaCorriente cuenta);
        void Visitar(Cdt cdt);
        void Visitar(Prestamo prestamo);
    }
}
