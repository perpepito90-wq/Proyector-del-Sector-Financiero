using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.Cuentas
{
    /// <summary>Resultado de generar una cartera de cuentas (métricas del Flyweight).</summary>
    public class ResultadoCartera
    {
        public int CuentasGeneradas { get; set; }
        public int FlyweightsCompartidos { get; set; }
        public double AhorroMemoria { get; set; }
        public bool ComparticionVerificada { get; set; }
        public List<CuentaBancaria> Muestra { get; } = new List<CuentaBancaria>();
    }

    /// <summary>
    /// Genera una cartera de cuentas para demostrar el Flyweight: muchas cuentas que
    /// comparten unos pocos objetos TipoProducto en lugar de duplicar sus datos.
    /// </summary>
    public class ServicioCartera
    {
        private static readonly string[] Nombres =
            { "Ana", "Luis", "María", "Carlos", "Sofía", "Diego", "Valentina", "Andrés", "Camila", "Jorge" };

        public ResultadoCartera GenerarCartera(int cantidad)
        {
            if (cantidad < 1) cantidad = 1;
            if (cantidad > 200000) cantidad = 200000;   // tope de seguridad

            string[] codigos = CatalogoProductos.Codigos().ToArray();
            var cuentas = new List<CuentaBancaria>(cantidad);
            var rnd = new Random(12345);

            for (int i = 0; i < cantidad; i++)
            {
                string cod = codigos[i % codigos.Length];
                string titular = Nombres[i % Nombres.Length] + " " + (i + 1);
                decimal saldo = rnd.Next(1, 500) * 100000m;
                cuentas.Add(new CuentaBancaria(cod, "CTA-" + (1000 + i), titular, saldo));
            }

            int distintos = cuentas.Select(c => c.Tipo.Codigo).Distinct().Count();
            double ahorro = 100.0 - (distintos * 100.0 / cuentas.Count);

            // Verificación: dos cuentas del mismo tipo comparten la MISMA instancia.
            bool compartido = cuentas.Count <= codigos.Length ||
                              ReferenceEquals(cuentas[0].Tipo, cuentas[codigos.Length].Tipo);

            var r = new ResultadoCartera
            {
                CuentasGeneradas = cuentas.Count,
                FlyweightsCompartidos = distintos,
                AhorroMemoria = Math.Round(ahorro, 2),
                ComparticionVerificada = compartido
            };
            r.Muestra.AddRange(cuentas.Take(8));

            Logger.Instancia.Auditoria(
                $"Cartera generada: {cuentas.Count} cuentas comparten {distintos} tipos de producto (Flyweight), ahorro {r.AhorroMemoria}%");

            return r;
        }
    }
}
