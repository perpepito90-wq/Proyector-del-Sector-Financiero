namespace SistemaBancarioCore.Services.Cuentas
{
    /// <summary>
    /// CLIENTE del Flyweight. Una cuenta concreta guarda una REFERENCIA al tipo de
    /// producto compartido (estado intrínseco) y solo sus datos propios (estado
    /// EXTRÍNSECO: número, titular y saldo). No duplica el nombre, la tasa, la
    /// categoría ni la moneda: esos viven una sola vez en el TipoProducto.
    /// </summary>
    public sealed class CuentaBancaria
    {
        private readonly TipoProducto _tipo;   // referencia al flyweight (compartida)

        public string Numero { get; }          // extrínseco
        public string Titular { get; }         // extrínseco
        public decimal Saldo { get; }          // extrínseco

        public CuentaBancaria(string codigoTipo, string numero, string titular, decimal saldo)
        {
            _tipo = CatalogoProductos.ObtenerTipo(codigoTipo);   // comparte la instancia
            Numero = numero;
            Titular = titular;
            Saldo = saldo;
        }

        /// <summary>El tipo de producto compartido al que pertenece la cuenta.</summary>
        public TipoProducto Tipo => _tipo;

        public string Describir() => _tipo.Describir(Numero, Titular, Saldo);
    }
}
