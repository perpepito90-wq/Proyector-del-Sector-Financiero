namespace SistemaBancarioCore.Services.Cuentas
{
    /// <summary>
    /// FLYWEIGHT FACTORY. Entrega instancias COMPARTIDAS de <see cref="TipoProducto"/>.
    /// Si el tipo ya fue solicitado, devuelve la MISMA instancia desde la caché; si
    /// no, lo crea una sola vez y lo guarda. Así, aunque existan miles de cuentas,
    /// solo hay un objeto TipoProducto por cada producto del catálogo.
    /// </summary>
    public static class CatalogoProductos
    {
        // Definiciones del catálogo (en un sistema real vendrían de la base de datos).
        private static readonly Dictionary<string, (string Nombre, decimal Tasa, string Cat, string Mon, string Desc)> _defs =
            new()
            {
                ["AHO"] = ("Cuenta de Ahorros",        0.005m, "Depósito",         "COP", "Cuenta de ahorro a la vista."),
                ["COR"] = ("Cuenta Corriente",         0.000m, "Depósito",         "COP", "Cuenta corriente con chequera."),
                ["NOM"] = ("Cuenta de Nómina",         0.003m, "Depósito",         "COP", "Cuenta para abono de salario."),
                ["CDT"] = ("Certificado a Término",    0.115m, "Inversión",        "COP", "Certificado de depósito a término fijo."),
                ["AFC"] = ("Ahorro Programado (AFC)",  0.060m, "Ahorro programado","COP", "Ahorro para fomento de la construcción."),
                ["USD"] = ("Cuenta en Dólares",        0.010m, "Depósito",         "USD", "Cuenta de depósito en moneda extranjera."),
            };

        private static readonly Dictionary<string, TipoProducto> _cache = new();
        private static readonly object _bloqueo = new object();

        /// <summary>Devuelve la instancia COMPARTIDA del tipo; la crea solo la primera vez.</summary>
        public static TipoProducto ObtenerTipo(string codigo)
        {
            lock (_bloqueo)
            {
                if (_cache.TryGetValue(codigo, out var existente))
                    return existente;                       // misma instancia para todos

                var d = _defs.TryGetValue(codigo, out var def)
                    ? def
                    : ("Producto " + codigo, 0m, "General", "COP", "Producto genérico.");

                var tipo = new TipoProducto(codigo, d.Item1, d.Item2, d.Item3, d.Item4, d.Item5);
                _cache[codigo] = tipo;
                return tipo;
            }
        }

        /// <summary>Cantidad de instancias de TipoProducto realmente creadas (en caché).</summary>
        public static int TotalInstancias()
        {
            lock (_bloqueo) { return _cache.Count; }
        }

        /// <summary>Códigos de producto disponibles en el catálogo.</summary>
        public static IReadOnlyList<string> Codigos() => _defs.Keys.ToList();

        /// <summary>
        /// Catálogo completo para mostrarlo en pantalla (solo lectura; no afecta la
        /// caché de compartición).
        /// </summary>
        public static IReadOnlyList<TipoProducto> Catalogo() =>
            _defs.Select(kv => new TipoProducto(kv.Key, kv.Value.Nombre, kv.Value.Tasa,
                                                kv.Value.Cat, kv.Value.Mon, kv.Value.Desc))
                 .ToList();
    }
}
