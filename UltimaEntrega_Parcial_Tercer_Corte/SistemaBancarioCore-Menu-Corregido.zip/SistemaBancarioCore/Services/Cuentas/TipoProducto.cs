namespace SistemaBancarioCore.Services.Cuentas
{
    /// <summary>
    /// FLYWEIGHT (inmutable). Representa un TIPO de producto bancario (ahorros,
    /// corriente, CDT...). Todo su estado es INTRÍNSECO: es igual para todas las
    /// cuentas de ese tipo, por lo que una sola instancia se comparte entre miles
    /// de cuentas en lugar de duplicarse en cada una.
    /// </summary>
    public sealed class TipoProducto
    {
        public string Codigo { get; }
        public string Nombre { get; }
        public decimal TasaEA { get; }     // tasa efectiva anual (fracción: 0.115 = 11,5%)
        public string Categoria { get; }
        public string Moneda { get; }
        public string Descripcion { get; }

        public TipoProducto(string codigo, string nombre, decimal tasaEA,
                            string categoria, string moneda, string descripcion)
        {
            Codigo = codigo;
            Nombre = nombre;
            TasaEA = tasaEA;
            Categoria = categoria;
            Moneda = moneda;
            Descripcion = descripcion;
        }

        /// <summary>
        /// Combina el estado INTRÍNSECO (este tipo de producto, compartido) con el
        /// EXTRÍNSECO (los datos propios de la cuenta, que llegan como parámetros).
        /// </summary>
        public string Describir(string numeroCuenta, string titular, decimal saldo)
            => $"{numeroCuenta} | {titular} | {Nombre} ({Codigo}) | {Moneda} {saldo:N0} | tasa {TasaEA:P2} EA";
    }
}
