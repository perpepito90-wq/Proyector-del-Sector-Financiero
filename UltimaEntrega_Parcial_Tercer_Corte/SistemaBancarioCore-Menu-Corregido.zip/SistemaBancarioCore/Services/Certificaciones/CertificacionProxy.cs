using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.Certificaciones
{
    /// <summary>
    /// PROXY. Se hace pasar por el servicio real (misma interfaz) y controla el
    /// acceso a él. Combina tres variantes del patrón:
    ///   • Protection Proxy: verifica permisos por rol antes de delegar.
    ///   • Caching Proxy: guarda el resultado para no regenerarlo (operación costosa).
    ///   • Virtual Proxy: crea el objeto real solo cuando realmente se necesita (lazy).
    /// El cliente usa la misma interfaz y no sabe que hay un intermediario.
    /// </summary>
    public class CertificacionProxy : ICertificacionService
    {
        private ICertificacionService? _real;                                  // lazy (Virtual)
        private static readonly Dictionary<string, string> _cache = new();     // Caching (compartido)
        private static readonly object _bloqueo = new object();

        public ResultadoCertificacion Emitir(SolicitudCertificacion s)
        {
            var r = new ResultadoCertificacion();

            // 1) PROTECTION: control de acceso por rol.
            if (!TienePermiso(s))
            {
                r.Autorizado = false;
                r.Mensaje = $"El rol '{s.Rol}' no está autorizado para emitir esta certificación.";
                r.Traza.Add("Protection → acceso DENEGADO: no se delega en el servicio real.");
                Logger.Instancia.Advertencia(
                    $"Acceso denegado a certificación de la cuenta {s.NumeroCuenta} (rol {s.Rol}, usuario {s.Usuario})");
                return r;
            }
            r.Autorizado = true;
            r.Traza.Add($"Protection → acceso autorizado (rol {s.Rol}).");

            // 2) CACHING: si ya se emitió, se devuelve del caché (sin costo).
            string clave = s.NumeroCuenta + ":" + s.Tipo;
            lock (_bloqueo)
            {
                if (_cache.TryGetValue(clave, out var cached))
                {
                    r.DesdeCache = true;
                    r.Contenido = cached;
                    r.Milisegundos = 0;
                    r.Traza.Add("Caching → certificación recuperada del caché (no se regenera).");
                    Logger.Instancia.Info($"Certificación servida desde el caché: {clave}");
                    return r;
                }
            }

            // 3) VIRTUAL: el servicio real (costoso) se crea solo la primera vez.
            if (_real == null)
            {
                _real = new CertificacionServiceReal();
                r.Traza.Add("Virtual → se crea el servicio real por primera vez (lazy loading).");
            }
            r.Traza.Add("Delegación → se genera la certificación en el servicio real (operación costosa).");

            ResultadoCertificacion real = _real.Emitir(s);
            r.DesdeCache = false;
            r.Contenido = real.Contenido;
            r.Milisegundos = real.Milisegundos;

            // 4) Se guarda en caché para la próxima vez.
            lock (_bloqueo) { _cache[clave] = real.Contenido; }
            r.Traza.Add($"Caching → resultado almacenado en caché (tardó {real.Milisegundos} ms; la próxima vez será inmediato).");

            return r;
        }

        /// <summary>
        /// PROTECTION: reglas de acceso. Un CLIENTE solo puede emitir certificaciones
        /// de su propia cuenta; un ASESOR o un ADMIN pueden emitir cualquiera.
        /// </summary>
        private static bool TienePermiso(SolicitudCertificacion s)
        {
            string rol = (s.Rol ?? string.Empty).Trim().ToUpperInvariant();
            if (rol == "CLIENTE") return s.EsPropia;
            return rol == "ASESOR" || rol == "ADMIN";
        }
    }
}
