using System.Diagnostics;
using System.Text;
using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.Certificaciones
{
    /// <summary>
    /// REAL SUBJECT (Proxy). El servicio real que de verdad emite la certificación:
    /// es una operación COSTOSA (reúne datos, construye el documento y aplica la
    /// firma digital). Por eso conviene protegerlo, crearlo solo cuando se necesita
    /// y cachear su resultado: de eso se encarga el proxy.
    /// </summary>
    public class CertificacionServiceReal : ICertificacionService
    {
        public ResultadoCertificacion Emitir(SolicitudCertificacion s)
        {
            var sw = Stopwatch.StartNew();
            System.Threading.Thread.Sleep(1500);   // simula el costo: datos + render + firma digital
            sw.Stop();

            var sb = new StringBuilder();
            sb.AppendLine("====================================================");
            sb.AppendLine("           CERTIFICACIÓN BANCARIA OFICIAL");
            sb.AppendLine("                Sistema Bancario Core");
            sb.AppendLine("====================================================");
            sb.AppendLine($"Tipo:     {s.Tipo}");
            sb.AppendLine($"Cuenta:   {s.NumeroCuenta}");
            sb.AppendLine($"Titular:  {s.Titular}");
            sb.AppendLine($"Emitida:  {DateTime.Now:yyyy-MM-dd HH:mm}");
            sb.AppendLine("----------------------------------------------------");
            sb.AppendLine("El Sistema Bancario Core certifica que la cuenta");
            sb.AppendLine("referida se encuentra registrada y activa a la fecha.");
            sb.AppendLine();
            sb.AppendLine($"Firma digital: {FirmaDigital(s)}");

            Logger.Instancia.Auditoria(
                $"Certificación emitida (servicio real) para la cuenta {s.NumeroCuenta}, tipo '{s.Tipo}'");

            return new ResultadoCertificacion
            {
                Autorizado = true,
                DesdeCache = false,
                Milisegundos = sw.ElapsedMilliseconds,
                Contenido = sb.ToString()
            };
        }

        private static string FirmaDigital(SolicitudCertificacion s)
        {
            int h = (s.NumeroCuenta + "|" + s.Tipo + "|" + DateTime.Now.ToString("yyyy-MM-dd")).GetHashCode();
            return "SBC-" + (h & 0x7FFFFFFF).ToString("X8");
        }
    }
}
