namespace SistemaBancarioCore.Services.Certificaciones
{
    /// <summary>
    /// SUBJECT (Proxy). Interfaz común que comparten el objeto real y el proxy.
    /// El cliente trabaja siempre contra esta abstracción y no sabe si por detrás
    /// hay un servicio real o un intermediario que controla el acceso.
    /// </summary>
    public interface ICertificacionService
    {
        ResultadoCertificacion Emitir(SolicitudCertificacion solicitud);
    }

    /// <summary>Datos de entrada para emitir una certificación.</summary>
    public class SolicitudCertificacion
    {
        public string NumeroCuenta { get; set; } = string.Empty;
        public string Titular { get; set; } = string.Empty;
        public string Tipo { get; set; } = "Certificación de cuenta";
        public string Usuario { get; set; } = string.Empty;
        public string Rol { get; set; } = "CLIENTE";   // CLIENTE | ASESOR | ADMIN
        public bool EsPropia { get; set; }              // ¿la cuenta es del propio solicitante?
    }

    /// <summary>Resultado de la emisión (y de los controles aplicados por el proxy).</summary>
    public class ResultadoCertificacion
    {
        public bool Autorizado { get; set; }
        public bool DesdeCache { get; set; }
        public long Milisegundos { get; set; }
        public string Contenido { get; set; } = string.Empty;
        public string Mensaje { get; set; } = string.Empty;
        public List<string> Traza { get; } = new List<string>();
    }
}
