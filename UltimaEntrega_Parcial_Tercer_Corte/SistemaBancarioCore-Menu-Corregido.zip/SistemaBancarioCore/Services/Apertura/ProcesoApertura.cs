using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.Apertura
{
    /// <summary>
    /// ABSTRACT CLASS del patrón Template Method. Define el esqueleto del proceso de
    /// apertura en el método plantilla <see cref="Ejecutar"/> (no se sobrescribe). Los
    /// pasos que varían según el producto se dejan como métodos abstractos; el resto
    /// son pasos comunes y un "hook" opcional para la notificación.
    /// </summary>
    public abstract class ProcesoApertura
    {
        /// <summary>Esqueleto fijo del proceso, igual para todos los productos.</summary>
        public static readonly string[] Esqueleto =
        {
            "Validar solicitante",
            "Validar requisitos del producto",
            "Crear el producto",
            "Registrar en auditoría",
            "Notificar al cliente"
        };

        protected abstract string TipoProducto { get; }

        /// <summary>
        /// MÉTODO PLANTILLA. Ejecuta los pasos siempre en el mismo orden. Las subclases
        /// no lo sobrescriben: solo aportan los pasos variables.
        /// </summary>
        public ResultadoApertura Ejecutar(SolicitudApertura datos)
        {
            var r = new ResultadoApertura { TipoProducto = TipoProducto };

            var (ok1, m1) = ValidarSolicitante(datos);
            r.Paso(1, ok1, "Validar solicitante", m1);
            if (!ok1) { r.Exitoso = false; return r; }

            var (ok2, m2) = ValidarRequisitos(datos);   // paso variable
            r.Paso(2, ok2, "Validar requisitos del producto", m2);
            if (!ok2) { r.Exitoso = false; return r; }

            var numero = CrearProducto(datos);           // paso variable
            r.NumeroProducto = numero;
            r.Paso(3, true, "Crear el producto", $"Producto {numero} creado.");

            RegistrarAuditoria(datos, numero);
            r.Paso(4, true, "Registrar en auditoría", "Movimiento registrado en la bitácora.");

            var noti = Notificar(datos, numero);          // hook
            r.Paso(5, true, "Notificar al cliente", noti);

            r.Exitoso = true;
            return r;
        }

        // Paso común (puede reutilizarse tal cual).
        protected virtual (bool ok, string detalle) ValidarSolicitante(SolicitudApertura d)
        {
            if (string.IsNullOrWhiteSpace(d.Nombre) || string.IsNullOrWhiteSpace(d.Documento))
                return (false, "Falta el nombre o el documento del solicitante.");
            return (true, $"Solicitante {d.Nombre} (doc. {d.Documento}) verificado.");
        }

        // Pasos que varían según el producto.
        protected abstract (bool ok, string detalle) ValidarRequisitos(SolicitudApertura d);
        protected abstract string CrearProducto(SolicitudApertura d);

        // Paso común.
        protected void RegistrarAuditoria(SolicitudApertura d, string numero) =>
            Logger.Instancia.Auditoria($"Apertura {TipoProducto}: producto {numero} para {d.Nombre} (monto {d.MontoInicial:N0})");

        // Hook con comportamiento por defecto; las subclases pueden cambiarlo.
        protected virtual string Notificar(SolicitudApertura d, string numero) =>
            $"Correo de bienvenida enviado a {d.Nombre}.";

        protected static string Numero(string prefijo) =>
            $"{prefijo}-{new Random().Next(1000, 9999)}";
    }
}
