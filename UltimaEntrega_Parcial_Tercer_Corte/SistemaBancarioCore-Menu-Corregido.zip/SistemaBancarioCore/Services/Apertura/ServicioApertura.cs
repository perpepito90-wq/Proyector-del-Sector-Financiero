namespace SistemaBancarioCore.Services.Apertura
{
    /// <summary>
    /// Cliente del patrón: elige el proceso concreto según el tipo y dispara el método
    /// plantilla. El esqueleto es el mismo para todos; solo cambian los pasos variables.
    /// </summary>
    public class ServicioApertura
    {
        private static ProcesoApertura Crear(string tipo) => tipo switch
        {
            "Cdt" => new AperturaCdt(),
            "Prestamo" => new AperturaPrestamo(),
            _ => new AperturaCuentaAhorros()
        };

        public ResultadoApertura Abrir(string tipo, SolicitudApertura datos)
        {
            var proceso = Crear(tipo);
            return proceso.Ejecutar(datos);
        }

        public string[] Esqueleto => ProcesoApertura.Esqueleto;
    }
}
