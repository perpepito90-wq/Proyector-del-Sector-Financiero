namespace SistemaBancarioCore.Services.Apertura
{
    /// <summary>
    /// CONCRETE CLASS: apertura de cuenta de ahorros. Solo define los pasos variables;
    /// hereda el esqueleto del proceso.
    /// </summary>
    public class AperturaCuentaAhorros : ProcesoApertura
    {
        private const decimal DepositoMinimo = 50_000m;
        protected override string TipoProducto => "Cuenta de ahorros";

        protected override (bool ok, string detalle) ValidarRequisitos(SolicitudApertura d) =>
            d.MontoInicial >= DepositoMinimo
                ? (true, $"Depósito inicial {d.MontoInicial:N0} cumple el mínimo ({DepositoMinimo:N0}).")
                : (false, $"El depósito inicial debe ser al menos {DepositoMinimo:N0}.");

        protected override string CrearProducto(SolicitudApertura d) => Numero("AHO");
    }

    /// <summary>CONCRETE CLASS: apertura de CDT. Cambia requisitos, creación y notificación (hook).</summary>
    public class AperturaCdt : ProcesoApertura
    {
        private const decimal MontoMinimo = 1_000_000m;
        protected override string TipoProducto => "CDT";

        protected override (bool ok, string detalle) ValidarRequisitos(SolicitudApertura d)
        {
            if (d.MontoInicial < MontoMinimo)
                return (false, $"El monto del CDT debe ser al menos {MontoMinimo:N0}.");
            if (d.PlazoMeses < 3)
                return (false, "El plazo del CDT debe ser de al menos 3 meses.");
            return (true, $"Monto {d.MontoInicial:N0} y plazo {d.PlazoMeses} meses válidos.");
        }

        protected override string CrearProducto(SolicitudApertura d) => Numero("CDT");

        // Hook sobrescrito: el CDT entrega además un certificado.
        protected override string Notificar(SolicitudApertura d, string numero) =>
            $"Correo de bienvenida y certificado del CDT {numero} enviados a {d.Nombre}.";
    }

    /// <summary>CONCRETE CLASS: apertura de préstamo. Cambia requisitos y creación.</summary>
    public class AperturaPrestamo : ProcesoApertura
    {
        private const decimal MontoMaximo = 50_000_000m;
        protected override string TipoProducto => "Préstamo";

        protected override (bool ok, string detalle) ValidarRequisitos(SolicitudApertura d)
        {
            if (d.MontoInicial <= 0)
                return (false, "El monto del préstamo debe ser mayor que cero.");
            if (d.MontoInicial > MontoMaximo)
                return (false, $"El monto supera el máximo permitido ({MontoMaximo:N0}).");
            return (true, $"Monto solicitado {d.MontoInicial:N0} dentro del máximo ({MontoMaximo:N0}).");
        }

        protected override string CrearProducto(SolicitudApertura d) => Numero("PRE");
    }
}
