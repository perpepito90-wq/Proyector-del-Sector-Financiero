namespace SistemaBancarioCore.Services.Apertura
{
    /// <summary>Datos que ingresa el cliente para abrir un producto.</summary>
    public class SolicitudApertura
    {
        public string Nombre { get; set; } = string.Empty;
        public string Documento { get; set; } = string.Empty;
        public decimal MontoInicial { get; set; }
        public int PlazoMeses { get; set; }   // usado por el CDT
    }

    /// <summary>Resultado del proceso: los pasos ejecutados (el esqueleto) y el desenlace.</summary>
    public class ResultadoApertura
    {
        public string TipoProducto { get; set; } = string.Empty;
        public List<string> Pasos { get; set; } = new List<string>();
        public bool Exitoso { get; set; }
        public string? NumeroProducto { get; set; }

        public void Paso(int numero, bool ok, string titulo, string detalle) =>
            Pasos.Add($"{(ok ? "✓" : "✗")} {numero}. {titulo}: {detalle}");
    }
}
