using SistemaBancarioCore.Models;

namespace SistemaBancarioCore.Services.Cumplimiento
{
    /// <summary>Operación de alto valor que debe reportarse (monitoreo AML).</summary>
    public class OperacionAml
    {
        public DateTime Fecha { get; set; }
        public string Cuenta { get; set; } = string.Empty;
        public string Tipo { get; set; } = string.Empty;
        public decimal Monto { get; set; }
    }

    /// <summary>Resumen del tablero de cumplimiento AML.</summary>
    public class ResumenAml
    {
        public int TotalClientes { get; set; }
        public int ClientesAltoRiesgo { get; set; }
        public int OperacionesAltoValor { get; set; }
        public int AlertasPendientes { get; set; }
        public decimal UmbralReporte { get; set; }
    }

    /// <summary>
    /// Servicio de cumplimiento regulatorio. KYC: registra y verifica clientes,
    /// calculando su nivel de riesgo. AML: monitorea operaciones de alto valor y
    /// consolida las alertas. Reutiliza el Logger (Singleton) como registro de auditoría.
    /// </summary>
    public class ServicioCumplimiento
    {
        public const decimal UmbralReporte = 10_000_000m;   // operaciones de alto valor (AML)
        private static readonly string[] PaisesAltoRiesgo =
            { "Corea del Norte", "Irán", "Siria", "Afganistán", "Yemen" };

        private readonly UsuarioContext _db;
        public ServicioCumplimiento(UsuarioContext db) => _db = db;

        // ---------------- KYC ----------------
        public List<Cliente> Clientes() => _db.Clientes.OrderBy(c => c.Id).ToList();

        public Cliente RegistrarCliente(string nombre, string tipoDocumento, string documento, string pais, bool esPEP)
        {
            var (nivel, estado) = EvaluarRiesgo(documento, pais, esPEP);
            var cliente = new Cliente
            {
                Nombre = string.IsNullOrWhiteSpace(nombre) ? "Sin nombre" : nombre.Trim(),
                TipoDocumento = string.IsNullOrWhiteSpace(tipoDocumento) ? "CC" : tipoDocumento,
                Documento = string.IsNullOrWhiteSpace(documento) ? "" : documento.Trim(),
                Pais = string.IsNullOrWhiteSpace(pais) ? "Colombia" : pais.Trim(),
                EsPEP = esPEP,
                NivelRiesgo = nivel,
                EstadoKYC = estado,
                FechaRegistro = DateTime.Now
            };
            _db.Clientes.Add(cliente);
            _db.SaveChanges();
            Logger.Instancia.Auditoria($"KYC: cliente {cliente.Nombre} registrado (riesgo {nivel}, estado {estado})");
            return cliente;
        }

        /// <summary>Evalúa el riesgo del cliente según país, condición PEP y documento.</summary>
        private static (string nivel, string estado) EvaluarRiesgo(string documento, string pais, bool esPEP)
        {
            int riesgo = 0;
            if (PaisesAltoRiesgo.Contains(pais ?? "", StringComparer.OrdinalIgnoreCase)) riesgo += 2;
            if (esPEP) riesgo += 2;
            if (string.IsNullOrWhiteSpace(documento) || documento.Trim().Length < 5) riesgo += 1;

            string nivel = riesgo >= 3 ? "Alto" : riesgo >= 1 ? "Medio" : "Bajo";
            // Alto riesgo o sin documento: queda pendiente de verificación manual.
            string estado = (string.IsNullOrWhiteSpace(documento) || riesgo >= 3) ? "Pendiente" : "Verificado";
            return (nivel, estado);
        }

        public void Verificar(int id) => CambiarEstado(id, "Verificado");
        public void Rechazar(int id) => CambiarEstado(id, "Rechazado");

        private void CambiarEstado(int id, string estado)
        {
            var c = _db.Clientes.FirstOrDefault(x => x.Id == id);
            if (c != null)
            {
                c.EstadoKYC = estado;
                _db.SaveChanges();
                Logger.Instancia.Auditoria($"KYC: cliente {c.Nombre} marcado como {estado}");
            }
        }

        // ---------------- AML ----------------
        public List<OperacionAml> OperacionesAltoValor()
        {
            var cuentas = _db.Cuentas.ToDictionary(c => c.Id, c => $"{c.Numero} · {c.Titular}");
            return _db.Movimientos.Where(m => m.Monto >= UmbralReporte)
                .OrderByDescending(m => m.Fecha).ToList()
                .Select(m => new OperacionAml
                {
                    Fecha = m.Fecha,
                    Cuenta = cuentas.TryGetValue(m.CuentaId, out var n) ? n : $"Cuenta {m.CuentaId}",
                    Tipo = m.Tipo,
                    Monto = m.Monto
                }).ToList();
        }

        public List<AlertaFraude> Alertas() => _db.AlertasFraude.OrderByDescending(a => a.Id).ToList();

        public ResumenAml Resumen() => new ResumenAml
        {
            TotalClientes = _db.Clientes.Count(),
            ClientesAltoRiesgo = _db.Clientes.Count(c => c.NivelRiesgo == "Alto"),
            OperacionesAltoValor = _db.Movimientos.Count(m => m.Monto >= UmbralReporte),
            AlertasPendientes = _db.AlertasFraude.Count(a => a.Estado == "Pendiente"),
            UmbralReporte = UmbralReporte
        };
    }
}
