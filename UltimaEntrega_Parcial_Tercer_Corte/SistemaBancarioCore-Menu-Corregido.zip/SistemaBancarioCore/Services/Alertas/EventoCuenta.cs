namespace SistemaBancarioCore.Services.Alertas
{
    /// <summary>
    /// Datos del evento que la cuenta (sujeto) envía a sus observadores cuando
    /// cambia su estado (saldo). Es el "qué pasó" que cada observador interpreta.
    /// </summary>
    public class EventoCuenta
    {
        public string Cuenta { get; set; } = string.Empty;
        public string Tipo { get; set; } = string.Empty;   // Depósito, Retiro, Transferencia
        public decimal Monto { get; set; }
        public decimal SaldoResultante { get; set; }
        public string Hora { get; set; } = string.Empty;
    }
}
