namespace SistemaBancarioCore.Services.Alertas
{
    /// <summary>Estado que se muestra en pantalla tras cada operación.</summary>
    public class ResultadoAlertas
    {
        public string Cuenta { get; set; } = string.Empty;
        public decimal Saldo { get; set; }
        public List<string> Observadores { get; set; } = new List<string>();
        public List<EventoCuenta> Eventos { get; set; } = new List<EventoCuenta>();
        public List<string> Feed { get; set; } = new List<string>();
        public string? Aviso { get; set; }
    }

    /// <summary>
    /// Cliente del patrón: arma la cuenta (sujeto) y suscribe a los observadores.
    /// Se mantiene en memoria (estático) para que las suscripciones y el saldo
    /// persistan entre peticiones y las notificaciones sean demostrables.
    /// </summary>
    public class ServicioAlertas
    {
        private static CuentaObservable _cuenta = null!;
        private static readonly List<string> _feed = new List<string>();
        private static readonly object _lock = new object();
        private static bool _iniciado = false;

        public ServicioAlertas()
        {
            lock (_lock)
            {
                if (!_iniciado) { Inicializar(); _iniciado = true; }
            }
        }

        private static void Inicializar()
        {
            _feed.Clear();
            _cuenta = new CuentaObservable("CTA-2000", 5_000_000m);
            _cuenta.Suscribir(new ObservadorNotificaciones(_feed));
            _cuenta.Suscribir(new ObservadorAuditoria(_feed));
            _cuenta.Suscribir(new ObservadorMonitorSaldo(_feed));
        }

        public ResultadoAlertas Estado(string? aviso = null)
        {
            var feed = new List<string>(_feed);
            feed.Reverse(); // más reciente primero
            return new ResultadoAlertas
            {
                Cuenta = _cuenta.Numero,
                Saldo = _cuenta.Saldo,
                Observadores = _cuenta.Observadores.Select(o => o.Nombre).ToList(),
                Eventos = new List<EventoCuenta>(_cuenta.Historial),
                Feed = feed,
                Aviso = aviso
            };
        }

        public ResultadoAlertas Ejecutar(string tipo, decimal monto)
        {
            lock (_lock)
            {
                if (monto <= 0)
                    return Estado("El monto debe ser mayor que cero.");

                switch (tipo)
                {
                    case "Deposito":
                        _cuenta.Depositar(monto);
                        return Estado("Depósito aplicado. Los observadores fueron notificados.");
                    case "Retiro":
                        return _cuenta.Retirar("Retiro", monto)
                            ? Estado("Retiro aplicado. Los observadores fueron notificados.")
                            : Estado("Fondos insuficientes: el retiro supera el saldo disponible.");
                    case "Transferencia":
                        return _cuenta.Retirar("Transferencia enviada", monto)
                            ? Estado("Transferencia aplicada. Los observadores fueron notificados.")
                            : Estado("Fondos insuficientes: la transferencia supera el saldo disponible.");
                    default:
                        return Estado("Operación no reconocida.");
                }
            }
        }

        public ResultadoAlertas Reiniciar()
        {
            lock (_lock)
            {
                Inicializar();
                return Estado("Cuenta reiniciada.");
            }
        }
    }
}
