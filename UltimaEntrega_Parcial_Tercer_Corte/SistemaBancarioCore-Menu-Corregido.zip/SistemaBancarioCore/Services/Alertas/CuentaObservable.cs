namespace SistemaBancarioCore.Services.Alertas
{
    /// <summary>
    /// SUBJECT concreto. Una cuenta que, al mover su saldo, notifica a todos sus
    /// observadores. La cuenta no envía correos ni audita: solo anuncia el evento;
    /// cada observador decide cómo reaccionar.
    /// </summary>
    public class CuentaObservable : ISujetoCuenta
    {
        private readonly List<IObservadorCuenta> _observadores = new List<IObservadorCuenta>();

        public string Numero { get; }
        public decimal Saldo { get; private set; }
        public List<EventoCuenta> Historial { get; } = new List<EventoCuenta>();

        public CuentaObservable(string numero, decimal saldoInicial)
        {
            Numero = numero;
            Saldo = saldoInicial;
        }

        public IReadOnlyList<IObservadorCuenta> Observadores => _observadores;

        public void Suscribir(IObservadorCuenta observador)
        {
            if (!_observadores.Contains(observador)) _observadores.Add(observador);
        }

        public void Desuscribir(IObservadorCuenta observador) => _observadores.Remove(observador);

        public void Notificar(EventoCuenta evento)
        {
            Historial.Add(evento);
            foreach (var o in _observadores)
                o.Actualizar(evento);   // uno-a-muchos: todos se enteran automáticamente
        }

        public void Depositar(decimal monto)
        {
            Saldo += monto;
            Notificar(Evento("Depósito", monto));
        }

        public bool Retirar(string tipo, decimal monto)
        {
            if (monto > Saldo) return false;          // fondos insuficientes
            Saldo -= monto;
            Notificar(Evento(tipo, monto));
            return true;
        }

        private EventoCuenta Evento(string tipo, decimal monto) => new EventoCuenta
        {
            Cuenta = Numero,
            Tipo = tipo,
            Monto = monto,
            SaldoResultante = Saldo,
            Hora = DateTime.Now.ToString("HH:mm:ss")
        };
    }
}
