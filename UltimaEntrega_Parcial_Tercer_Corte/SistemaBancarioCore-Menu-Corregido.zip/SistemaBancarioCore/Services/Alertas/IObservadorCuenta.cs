namespace SistemaBancarioCore.Services.Alertas
{
    /// <summary>
    /// OBSERVER. Cualquier módulo interesado en los cambios de una cuenta implementa
    /// esta interfaz. El sujeto solo conoce esta abstracción, nunca las clases
    /// concretas que reaccionan.
    /// </summary>
    public interface IObservadorCuenta
    {
        string Nombre { get; }
        void Actualizar(EventoCuenta evento);
    }
}
