namespace SistemaBancarioCore.Services.Alertas
{
    /// <summary>
    /// SUBJECT (Observable). Mantiene la lista de observadores y los notifica cuando
    /// cambia de estado. No sabe qué hace cada observador: solo los recorre.
    /// </summary>
    public interface ISujetoCuenta
    {
        void Suscribir(IObservadorCuenta observador);
        void Desuscribir(IObservadorCuenta observador);
        void Notificar(EventoCuenta evento);
    }
}
