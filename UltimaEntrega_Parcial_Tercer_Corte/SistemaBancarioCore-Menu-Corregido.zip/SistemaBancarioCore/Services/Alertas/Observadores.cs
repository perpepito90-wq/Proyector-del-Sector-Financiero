using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.Alertas
{
    /// <summary>
    /// OBSERVER concreto. Avisa al cliente del movimiento. Cada reacción se registra
    /// en un feed compartido para mostrarla en pantalla.
    /// </summary>
    public class ObservadorNotificaciones : IObservadorCuenta
    {
        private readonly List<string> _feed;
        public string Nombre => "Notificaciones";
        public ObservadorNotificaciones(List<string> feed) => _feed = feed;

        public void Actualizar(EventoCuenta e) =>
            _feed.Add($"[Notificación] Alerta al cliente: {e.Tipo} de {e.Monto:N0} en {e.Cuenta}. Saldo: {e.SaldoResultante:N0}.");
    }

    /// <summary>
    /// OBSERVER concreto. Registra el movimiento en la auditoría, reutilizando el
    /// Logger (Singleton) ya existente en el sistema.
    /// </summary>
    public class ObservadorAuditoria : IObservadorCuenta
    {
        private readonly List<string> _feed;
        public string Nombre => "Auditoría";
        public ObservadorAuditoria(List<string> feed) => _feed = feed;

        public void Actualizar(EventoCuenta e)
        {
            Logger.Instancia.Auditoria($"Cuenta {e.Cuenta}: {e.Tipo} de {e.Monto:N0}. Saldo {e.SaldoResultante:N0}");
            _feed.Add($"[Auditoría] Registrado en bitácora: {e.Tipo} de {e.Monto:N0}.");
        }
    }

    /// <summary>
    /// OBSERVER concreto. Vigila el saldo y los movimientos grandes, y levanta una
    /// advertencia cuando corresponde.
    /// </summary>
    public class ObservadorMonitorSaldo : IObservadorCuenta
    {
        private const decimal UmbralSaldoBajo = 1_000_000m;
        private const decimal UmbralMovimientoGrande = 2_000_000m;
        private readonly List<string> _feed;
        public string Nombre => "Monitor de saldo";
        public ObservadorMonitorSaldo(List<string> feed) => _feed = feed;

        public void Actualizar(EventoCuenta e)
        {
            if (e.Tipo != "Depósito" && e.Monto >= UmbralMovimientoGrande)
                _feed.Add($"[Monitor] Movimiento grande detectado: {e.Monto:N0}. Revisión recomendada.");
            else if (e.SaldoResultante < UmbralSaldoBajo)
                _feed.Add($"[Monitor] Saldo bajo: {e.SaldoResultante:N0} (umbral {UmbralSaldoBajo:N0}).");
            else
                _feed.Add("[Monitor] Movimiento dentro de los parámetros normales.");
        }
    }
}
