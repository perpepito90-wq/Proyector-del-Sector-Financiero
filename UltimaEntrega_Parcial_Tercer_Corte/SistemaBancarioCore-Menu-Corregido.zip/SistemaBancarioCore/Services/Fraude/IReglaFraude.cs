namespace SistemaBancarioCore.Services.Fraude
{
    /// <summary>
    /// HANDLER del patrón Chain of Responsibility. Cada regla de fraude evalúa la
    /// transacción y puede pasar el contexto a la siguiente regla de la cadena.
    /// </summary>
    public interface IReglaFraude
    {
        string Nombre { get; }
        IReglaFraude Siguiente(IReglaFraude siguiente);
        void Evaluar(ContextoFraude contexto);
    }

    /// <summary>
    /// Handler base. Implementa el encadenamiento: revisa su propia regla y, si ninguna
    /// regla ha bloqueado la transacción, delega en la siguiente de la cadena.
    /// </summary>
    public abstract class ReglaFraude : IReglaFraude
    {
        private IReglaFraude? _siguiente;

        public abstract string Nombre { get; }

        public IReglaFraude Siguiente(IReglaFraude siguiente)
        {
            _siguiente = siguiente;
            return siguiente;   // permite encadenar con fluidez: a.Siguiente(b).Siguiente(c)
        }

        public void Evaluar(ContextoFraude contexto)
        {
            Revisar(contexto);
            if (!contexto.Bloqueado)        // una regla puede cortar la cadena bloqueando
                _siguiente?.Evaluar(contexto);
        }

        /// <summary>Lógica propia de cada regla concreta.</summary>
        protected abstract void Revisar(ContextoFraude contexto);
    }
}
