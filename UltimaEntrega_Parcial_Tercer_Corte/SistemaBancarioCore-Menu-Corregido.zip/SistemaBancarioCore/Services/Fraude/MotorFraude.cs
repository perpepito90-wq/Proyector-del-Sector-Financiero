namespace SistemaBancarioCore.Services.Fraude
{
    /// <summary>
    /// Arma la cadena de reglas (Chain of Responsibility) y evalúa una transacción en
    /// tiempo real. La decisión se obtiene del puntaje de riesgo acumulado por la cadena.
    /// </summary>
    public class MotorFraude
    {
        private readonly IReglaFraude _cadena;
        private readonly List<string> _nombres;

        public MotorFraude()
        {
            // Orden de la cadena: primero la regla dura (puede cortar), luego las de riesgo.
            var critico = new ReglaBloqueoCritico();
            var alto = new ReglaMontoAlto();
            var frecuencia = new ReglaFrecuencia();
            var inusual = new ReglaMontoInusual();
            var horario = new ReglaHorarioInusual();

            critico.Siguiente(alto).Siguiente(frecuencia).Siguiente(inusual).Siguiente(horario);
            _cadena = critico;

            _nombres = new List<string>
            {
                critico.Nombre, alto.Nombre, frecuencia.Nombre, inusual.Nombre, horario.Nombre
            };
        }

        public IReadOnlyList<string> ReglasConfiguradas => _nombres;

        public ResultadoFraude Evaluar(ContextoFraude ctx)
        {
            _cadena.Evaluar(ctx);

            string decision =
                ctx.Bloqueado || ctx.Puntaje >= 70 ? "Bloqueada" :
                ctx.Puntaje >= 40 ? "Revisar" :
                "Aprobada";

            return new ResultadoFraude
            {
                Decision = decision,
                Puntaje = ctx.Puntaje,
                Motivos = new List<string>(ctx.Motivos),
                Bloqueado = ctx.Bloqueado
            };
        }
    }
}
