namespace SistemaBancarioCore.Services.Fraude
{
    /// <summary>Regla dura: un retiro/transferencia por encima del límite crítico se bloquea y corta la cadena.</summary>
    public class ReglaBloqueoCritico : ReglaFraude
    {
        public const decimal UmbralCritico = 20_000_000m;
        public override string Nombre => "Bloqueo por límite crítico";
        protected override void Revisar(ContextoFraude c)
        {
            if (c.Tipo != "Depósito" && c.Monto >= UmbralCritico)
            {
                c.Sumar(100, $"Supera el límite crítico de {UmbralCritico:N0}");
                c.Bloqueado = true;
            }
        }
    }

    /// <summary>Regla: monto alto en un retiro o transferencia.</summary>
    public class ReglaMontoAlto : ReglaFraude
    {
        public const decimal UmbralAlto = 5_000_000m;
        public override string Nombre => "Monto alto";
        protected override void Revisar(ContextoFraude c)
        {
            if (c.Tipo != "Depósito" && c.Monto >= UmbralAlto)
                c.Sumar(40, $"Monto alto (≥ {UmbralAlto:N0})");
        }
    }

    /// <summary>Regla: alta frecuencia de movimientos en poco tiempo.</summary>
    public class ReglaFrecuencia : ReglaFraude
    {
        public const int UmbralMovimientos = 3;
        public override string Nombre => "Alta frecuencia";
        protected override void Revisar(ContextoFraude c)
        {
            if (c.MovimientosRecientes >= UmbralMovimientos)
                c.Sumar(30, $"Alta frecuencia: {c.MovimientosRecientes} movimientos recientes");
        }
    }

    /// <summary>Regla: monto muy por encima del promedio histórico de la cuenta.</summary>
    public class ReglaMontoInusual : ReglaFraude
    {
        public override string Nombre => "Monto inusual";
        protected override void Revisar(ContextoFraude c)
        {
            if (c.PromedioHistorico > 0 && c.Monto > 3 * c.PromedioHistorico)
                c.Sumar(30, $"Monto inusual: supera 3× el promedio ({c.PromedioHistorico:N0})");
        }
    }

    /// <summary>Regla: transacción en horario inusual (madrugada).</summary>
    public class ReglaHorarioInusual : ReglaFraude
    {
        public override string Nombre => "Horario inusual";
        protected override void Revisar(ContextoFraude c)
        {
            if (c.Fecha.Hour < 6)
                c.Sumar(15, $"Horario inusual ({c.Fecha:HH:mm})");
        }
    }
}
