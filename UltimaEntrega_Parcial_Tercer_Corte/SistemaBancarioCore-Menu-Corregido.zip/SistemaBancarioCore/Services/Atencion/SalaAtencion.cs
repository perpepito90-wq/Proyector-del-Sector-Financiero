using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.Atencion
{
    /// <summary>
    /// MEDIATOR CONCRETO. La sala de atención conoce a todos los participantes y
    /// centraliza las reglas de enrutamiento: cuando alguien envía un mensaje, la
    /// sala decide a quién entregárselo. Así los participantes quedan desacoplados
    /// entre sí.
    /// </summary>
    public class SalaAtencion : IMediadorAtencion
    {
        private readonly List<Participante> _participantes = new List<Participante>();

        public List<Mensaje> Transcripcion { get; } = new List<Mensaje>();
        public List<string> Bitacora { get; } = new List<string>();

        public void Registrar(Participante participante)
        {
            _participantes.Add(participante);
            Bitacora.Add($"{participante.Rol} '{participante.Nombre}' entra a la sala.");
        }

        public void Enviar(string texto, Participante remitente)
        {
            var mensaje = new Mensaje
            {
                Remitente = remitente.Nombre,
                Rol = remitente.Rol,
                Texto = texto,
                Hora = DateTime.Now.ToString("HH:mm")
            };

            // El MEDIADOR decide los destinatarios (regla de enrutamiento centralizada).
            bool escala = remitente.Rol == "Cliente" &&
                          (texto.ToLower().Contains("queja") || texto.ToLower().Contains("reclamo"));

            List<Participante> destinatarios;
            if (remitente.Rol == "Cliente")
            {
                destinatarios = _participantes.Where(p => p.Rol == "Asesor").ToList();
                if (escala)
                    destinatarios.AddRange(_participantes.Where(p => p.Rol == "Supervisor"));
            }
            else
            {
                destinatarios = _participantes.Where(p => p != remitente).ToList();
            }

            foreach (var d in destinatarios.Distinct())
            {
                d.Recibir(mensaje);
                mensaje.Destinatarios.Add($"{d.Nombre} ({d.Rol})");
            }

            Transcripcion.Add(mensaje);
            if (escala)
                Bitacora.Add("La sala escaló el mensaje a Supervisión por contener una queja/reclamo.");
            Bitacora.Add($"{remitente.Nombre} → sala → " +
                         (mensaje.Destinatarios.Count > 0 ? string.Join(", ", mensaje.Destinatarios) : "nadie disponible"));

            Logger.Instancia.Auditoria(
                $"Atención: mensaje de {remitente.Nombre} ({remitente.Rol}) entregado a {mensaje.Destinatarios.Count} participante(s)");
        }
    }
}
