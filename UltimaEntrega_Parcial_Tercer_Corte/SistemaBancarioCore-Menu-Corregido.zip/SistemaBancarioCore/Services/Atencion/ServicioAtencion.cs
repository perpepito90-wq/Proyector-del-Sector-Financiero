namespace SistemaBancarioCore.Services.Atencion
{
    /// <summary>Resultado de una simulación de la sala de atención.</summary>
    public class ResultadoAtencion
    {
        public List<Mensaje> Transcripcion { get; set; } = new List<Mensaje>();
        public List<string> Bitacora { get; set; } = new List<string>();
    }

    /// <summary>
    /// Arma la sala con sus participantes, reproduce una conversación base y, si el
    /// usuario escribió un mensaje, lo envía como el rol elegido. Todo pasa por el
    /// mediador: los participantes nunca se llaman entre sí.
    /// </summary>
    public class ServicioAtencion
    {
        public ResultadoAtencion Simular(string rolRemitente, string textoExtra)
        {
            var sala = new SalaAtencion();
            var cliente = new ClienteParticipante("Ana", sala);
            var asesor = new AsesorParticipante("Carlos", sala);
            var supervisor = new SupervisorParticipante("Lucía", sala);

            sala.Registrar(cliente);
            sala.Registrar(asesor);
            sala.Registrar(supervisor);

            // Conversación base (los participantes solo hablan con la sala).
            cliente.Enviar("Buenas, necesito ayuda con una transferencia que no se reflejó.");
            asesor.Enviar("Claro, Ana. ¿Me confirma el número de cuenta y la fecha?");

            // Mensaje adicional que escribe el usuario (opcional).
            if (!string.IsNullOrWhiteSpace(textoExtra))
            {
                Participante quien = rolRemitente switch
                {
                    "Asesor" => asesor,
                    "Supervisor" => supervisor,
                    _ => cliente
                };
                quien.Enviar(textoExtra.Trim());
            }

            return new ResultadoAtencion
            {
                Transcripcion = sala.Transcripcion,
                Bitacora = sala.Bitacora
            };
        }
    }
}
