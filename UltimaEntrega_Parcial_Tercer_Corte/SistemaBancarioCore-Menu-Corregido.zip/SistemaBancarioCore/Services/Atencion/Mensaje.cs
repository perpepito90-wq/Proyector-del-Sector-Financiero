namespace SistemaBancarioCore.Services.Atencion
{
    /// <summary>Un mensaje dentro de la sala de atención, con sus destinatarios.</summary>
    public class Mensaje
    {
        public string Remitente { get; set; } = string.Empty;
        public string Rol { get; set; } = string.Empty;
        public string Texto { get; set; } = string.Empty;
        public string Hora { get; set; } = string.Empty;
        public List<string> Destinatarios { get; } = new List<string>();
    }
}
