namespace SistemaBancarioCore.Services.Atencion
{
    /// <summary>
    /// COLLEAGUE (abstracto). Cada participante conoce al mediador, nunca a los
    /// demás participantes. Envía a través del mediador y recibe lo que este le entrega.
    /// </summary>
    public abstract class Participante
    {
        protected readonly IMediadorAtencion Mediador;

        public string Nombre { get; }
        public string Rol { get; }
        public List<Mensaje> Recibidos { get; } = new List<Mensaje>();

        protected Participante(string nombre, string rol, IMediadorAtencion mediador)
        {
            Nombre = nombre;
            Rol = rol;
            Mediador = mediador;
        }

        public void Enviar(string texto) => Mediador.Enviar(texto, this);
        public virtual void Recibir(Mensaje mensaje) => Recibidos.Add(mensaje);
    }

    /// <summary>COLLEAGUE concreto: el cliente que solicita atención.</summary>
    public class ClienteParticipante : Participante
    {
        public ClienteParticipante(string nombre, IMediadorAtencion mediador)
            : base(nombre, "Cliente", mediador) { }
    }

    /// <summary>COLLEAGUE concreto: el asesor que atiende.</summary>
    public class AsesorParticipante : Participante
    {
        public AsesorParticipante(string nombre, IMediadorAtencion mediador)
            : base(nombre, "Asesor", mediador) { }
    }

    /// <summary>COLLEAGUE concreto: el supervisor (interviene en escalamientos).</summary>
    public class SupervisorParticipante : Participante
    {
        public SupervisorParticipante(string nombre, IMediadorAtencion mediador)
            : base(nombre, "Supervisor", mediador) { }
    }
}
