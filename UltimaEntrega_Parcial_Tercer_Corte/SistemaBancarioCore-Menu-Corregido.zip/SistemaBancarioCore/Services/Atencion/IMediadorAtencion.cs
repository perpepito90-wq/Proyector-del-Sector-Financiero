namespace SistemaBancarioCore.Services.Atencion
{
    /// <summary>
    /// MEDIATOR. Centraliza la comunicación entre los participantes de la atención.
    /// Los participantes no se conocen entre sí: solo hablan con el mediador, que
    /// decide a quién entregar cada mensaje.
    /// </summary>
    public interface IMediadorAtencion
    {
        void Registrar(Participante participante);
        void Enviar(string texto, Participante remitente);
    }
}
