using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.Creditos
{
    /// <summary>
    /// CONTEXT. La solicitud delega cada operación en su estado actual. Cambia su
    /// comportamiento según el estado (parece "cambiar de clase") sin condicionales
    /// anidados. Solo conoce la interfaz IEstadoSolicitud.
    /// </summary>
    public class SolicitudCredito
    {
        private IEstadoSolicitud _estado;

        public string Id { get; }
        public string Cliente { get; }
        public decimal Monto { get; }
        public List<string> Historial { get; } = new List<string>();
        public string? UltimoMensaje { get; private set; }

        public SolicitudCredito(string id, string cliente, decimal monto)
        {
            Id = id;
            Cliente = cliente;
            Monto = monto;
            _estado = new RadicadaState();
            Historial.Add($"Solicitud {id} radicada por {cliente} por {monto:N0}.");
        }

        public string Estado => _estado.Nombre;

        // La solicitud delega: no sabe qué es válido, lo sabe el estado.
        public void EnviarARevision() => _estado.EnviarARevision(this);
        public void Aprobar() => _estado.Aprobar(this);
        public void Rechazar() => _estado.Rechazar(this);
        public void Desembolsar() => _estado.Desembolsar(this);

        /// <summary>Transición válida: cambia de estado y lo registra/auditará.</summary>
        internal void Transicionar(IEstadoSolicitud nuevo, string mensaje)
        {
            var anterior = _estado.Nombre;
            _estado = nuevo;
            UltimoMensaje = mensaje;
            Historial.Add($"{anterior} → {nuevo.Nombre}: {mensaje}");
            Logger.Instancia.Auditoria($"Crédito {Id}: {anterior} → {nuevo.Nombre} ({mensaje})");
        }

        /// <summary>Intento inválido: no cambia de estado, deja constancia.</summary>
        internal void Invalido(string mensaje)
        {
            UltimoMensaje = mensaje;
            Historial.Add($"✗ ({_estado.Nombre}) {mensaje}");
        }
    }
}
