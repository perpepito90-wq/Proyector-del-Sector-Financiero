namespace SistemaBancarioCore.Services.Creditos
{
    /// <summary>Estado que se muestra en pantalla tras cada operación.</summary>
    public class ResultadoCredito
    {
        public string Id { get; set; } = string.Empty;
        public string Cliente { get; set; } = string.Empty;
        public decimal Monto { get; set; }
        public string Estado { get; set; } = string.Empty;
        public List<string> Historial { get; set; } = new List<string>();
        public string? Aviso { get; set; }
        public bool Invalido { get; set; }
    }

    /// <summary>
    /// Orquesta la solicitud (contexto). Se mantiene en memoria (estático) para que
    /// el estado persista entre peticiones y las transiciones sean demostrables.
    /// </summary>
    public class ServicioCreditos
    {
        private static SolicitudCredito _solicitud = null!;
        private static readonly object _lock = new object();
        private static bool _iniciado = false;

        public ServicioCreditos()
        {
            lock (_lock)
            {
                if (!_iniciado) { Inicializar(); _iniciado = true; }
            }
        }

        private static void Inicializar() =>
            _solicitud = new SolicitudCredito("CRD-001", "Ana Pérez", 8_000_000m);

        public ResultadoCredito Estado(string? aviso = null, bool invalido = false) => new ResultadoCredito
        {
            Id = _solicitud.Id,
            Cliente = _solicitud.Cliente,
            Monto = _solicitud.Monto,
            Estado = _solicitud.Estado,
            Historial = new List<string>(_solicitud.Historial),
            Aviso = aviso,
            Invalido = invalido
        };

        public ResultadoCredito Accion(string accion)
        {
            lock (_lock)
            {
                switch (accion)
                {
                    case "EnviarARevision": _solicitud.EnviarARevision(); break;
                    case "Aprobar": _solicitud.Aprobar(); break;
                    case "Rechazar": _solicitud.Rechazar(); break;
                    case "Desembolsar": _solicitud.Desembolsar(); break;
                    default: return Estado("Operación no reconocida.", true);
                }
                // Una transición inválida deja una entrada marcada con "✗" en el historial.
                bool invalido = _solicitud.Historial.Count > 0 && _solicitud.Historial[^1].StartsWith("✗");
                return Estado(_solicitud.UltimoMensaje, invalido);
            }
        }

        public ResultadoCredito Reiniciar()
        {
            lock (_lock)
            {
                Inicializar();
                return Estado("Solicitud reiniciada al estado Radicada.");
            }
        }
    }
}
