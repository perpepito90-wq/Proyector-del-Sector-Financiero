namespace SistemaBancarioCore.Services.Creditos
{
    /// <summary>
    /// STATE. Define las operaciones del ciclo de vida de una solicitud de crédito.
    /// Cada estado concreto decide qué transiciones son válidas desde él, de modo que
    /// el contexto no necesita un switch gigante con todos los casos.
    /// </summary>
    public interface IEstadoSolicitud
    {
        string Nombre { get; }
        void EnviarARevision(SolicitudCredito solicitud);
        void Aprobar(SolicitudCredito solicitud);
        void Rechazar(SolicitudCredito solicitud);
        void Desembolsar(SolicitudCredito solicitud);
    }
}
