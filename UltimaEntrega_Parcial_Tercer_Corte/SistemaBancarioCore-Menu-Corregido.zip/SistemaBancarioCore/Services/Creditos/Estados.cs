namespace SistemaBancarioCore.Services.Creditos
{
    /// <summary>STATE concreto: recién radicada. Solo puede ir a revisión o rechazarse.</summary>
    public class RadicadaState : IEstadoSolicitud
    {
        public string Nombre => "Radicada";
        public void EnviarARevision(SolicitudCredito s) => s.Transicionar(new EnRevisionState(), "Enviada a revisión del comité.");
        public void Aprobar(SolicitudCredito s) => s.Invalido("No se puede aprobar: primero debe pasar a revisión.");
        public void Rechazar(SolicitudCredito s) => s.Transicionar(new RechazadaState(), "Rechazada antes de revisión.");
        public void Desembolsar(SolicitudCredito s) => s.Invalido("No se puede desembolsar: la solicitud no está aprobada.");
    }

    /// <summary>STATE concreto: en revisión. Puede aprobarse o rechazarse.</summary>
    public class EnRevisionState : IEstadoSolicitud
    {
        public string Nombre => "En revisión";
        public void EnviarARevision(SolicitudCredito s) => s.Invalido("La solicitud ya está en revisión.");
        public void Aprobar(SolicitudCredito s) => s.Transicionar(new AprobadaState(), "Aprobada por el comité.");
        public void Rechazar(SolicitudCredito s) => s.Transicionar(new RechazadaState(), "Rechazada en revisión.");
        public void Desembolsar(SolicitudCredito s) => s.Invalido("No se puede desembolsar: la solicitud aún no está aprobada.");
    }

    /// <summary>STATE concreto: aprobada. Solo puede desembolsarse.</summary>
    public class AprobadaState : IEstadoSolicitud
    {
        public string Nombre => "Aprobada";
        public void EnviarARevision(SolicitudCredito s) => s.Invalido("La solicitud ya fue aprobada.");
        public void Aprobar(SolicitudCredito s) => s.Invalido("La solicitud ya está aprobada.");
        public void Rechazar(SolicitudCredito s) => s.Invalido("No se puede rechazar una solicitud ya aprobada.");
        public void Desembolsar(SolicitudCredito s) => s.Transicionar(new DesembolsadaState(), "Crédito desembolsado al cliente.");
    }

    /// <summary>STATE concreto: rechazada (estado final).</summary>
    public class RechazadaState : IEstadoSolicitud
    {
        public string Nombre => "Rechazada";
        public void EnviarARevision(SolicitudCredito s) => s.Invalido("La solicitud está rechazada; es un estado final.");
        public void Aprobar(SolicitudCredito s) => s.Invalido("La solicitud está rechazada; es un estado final.");
        public void Rechazar(SolicitudCredito s) => s.Invalido("La solicitud ya está rechazada.");
        public void Desembolsar(SolicitudCredito s) => s.Invalido("La solicitud está rechazada; no se puede desembolsar.");
    }

    /// <summary>STATE concreto: desembolsada (estado final).</summary>
    public class DesembolsadaState : IEstadoSolicitud
    {
        public string Nombre => "Desembolsada";
        public void EnviarARevision(SolicitudCredito s) => s.Invalido("El crédito ya fue desembolsado; es un estado final.");
        public void Aprobar(SolicitudCredito s) => s.Invalido("El crédito ya fue desembolsado; es un estado final.");
        public void Rechazar(SolicitudCredito s) => s.Invalido("El crédito ya fue desembolsado; no se puede rechazar.");
        public void Desembolsar(SolicitudCredito s) => s.Invalido("El crédito ya fue desembolsado.");
    }
}
