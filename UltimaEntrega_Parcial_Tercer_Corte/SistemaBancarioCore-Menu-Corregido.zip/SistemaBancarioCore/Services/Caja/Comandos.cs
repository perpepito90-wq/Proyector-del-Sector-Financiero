namespace SistemaBancarioCore.Services.Caja
{
    /// <summary>COMMAND concreto: depósito. Deshacer = retirar el mismo monto.</summary>
    public class ComandoDeposito : IComando
    {
        private readonly CuentaCaja _cuenta;
        private readonly decimal _monto;
        public bool Aplicado { get; private set; }
        public string Descripcion => $"Depósito de {_monto:N0}";

        public ComandoDeposito(CuentaCaja cuenta, decimal monto) { _cuenta = cuenta; _monto = monto; }

        public void Ejecutar() { _cuenta.Depositar(_monto); Aplicado = true; }
        public void Deshacer() { if (Aplicado) _cuenta.Retirar(_monto); }
    }

    /// <summary>COMMAND concreto: retiro. Deshacer = devolver el monto.</summary>
    public class ComandoRetiro : IComando
    {
        private readonly CuentaCaja _cuenta;
        private readonly decimal _monto;
        public bool Aplicado { get; private set; }
        public string Descripcion => $"Retiro de {_monto:N0}";

        public ComandoRetiro(CuentaCaja cuenta, decimal monto) { _cuenta = cuenta; _monto = monto; }

        public void Ejecutar() { Aplicado = _cuenta.Retirar(_monto); }
        public void Deshacer() { if (Aplicado) _cuenta.Depositar(_monto); }
    }

    /// <summary>COMMAND concreto: transferencia a un tercero. Deshacer = devolver el monto.</summary>
    public class ComandoTransferencia : IComando
    {
        private readonly CuentaCaja _cuenta;
        private readonly decimal _monto;
        private readonly string _beneficiario;
        public bool Aplicado { get; private set; }
        public string Descripcion => $"Transferencia de {_monto:N0} a {_beneficiario}";

        public ComandoTransferencia(CuentaCaja cuenta, decimal monto, string beneficiario)
        { _cuenta = cuenta; _monto = monto; _beneficiario = string.IsNullOrWhiteSpace(beneficiario) ? "un tercero" : beneficiario.Trim(); }

        public void Ejecutar() { Aplicado = _cuenta.Retirar(_monto); }
        public void Deshacer() { if (Aplicado) _cuenta.Depositar(_monto); }
    }
}
