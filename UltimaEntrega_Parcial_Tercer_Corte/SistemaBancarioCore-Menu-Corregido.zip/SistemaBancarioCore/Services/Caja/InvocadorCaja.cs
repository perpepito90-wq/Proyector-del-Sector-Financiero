using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.Caja
{
    /// <summary>
    /// INVOKER. Dispara los comandos sin saber qué hacen por dentro. Lleva el historial
    /// de lo ejecutado (para deshacer) y una cola de pendientes (para procesar en lote).
    /// </summary>
    public class InvocadorCaja
    {
        private readonly List<IComando> _historial = new List<IComando>();
        private readonly List<IComando> _cola = new List<IComando>();

        public IReadOnlyList<IComando> Historial => _historial;
        public IReadOnlyList<IComando> Cola => _cola;
        public bool PuedeDeshacer => _historial.Count > 0;

        /// <summary>Ejecuta el comando de inmediato y lo registra si se aplicó.</summary>
        public bool EjecutarAhora(IComando comando)
        {
            comando.Ejecutar();
            if (comando.Aplicado)
            {
                _historial.Add(comando);
                Logger.Instancia.Auditoria($"Caja: ejecutado '{comando.Descripcion}'");
            }
            return comando.Aplicado;
        }

        /// <summary>Agrega el comando a la cola sin ejecutarlo todavía.</summary>
        public void Encolar(IComando comando) => _cola.Add(comando);

        /// <summary>Ejecuta en orden todos los comandos encolados.</summary>
        public (int aplicados, int rechazados) ProcesarCola()
        {
            int ok = 0, no = 0;
            foreach (var cmd in _cola)
            {
                cmd.Ejecutar();
                if (cmd.Aplicado) { _historial.Add(cmd); ok++; Logger.Instancia.Auditoria($"Caja (cola): ejecutado '{cmd.Descripcion}'"); }
                else no++;
            }
            _cola.Clear();
            return (ok, no);
        }

        /// <summary>Deshace la última operación ejecutada.</summary>
        public string? DeshacerUltimo()
        {
            if (_historial.Count == 0) return null;
            var cmd = _historial[^1];
            _historial.RemoveAt(_historial.Count - 1);
            cmd.Deshacer();
            Logger.Instancia.Auditoria($"Caja: deshecho '{cmd.Descripcion}'");
            return cmd.Descripcion;
        }
    }
}
