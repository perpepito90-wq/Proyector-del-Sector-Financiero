namespace SistemaBancarioCore.Services.Caja
{
    /// <summary>
    /// RECEIVER. Contiene la lógica real de negocio (mover el saldo). Los comandos
    /// delegan en ella; no saben de historial ni de deshacer, solo aplican el cambio.
    /// </summary>
    public class CuentaCaja
    {
        public string Numero { get; }
        public decimal Saldo { get; private set; }

        public CuentaCaja(string numero, decimal saldoInicial)
        {
            Numero = numero;
            Saldo = saldoInicial;
        }

        public void Depositar(decimal monto) => Saldo += monto;

        public bool Retirar(decimal monto)
        {
            if (monto > Saldo) return false;   // fondos insuficientes
            Saldo -= monto;
            return true;
        }
    }
}
