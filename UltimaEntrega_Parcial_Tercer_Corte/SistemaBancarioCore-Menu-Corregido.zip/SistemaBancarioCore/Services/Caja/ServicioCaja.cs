namespace SistemaBancarioCore.Services.Caja
{
    /// <summary>Estado que se muestra en pantalla tras cada operación.</summary>
    public class ResultadoCaja
    {
        public string Cuenta { get; set; } = string.Empty;
        public decimal Saldo { get; set; }
        public List<string> Cola { get; set; } = new List<string>();
        public List<string> Historial { get; set; } = new List<string>();
        public bool PuedeDeshacer { get; set; }
        public string? Aviso { get; set; }
        public bool Invalido { get; set; }
    }

    /// <summary>
    /// CLIENT del patrón: crea los comandos y se los entrega al invocador. Mantiene
    /// en memoria (estático) la cuenta (receiver) y el invocador para que el saldo,
    /// el historial y la cola persistan entre peticiones.
    /// </summary>
    public class ServicioCaja
    {
        private static CuentaCaja _cuenta = null!;
        private static InvocadorCaja _invocador = null!;
        private static readonly object _lock = new object();
        private static bool _iniciado = false;

        public ServicioCaja()
        {
            lock (_lock)
            {
                if (!_iniciado) { Inicializar(); _iniciado = true; }
            }
        }

        private static void Inicializar()
        {
            _cuenta = new CuentaCaja("CTA-7000", 5_000_000m);
            _invocador = new InvocadorCaja();
        }

        private IComando Crear(string tipo, decimal monto, string? beneficiario) => tipo switch
        {
            "Retiro" => new ComandoRetiro(_cuenta, monto),
            "Transferencia" => new ComandoTransferencia(_cuenta, monto, beneficiario ?? ""),
            _ => new ComandoDeposito(_cuenta, monto)
        };

        public ResultadoCaja Estado(string? aviso = null, bool invalido = false) => new ResultadoCaja
        {
            Cuenta = _cuenta.Numero,
            Saldo = _cuenta.Saldo,
            Cola = _invocador.Cola.Select(c => c.Descripcion).ToList(),
            Historial = _invocador.Historial.Select(c => c.Descripcion).Reverse().ToList(),
            PuedeDeshacer = _invocador.PuedeDeshacer,
            Aviso = aviso,
            Invalido = invalido
        };

        public ResultadoCaja Enviar(string tipo, decimal monto, string modo, string? beneficiario)
        {
            lock (_lock)
            {
                if (monto <= 0) return Estado("El monto debe ser mayor que cero.", true);

                var cmd = Crear(tipo, monto, beneficiario);

                if (modo == "Encolar")
                {
                    _invocador.Encolar(cmd);
                    return Estado($"Encolado: {cmd.Descripcion}.");
                }

                return _invocador.EjecutarAhora(cmd)
                    ? Estado($"Ejecutado: {cmd.Descripcion}.")
                    : Estado("Fondos insuficientes: la operación no se aplicó.", true);
            }
        }

        public ResultadoCaja Procesar()
        {
            lock (_lock)
            {
                if (_invocador.Cola.Count == 0) return Estado("La cola está vacía.", true);
                var (ok, no) = _invocador.ProcesarCola();
                return Estado($"Cola procesada: {ok} aplicada(s), {no} rechazada(s) por fondos.");
            }
        }

        public ResultadoCaja Deshacer()
        {
            lock (_lock)
            {
                var desc = _invocador.DeshacerUltimo();
                return desc == null
                    ? Estado("No hay operaciones para deshacer.", true)
                    : Estado($"Deshecho: {desc}.");
            }
        }

        public ResultadoCaja Reiniciar()
        {
            lock (_lock)
            {
                Inicializar();
                return Estado("Caja reiniciada.");
            }
        }
    }
}
