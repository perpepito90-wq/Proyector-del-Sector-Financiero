namespace SistemaBancarioCore.Services.Caja
{
    /// <summary>
    /// COMMAND. Encapsula una operación de caja como un objeto, con lo necesario para
    /// ejecutarla y para deshacerla. Al ser un objeto, la operación se puede registrar,
    /// encolar y revertir, en lugar de ser una simple llamada a un método.
    /// </summary>
    public interface IComando
    {
        string Descripcion { get; }
        bool Aplicado { get; }
        void Ejecutar();
        void Deshacer();
    }
}
