namespace SistemaBancarioCore.Services.Parametros
{
    /// <summary>
    /// MEMENTO (vista pública / estrecha). Es lo único que ve el CARETAKER
    /// (el historial): solo metadatos para mostrar en pantalla. El estado real
    /// guardado queda oculto; únicamente el ORIGINADOR puede leerlo. Así el
    /// patrón Memento preserva el encapsulamiento.
    /// </summary>
    public interface IMementoConfiguracion
    {
        string Descripcion { get; }
        DateTime Fecha { get; }
    }
}
