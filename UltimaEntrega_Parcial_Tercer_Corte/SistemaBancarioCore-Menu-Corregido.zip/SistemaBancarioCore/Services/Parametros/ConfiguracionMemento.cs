namespace SistemaBancarioCore.Services.Parametros
{
    /// <summary>
    /// MEMENTO concreto. Guarda una "foto" inmutable del estado de los parámetros.
    /// Los valores capturados son de solo lectura y con acceso <c>internal</c>:
    /// solo el ORIGINADOR (misma biblioteca) puede leerlos para restaurar. El
    /// CARETAKER lo maneja a través de <see cref="IMementoConfiguracion"/> y nunca
    /// toca el estado interno.
    /// </summary>
    public sealed class ConfiguracionMemento : IMementoConfiguracion
    {
        public string Descripcion { get; }
        public DateTime Fecha { get; }

        // Estado capturado: visible solo dentro de la biblioteca (el Originador).
        internal decimal LimiteDiarioTransferencia { get; }
        internal decimal MontoMaximoOperacion { get; }
        internal decimal TasaInteresBase { get; }
        internal bool ModoMantenimiento { get; }

        internal ConfiguracionMemento(
            string descripcion,
            decimal limiteDiario,
            decimal montoMaximo,
            decimal tasaBase,
            bool modoMantenimiento)
        {
            Descripcion = descripcion;
            Fecha = DateTime.Now;
            LimiteDiarioTransferencia = limiteDiario;
            MontoMaximoOperacion = montoMaximo;
            TasaInteresBase = tasaBase;
            ModoMantenimiento = modoMantenimiento;
        }
    }
}
