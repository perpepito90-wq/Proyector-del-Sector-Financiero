using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.Parametros
{
    /// <summary>Estado que se muestra en pantalla tras cada operación.</summary>
    public class ResultadoParametros
    {
        public ParametrosOperativos Actual { get; set; } = new ParametrosOperativos();
        public IReadOnlyList<IMementoConfiguracion> Historial { get; set; } =
            new List<IMementoConfiguracion>();
        public string? Aviso { get; set; }
    }

    /// <summary>
    /// Orquesta el ORIGINADOR (parámetros actuales) y el CARETAKER (historial de
    /// puntos de restauración). Se mantiene en memoria (estático) para que los
    /// puntos sobrevivan entre peticiones y la restauración sea demostrable.
    /// </summary>
    public class ServicioParametros
    {
        // Único estado vivo del sistema + su historial de restauración.
        private static readonly ParametrosOperativos _originador = new ParametrosOperativos();
        private static readonly HistorialConfiguracion _historial = new HistorialConfiguracion();
        private static readonly object _lock = new object();
        private static bool _iniciado = false;

        public ServicioParametros()
        {
            lock (_lock)
            {
                if (!_iniciado)
                {
                    // Primer punto: el estado inicial, para poder volver a él siempre.
                    _historial.Guardar(_originador.CrearMemento("Estado inicial"));
                    _iniciado = true;
                }
            }
        }

        public ResultadoParametros Estado(string? aviso = null) => new ResultadoParametros
        {
            Actual = _originador,
            Historial = _historial.Puntos,
            Aviso = aviso
        };

        /// <summary>
        /// Guarda el estado ACTUAL como punto de restauración (MEMENTO) y luego aplica
        /// los nuevos valores. Así cualquier cambio se puede deshacer.
        /// </summary>
        public ResultadoParametros Aplicar(
            decimal limiteDiario, decimal montoMaximo, decimal tasaBase,
            bool modoMantenimiento, string? etiqueta)
        {
            lock (_lock)
            {
                var desc = string.IsNullOrWhiteSpace(etiqueta)
                    ? $"Estado previo — {DateTime.Now:HH:mm:ss}"
                    : etiqueta.Trim();

                _historial.Guardar(_originador.CrearMemento(desc));

                _originador.LimiteDiarioTransferencia = limiteDiario;
                _originador.MontoMaximoOperacion = montoMaximo;
                _originador.TasaInteresBase = tasaBase;
                _originador.ModoMantenimiento = modoMantenimiento;

                Logger.Instancia.Auditoria(
                    $"Parámetros: cambios aplicados. Punto de restauración guardado: '{desc}'");
            }
            return Estado("Cambios aplicados. Se guardó un punto de restauración.");
        }

        /// <summary>Restaura el estado desde un punto del historial (CARETAKER → ORIGINADOR).</summary>
        public ResultadoParametros Restaurar(int indice)
        {
            lock (_lock)
            {
                var memento = _historial.Obtener(indice);
                if (memento == null)
                    return Estado("No se encontró el punto de restauración indicado.");

                _originador.Restaurar(memento);
                Logger.Instancia.Auditoria(
                    $"Parámetros: estado restaurado al punto '{memento.Descripcion}'");
                return Estado($"Estado restaurado a: «{memento.Descripcion}».");
            }
        }
    }
}
