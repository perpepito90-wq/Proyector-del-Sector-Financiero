namespace SistemaBancarioCore.Services.Parametros
{
    /// <summary>
    /// CARETAKER. Custodia la lista de MEMENTOS (puntos de restauración) sin conocer
    /// ni modificar su contenido: solo los guarda y los devuelve. Trabaja con la
    /// interfaz estrecha <see cref="IMementoConfiguracion"/>.
    /// </summary>
    public class HistorialConfiguracion
    {
        private readonly List<IMementoConfiguracion> _puntos = new List<IMementoConfiguracion>();

        public IReadOnlyList<IMementoConfiguracion> Puntos => _puntos;

        public void Guardar(IMementoConfiguracion memento) => _puntos.Add(memento);

        public IMementoConfiguracion? Obtener(int indice) =>
            indice >= 0 && indice < _puntos.Count ? _puntos[indice] : null;
    }
}
