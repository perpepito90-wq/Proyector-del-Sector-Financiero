namespace SistemaBancarioCore.Services.Parametros
{
    /// <summary>
    /// ORIGINADOR. Mantiene los parámetros operativos del banco (su estado actual)
    /// y es el único que sabe crear un MEMENTO con ese estado y restaurarse a partir
    /// de uno. Nadie más conoce la estructura interna que se guarda.
    /// </summary>
    public class ParametrosOperativos
    {
        public decimal LimiteDiarioTransferencia { get; set; } = 20_000_000m;
        public decimal MontoMaximoOperacion { get; set; } = 5_000_000m;
        public decimal TasaInteresBase { get; set; } = 1.8m;
        public bool ModoMantenimiento { get; set; } = false;

        /// <summary>Crea una foto inmutable del estado actual (MEMENTO).</summary>
        public ConfiguracionMemento CrearMemento(string descripcion)
        {
            return new ConfiguracionMemento(
                descripcion,
                LimiteDiarioTransferencia,
                MontoMaximoOperacion,
                TasaInteresBase,
                ModoMantenimiento);
        }

        /// <summary>Restaura el estado desde un MEMENTO previamente guardado.</summary>
        public void Restaurar(IMementoConfiguracion memento)
        {
            if (memento is not ConfiguracionMemento m)
                throw new InvalidOperationException("Memento de tipo no reconocido.");

            LimiteDiarioTransferencia = m.LimiteDiarioTransferencia;
            MontoMaximoOperacion = m.MontoMaximoOperacion;
            TasaInteresBase = m.TasaInteresBase;
            ModoMantenimiento = m.ModoMantenimiento;
        }
    }
}
