namespace SistemaBancarioCore.Services.Movimientos
{
    /// <summary>
    /// ITERATOR. Define el acceso secuencial a los movimientos sin exponer cómo
    /// están almacenados ni en qué orden. El cliente solo pregunta si hay otro
    /// elemento y pide el siguiente.
    /// </summary>
    public interface IIteradorMovimientos
    {
        bool HaySiguiente();
        Movimiento Siguiente();
        void Reiniciar();
    }
}
