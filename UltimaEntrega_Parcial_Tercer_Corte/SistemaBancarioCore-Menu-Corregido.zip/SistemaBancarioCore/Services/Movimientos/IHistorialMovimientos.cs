namespace SistemaBancarioCore.Services.Movimientos
{
    /// <summary>
    /// AGGREGATE. La colección de movimientos sabe entregar un iterador sobre sí
    /// misma. El cliente nunca accede a la lista interna: pide un iterador y lo
    /// recorre. Según el criterio, devuelve un iterador concreto distinto (mismo
    /// historial, distintos recorridos).
    /// </summary>
    public interface IHistorialMovimientos
    {
        IIteradorMovimientos CrearIterador(string criterio);
        int Cantidad { get; }
    }
}
