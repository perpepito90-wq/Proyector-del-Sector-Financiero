namespace SistemaBancarioCore.Services.Movimientos
{
    // ============================================================================
    //  ITERADORES CONCRETOS. Cada uno encapsula una forma de recorrer el mismo
    //  historial. Reciben la lista desde el AGGREGATE (detalle interno entre la
    //  colección y su iterador); el cliente nunca la ve.
    // ============================================================================

    /// <summary>Recorre los movimientos en orden cronológico (por fecha).</summary>
    public class IteradorCronologico : IIteradorMovimientos
    {
        private readonly List<Movimiento> _items;
        private int _pos;

        public IteradorCronologico(List<Movimiento> movimientos)
        {
            _items = movimientos.OrderBy(m => m.Fecha).ToList();
        }

        public bool HaySiguiente() => _pos < _items.Count;
        public Movimiento Siguiente() => _items[_pos++];
        public void Reiniciar() => _pos = 0;
    }

    /// <summary>Recorre los movimientos de mayor a menor monto.</summary>
    public class IteradorPorMonto : IIteradorMovimientos
    {
        private readonly List<Movimiento> _items;
        private int _pos;

        public IteradorPorMonto(List<Movimiento> movimientos)
        {
            _items = movimientos.OrderByDescending(m => m.Monto).ToList();
        }

        public bool HaySiguiente() => _pos < _items.Count;
        public Movimiento Siguiente() => _items[_pos++];
        public void Reiniciar() => _pos = 0;
    }

    /// <summary>Recorre solo los movimientos de un tipo (Crédito o Débito), por fecha.</summary>
    public class IteradorPorTipo : IIteradorMovimientos
    {
        private readonly List<Movimiento> _items;
        private int _pos;

        public IteradorPorTipo(List<Movimiento> movimientos, string tipo)
        {
            _items = movimientos.Where(m => m.Tipo == tipo).OrderBy(m => m.Fecha).ToList();
        }

        public bool HaySiguiente() => _pos < _items.Count;
        public Movimiento Siguiente() => _items[_pos++];
        public void Reiniciar() => _pos = 0;
    }
}
