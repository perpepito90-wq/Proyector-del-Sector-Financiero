using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.Movimientos
{
    /// <summary>
    /// Arma un historial de movimientos de ejemplo para una cuenta y lo recorre
    /// con el iterador elegido. El cliente (controlador/UI) nunca toca la lista:
    /// solo pide un iterador y lo recorre.
    /// </summary>
    public class ServicioMovimientos
    {
        public IHistorialMovimientos ObtenerHistorial(string numeroCuenta)
        {
            var rnd = new Random((numeroCuenta ?? "CTA").GetHashCode() & 0x7FFFFFFF);
            var lista = new List<Movimiento>();
            decimal saldo = 2_000_000m;

            string[] credito = { "Depósito en efectivo", "Transferencia recibida", "Abono de nómina", "Reintegro" };
            string[] debito  = { "Retiro en cajero", "Pago de servicios", "Compra con tarjeta", "Transferencia enviada" };
            var fecha = DateTime.Now.Date.AddDays(-20);

            for (int i = 0; i < 12; i++)
            {
                fecha = fecha.AddDays(rnd.Next(1, 3));
                bool esCredito = rnd.Next(2) == 0;
                decimal monto = rnd.Next(1, 40) * 50_000m;
                saldo += esCredito ? monto : -monto;

                lista.Add(new Movimiento
                {
                    Fecha = fecha,
                    Tipo = esCredito ? "Crédito" : "Débito",
                    Descripcion = esCredito ? credito[rnd.Next(credito.Length)] : debito[rnd.Next(debito.Length)],
                    Monto = monto,
                    SaldoResultante = saldo
                });
            }

            Logger.Instancia.Info($"Historial de movimientos generado para la cuenta {numeroCuenta} ({lista.Count} movimientos)");
            return new HistorialMovimientos(lista);
        }

        /// <summary>Recorre el historial con el iterador del criterio dado.</summary>
        public List<Movimiento> Recorrer(IHistorialMovimientos historial, string criterio)
        {
            var resultado = new List<Movimiento>();
            IIteradorMovimientos it = historial.CrearIterador(criterio);
            while (it.HaySiguiente())
                resultado.Add(it.Siguiente());
            return resultado;
        }
    }
}
