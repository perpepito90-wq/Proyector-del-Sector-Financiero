namespace SistemaBancarioCore.Services.Movimientos
{
    /// <summary>
    /// Elemento de la colección: un movimiento (asiento) de una cuenta.
    /// </summary>
    public class Movimiento
    {
        public DateTime Fecha { get; set; }
        public string Tipo { get; set; } = "Débito";      // Débito | Crédito
        public string Descripcion { get; set; } = string.Empty;
        public decimal Monto { get; set; }
        public decimal SaldoResultante { get; set; }
    }
}
