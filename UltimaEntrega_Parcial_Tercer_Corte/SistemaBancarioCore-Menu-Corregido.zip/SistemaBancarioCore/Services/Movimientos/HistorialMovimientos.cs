namespace SistemaBancarioCore.Services.Movimientos
{
    /// <summary>
    /// AGGREGATE CONCRETO. Guarda la colección de movimientos y es el único que
    /// conoce la lista interna. Entrega el iterador concreto que corresponda al
    /// criterio pedido, sin exponer la lista.
    /// </summary>
    public class HistorialMovimientos : IHistorialMovimientos
    {
        private readonly List<Movimiento> _movimientos;

        public HistorialMovimientos(List<Movimiento> movimientos)
        {
            _movimientos = movimientos ?? new List<Movimiento>();
        }

        public int Cantidad => _movimientos.Count;

        public IIteradorMovimientos CrearIterador(string criterio)
        {
            return (criterio ?? string.Empty).Trim().ToLowerInvariant() switch
            {
                "monto"    => new IteradorPorMonto(_movimientos),
                "creditos" => new IteradorPorTipo(_movimientos, "Crédito"),
                "debitos"  => new IteradorPorTipo(_movimientos, "Débito"),
                _          => new IteradorCronologico(_movimientos),
            };
        }
    }
}
