namespace SistemaBancarioCore.Services.Amortizacion
{
    /// <summary>
    /// STRATEGY. Define la familia de algoritmos de amortización. Cada estrategia
    /// concreta calcula el plan de pagos de una forma distinta, pero todas son
    /// intercambiables: reciben los mismos datos y devuelven un PlanPago.
    /// </summary>
    public interface IEstrategiaAmortizacion
    {
        string Nombre { get; }
        string Descripcion { get; }
        PlanPago Calcular(decimal monto, decimal tasaMensual, int plazoMeses);
    }
}
