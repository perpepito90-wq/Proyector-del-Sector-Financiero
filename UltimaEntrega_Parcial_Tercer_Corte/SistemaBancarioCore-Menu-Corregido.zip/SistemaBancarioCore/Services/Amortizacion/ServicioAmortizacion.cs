using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.Amortizacion
{
    /// <summary>Una fila de la comparativa entre estrategias.</summary>
    public class ComparativaItem
    {
        public string Clave { get; set; } = string.Empty;
        public string Nombre { get; set; } = string.Empty;
        public decimal TotalPagado { get; set; }
        public decimal TotalIntereses { get; set; }
        public bool Seleccionada { get; set; }
    }

    /// <summary>Estado que se muestra en pantalla tras una simulación.</summary>
    public class ResultadoAmortizacion
    {
        public decimal Monto { get; set; }
        public decimal TasaMensual { get; set; }
        public int PlazoMeses { get; set; }
        public string EstrategiaClave { get; set; } = "Frances";
        public string EstrategiaNombre { get; set; } = string.Empty;
        public string EstrategiaDescripcion { get; set; } = string.Empty;
        public PlanPago? Plan { get; set; }
        public List<ComparativaItem> Comparativa { get; set; } = new List<ComparativaItem>();
        public string? Aviso { get; set; }
        public bool Invalido { get; set; }
    }

    /// <summary>
    /// Cliente del patrón: elige la estrategia según la clave recibida, la pone en el
    /// simulador (contexto) y calcula. También arma una comparativa aplicando las tres
    /// estrategias a los mismos datos, para evidenciar que son intercambiables.
    /// </summary>
    public class ServicioAmortizacion
    {
        private static readonly Dictionary<string, Func<IEstrategiaAmortizacion>> _estrategias =
            new Dictionary<string, Func<IEstrategiaAmortizacion>>
            {
                ["Frances"] = () => new EstrategiaFrances(),
                ["Aleman"] = () => new EstrategiaAleman(),
                ["Global"] = () => new EstrategiaInteresGlobal()
            };

        public ResultadoAmortizacion Simular(string clave, decimal monto, decimal tasaMensual, int plazoMeses)
        {
            if (!_estrategias.ContainsKey(clave)) clave = "Frances";

            var r = new ResultadoAmortizacion
            {
                Monto = monto, TasaMensual = tasaMensual, PlazoMeses = plazoMeses, EstrategiaClave = clave
            };

            if (monto <= 0 || plazoMeses < 1 || plazoMeses > 60 || tasaMensual < 0)
            {
                r.Aviso = "Revisa los datos: monto mayor que cero, plazo entre 1 y 60 meses y tasa no negativa.";
                r.Invalido = true;
                return r;
            }

            // CONTEXT con la estrategia elegida.
            var simulador = new SimuladorCredito(_estrategias[clave]());
            var plan = simulador.Simular(monto, tasaMensual, plazoMeses);
            r.Plan = plan;
            r.EstrategiaNombre = plan.Estrategia;
            r.EstrategiaDescripcion = _estrategias[clave]().Descripcion;

            // Comparativa: la misma entrada con cada estrategia (intercambiables).
            foreach (var kv in _estrategias)
            {
                var p = kv.Value().Calcular(monto, tasaMensual, plazoMeses);
                r.Comparativa.Add(new ComparativaItem
                {
                    Clave = kv.Key, Nombre = p.Estrategia,
                    TotalPagado = p.TotalPagado, TotalIntereses = p.TotalIntereses,
                    Seleccionada = kv.Key == clave
                });
            }

            Logger.Instancia.Auditoria(
                $"Amortización: simulación {plan.Estrategia} monto {monto:N0}, {plazoMeses} meses, cuota total {plan.TotalPagado:N0}");
            return r;
        }
    }
}
