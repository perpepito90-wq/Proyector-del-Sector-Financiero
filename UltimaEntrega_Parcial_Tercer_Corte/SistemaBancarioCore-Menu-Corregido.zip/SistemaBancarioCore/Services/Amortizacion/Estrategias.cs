namespace SistemaBancarioCore.Services.Amortizacion
{
    /// <summary>Utilidades comunes a las estrategias.</summary>
    internal static class Amort
    {
        public static decimal R(decimal x) => Math.Round(x, 0, MidpointRounding.AwayFromZero);

        public static PlanPago Totalizar(string nombre, List<Cuota> cuotas, decimal monto)
        {
            var total = cuotas.Sum(c => c.Valor);
            return new PlanPago
            {
                Estrategia = nombre,
                Cuotas = cuotas,
                TotalPagado = total,
                TotalIntereses = total - monto
            };
        }
    }

    /// <summary>
    /// STRATEGY concreto: sistema francés (cuota fija). La cuota es constante; al
    /// principio se paga más interés y menos capital.
    /// </summary>
    public class EstrategiaFrances : IEstrategiaAmortizacion
    {
        public string Nombre => "Francés (cuota fija)";
        public string Descripcion => "Cuota constante durante todo el plazo.";

        public PlanPago Calcular(decimal monto, decimal tasaMensual, int plazoMeses)
        {
            var i = tasaMensual / 100m;
            decimal cuota = i == 0
                ? monto / plazoMeses
                : monto * i / (1 - (decimal)Math.Pow((double)(1 + i), -plazoMeses));
            cuota = Amort.R(cuota);

            var cuotas = new List<Cuota>();
            var saldo = monto;
            for (int k = 1; k <= plazoMeses; k++)
            {
                var interes = Amort.R(saldo * i);
                var abono = k == plazoMeses ? saldo : cuota - interes;
                var valor = interes + abono;
                saldo -= abono;
                cuotas.Add(new Cuota { Numero = k, Valor = valor, Interes = interes, Abono = abono, Saldo = saldo < 0 ? 0 : saldo });
            }
            return Amort.Totalizar(Nombre, cuotas, monto);
        }
    }

    /// <summary>
    /// STRATEGY concreto: sistema alemán (abono constante a capital). El abono a
    /// capital es fijo y la cuota baja mes a mes porque el interés disminuye.
    /// </summary>
    public class EstrategiaAleman : IEstrategiaAmortizacion
    {
        public string Nombre => "Alemán (abono constante)";
        public string Descripcion => "Abono a capital fijo; la cuota disminuye cada mes.";

        public PlanPago Calcular(decimal monto, decimal tasaMensual, int plazoMeses)
        {
            var i = tasaMensual / 100m;
            var abonoFijo = Amort.R(monto / plazoMeses);

            var cuotas = new List<Cuota>();
            var saldo = monto;
            for (int k = 1; k <= plazoMeses; k++)
            {
                var interes = Amort.R(saldo * i);
                var abono = k == plazoMeses ? saldo : abonoFijo;
                var valor = interes + abono;
                saldo -= abono;
                cuotas.Add(new Cuota { Numero = k, Valor = valor, Interes = interes, Abono = abono, Saldo = saldo < 0 ? 0 : saldo });
            }
            return Amort.Totalizar(Nombre, cuotas, monto);
        }
    }

    /// <summary>
    /// STRATEGY concreto: interés global (simple). El interés se calcula sobre el
    /// monto inicial por todo el plazo; la cuota es plana pero resulta más costosa.
    /// </summary>
    public class EstrategiaInteresGlobal : IEstrategiaAmortizacion
    {
        public string Nombre => "Interés global";
        public string Descripcion => "Interés simple sobre el monto inicial; cuota plana.";

        public PlanPago Calcular(decimal monto, decimal tasaMensual, int plazoMeses)
        {
            var i = tasaMensual / 100m;
            var interesTotal = monto * i * plazoMeses;
            var abonoBase = Amort.R(monto / plazoMeses);
            var interesMes = Amort.R(interesTotal / plazoMeses);

            var cuotas = new List<Cuota>();
            var saldo = monto;
            for (int k = 1; k <= plazoMeses; k++)
            {
                var abono = k == plazoMeses ? saldo : abonoBase;
                var valor = abono + interesMes;
                saldo -= abono;
                cuotas.Add(new Cuota { Numero = k, Valor = valor, Interes = interesMes, Abono = abono, Saldo = saldo < 0 ? 0 : saldo });
            }
            return Amort.Totalizar(Nombre, cuotas, monto);
        }
    }
}
