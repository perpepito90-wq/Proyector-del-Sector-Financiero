namespace SistemaBancarioCore.Services.Amortizacion
{
    /// <summary>Una cuota del plan de pagos.</summary>
    public class Cuota
    {
        public int Numero { get; set; }
        public decimal Valor { get; set; }
        public decimal Interes { get; set; }
        public decimal Abono { get; set; }     // abono a capital
        public decimal Saldo { get; set; }      // saldo restante tras la cuota
    }

    /// <summary>Resultado del cálculo de una estrategia: el plan completo y sus totales.</summary>
    public class PlanPago
    {
        public string Estrategia { get; set; } = string.Empty;
        public List<Cuota> Cuotas { get; set; } = new List<Cuota>();
        public decimal TotalPagado { get; set; }
        public decimal TotalIntereses { get; set; }
    }
}
