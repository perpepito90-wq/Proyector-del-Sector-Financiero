namespace SistemaBancarioCore.Services.Amortizacion
{
    /// <summary>
    /// CONTEXT. El simulador mantiene una referencia a una estrategia de amortización
    /// y le delega el cálculo del plan. Puede cambiar de estrategia en tiempo de
    /// ejecución sin que cambie el resto de su código.
    /// </summary>
    public class SimuladorCredito
    {
        private IEstrategiaAmortizacion _estrategia;

        public SimuladorCredito(IEstrategiaAmortizacion estrategia) => _estrategia = estrategia;

        public string EstrategiaActual => _estrategia.Nombre;

        public void CambiarEstrategia(IEstrategiaAmortizacion estrategia) => _estrategia = estrategia;

        public PlanPago Simular(decimal monto, decimal tasaMensual, int plazoMeses) =>
            _estrategia.Calcular(monto, tasaMensual, plazoMeses);
    }
}
