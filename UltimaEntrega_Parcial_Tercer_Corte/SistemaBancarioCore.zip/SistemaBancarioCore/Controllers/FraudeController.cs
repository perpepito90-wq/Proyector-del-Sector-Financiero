using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Banca;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Detección de fraude en tiempo real. El motor antifraude aplica una lista de reglas
    /// de riesgo a cada transacción; esta pantalla muestra las alertas generadas y permite
    /// simular la evaluación de una transacción para ver qué reglas se disparan.
    /// </summary>
    [Authorize]
    public class FraudeController : Controller
    {
        private readonly ServicioBanca _svc;
        public FraudeController(ServicioBanca svc) => _svc = svc;

        private void Cargar()
        {
            ViewData["alertas"] = _svc.AlertasFraude();
            ViewData["reglas"] = _svc.ReglasAntifraude;
            ViewData["cuentas"] = _svc.Cuentas();
        }

        public IActionResult Index()
        {
            Cargar();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Evaluar(int cuentaId, string tipo, decimal monto, int? hora)
        {
            var (resultado, numero) = _svc.EvaluarSimulacion(cuentaId, tipo ?? "Retiro", monto, hora);
            Cargar();
            ViewData["sim"] = resultado;
            ViewData["simCuenta"] = numero;
            ViewData["simTipo"] = tipo;
            ViewData["simMonto"] = monto;
            return View("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult MarcarRevisada(int id)
        {
            _svc.MarcarRevisada(id);
            TempData["aviso"] = "Alerta marcada como revisada.";
            return RedirectToAction("Index");
        }
    }
}
