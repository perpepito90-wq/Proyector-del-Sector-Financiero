namespace SistemaBancarioCore.Services.Fraude
{
    /// <summary>
    /// Datos de la transacción que evalúan las reglas de fraude. Lleva la información de
    /// la operación, las estadísticas de la cuenta y los acumuladores (puntaje y motivos)
    /// que cada regla va completando.
    /// </summary>
    public class ContextoFraude
    {
        public int CuentaId { get; set; }
        public string CuentaNumero { get; set; } = string.Empty;
        public string Tipo { get; set; } = string.Empty;
        public decimal Monto { get; set; }
        public DateTime Fecha { get; set; } = DateTime.Now;

        // Estadísticas de la cuenta (las calcula el servicio desde la base de datos).
        public int MovimientosRecientes { get; set; }   // en los últimos minutos
        public decimal PromedioHistorico { get; set; }

        // Acumuladores que llenan las reglas.
        public int Puntaje { get; private set; }
        public List<string> Motivos { get; } = new List<string>();
        public bool Bloqueado { get; set; }

        public void Sumar(int puntos, string motivo)
        {
            Puntaje += puntos;
            Motivos.Add(motivo);
        }
    }

    /// <summary>Resultado de evaluar una transacción con el motor antifraude.</summary>
    public class ResultadoFraude
    {
        public string Decision { get; set; } = "Aprobada";   // Aprobada / Revisar / Bloqueada
        public int Puntaje { get; set; }
        public List<string> Motivos { get; set; } = new List<string>();
        public bool Bloqueado { get; set; }
    }
}
