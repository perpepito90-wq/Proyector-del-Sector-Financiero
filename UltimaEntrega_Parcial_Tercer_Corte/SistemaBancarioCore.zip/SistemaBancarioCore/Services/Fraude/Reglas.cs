namespace SistemaBancarioCore.Services.Fraude
{
    /// <summary>Regla dura: un retiro/transferencia por encima del límite crítico se bloquea.</summary>
    public class ReglaBloqueoCritico : IReglaFraude
    {
        public const decimal UmbralCritico = 20_000_000m;
        public string Nombre => "Bloqueo por límite crítico";
        public void Evaluar(ContextoFraude c)
        {
            if (c.Tipo != "Depósito" && c.Monto >= UmbralCritico)
            {
                c.Sumar(100, $"Supera el límite crítico de {UmbralCritico:N0}");
                c.Bloqueado = true;
            }
        }
    }

    /// <summary>Regla: monto alto en un retiro o transferencia.</summary>
    public class ReglaMontoAlto : IReglaFraude
    {
        public const decimal UmbralAlto = 5_000_000m;
        public string Nombre => "Monto alto";
        public void Evaluar(ContextoFraude c)
        {
            if (c.Tipo != "Depósito" && c.Monto >= UmbralAlto)
                c.Sumar(40, $"Monto alto (≥ {UmbralAlto:N0})");
        }
    }

    /// <summary>Regla: alta frecuencia de movimientos en poco tiempo.</summary>
    public class ReglaFrecuencia : IReglaFraude
    {
        public const int UmbralMovimientos = 3;
        public string Nombre => "Alta frecuencia";
        public void Evaluar(ContextoFraude c)
        {
            if (c.MovimientosRecientes >= UmbralMovimientos)
                c.Sumar(30, $"Alta frecuencia: {c.MovimientosRecientes} movimientos recientes");
        }
    }

    /// <summary>Regla: monto muy por encima del promedio histórico de la cuenta.</summary>
    public class ReglaMontoInusual : IReglaFraude
    {
        public string Nombre => "Monto inusual";
        public void Evaluar(ContextoFraude c)
        {
            if (c.PromedioHistorico > 0 && c.Monto > 3 * c.PromedioHistorico)
                c.Sumar(30, $"Monto inusual: supera 3× el promedio ({c.PromedioHistorico:N0})");
        }
    }

    /// <summary>Regla: transacción en horario inusual (madrugada).</summary>
    public class ReglaHorarioInusual : IReglaFraude
    {
        public string Nombre => "Horario inusual";
        public void Evaluar(ContextoFraude c)
        {
            if (c.Fecha.Hour < 6)
                c.Sumar(15, $"Horario inusual ({c.Fecha:HH:mm})");
        }
    }
}
