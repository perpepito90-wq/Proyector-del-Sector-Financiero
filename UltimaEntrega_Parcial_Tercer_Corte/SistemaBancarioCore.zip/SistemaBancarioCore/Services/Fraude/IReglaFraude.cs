namespace SistemaBancarioCore.Services.Fraude
{
    /// <summary>
    /// Regla de evaluación de riesgo de una transacción. Cada regla revisa el contexto
    /// y, si corresponde, suma puntaje de riesgo (y puede marcar la operación como
    /// bloqueada). El motor aplica todas las reglas configuradas.
    /// </summary>
    public interface IReglaFraude
    {
        string Nombre { get; }
        void Evaluar(ContextoFraude contexto);
    }
}
