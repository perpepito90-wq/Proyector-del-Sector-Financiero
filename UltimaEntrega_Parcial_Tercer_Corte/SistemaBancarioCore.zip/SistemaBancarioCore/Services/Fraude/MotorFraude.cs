namespace SistemaBancarioCore.Services.Fraude
{
    /// <summary>
    /// Motor de detección de fraude en tiempo real. Aplica una lista de reglas de riesgo
    /// sobre la transacción y, según el puntaje acumulado, decide si se aprueba, se marca
    /// para revisión o se bloquea.
    /// </summary>
    public class MotorFraude
    {
        private readonly List<IReglaFraude> _reglas;

        public MotorFraude()
        {
            _reglas = new List<IReglaFraude>
            {
                new ReglaBloqueoCritico(),
                new ReglaMontoAlto(),
                new ReglaFrecuencia(),
                new ReglaMontoInusual(),
                new ReglaHorarioInusual()
            };
        }

        public IReadOnlyList<string> ReglasConfiguradas => _reglas.Select(r => r.Nombre).ToList();

        public ResultadoFraude Evaluar(ContextoFraude ctx)
        {
            foreach (var regla in _reglas)
            {
                regla.Evaluar(ctx);
                if (ctx.Bloqueado) break;   // una regla dura detiene la evaluación
            }

            string decision =
                ctx.Bloqueado || ctx.Puntaje >= 70 ? "Bloqueada" :
                ctx.Puntaje >= 40 ? "Revisar" :
                "Aprobada";

            return new ResultadoFraude
            {
                Decision = decision,
                Puntaje = ctx.Puntaje,
                Motivos = new List<string>(ctx.Motivos),
                Bloqueado = ctx.Bloqueado
            };
        }
    }
}
