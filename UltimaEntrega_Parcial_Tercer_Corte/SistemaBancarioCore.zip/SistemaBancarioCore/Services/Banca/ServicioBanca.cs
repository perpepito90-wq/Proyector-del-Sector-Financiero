using SistemaBancarioCore.Models;
using SistemaBancarioCore.Services.Fraude;

namespace SistemaBancarioCore.Services.Banca
{
    /// <summary>
    /// Servicio de gestión bancaria con persistencia real en base de datos (EF Core).
    /// Administra cuentas, transacciones, préstamos e inversiones. Se inyecta por
    /// petición (scoped) con el DbContext y reutiliza el Logger (Singleton) para la
    /// auditoría, que es la base del cumplimiento (KYC/AML).
    /// </summary>
    public class ServicioBanca
    {
        private readonly UsuarioContext _db;
        private readonly MotorFraude _motor = new MotorFraude();   // motor de reglas antifraude
        public ServicioBanca(UsuarioContext db) => _db = db;

        // ---------------- Cuentas ----------------
        public List<Cuenta> Cuentas() => _db.Cuentas.OrderBy(c => c.Id).ToList();
        public Cuenta? Cuenta(int id) => _db.Cuentas.FirstOrDefault(c => c.Id == id);

        public Cuenta AbrirCuenta(string titular, string tipo, decimal montoInicial)
        {
            var prefijo = tipo == "Corriente" ? "COR" : "AHO";
            var cuenta = new Cuenta
            {
                Numero = $"{prefijo}-{(_db.Cuentas.Count() + 1):0000}",
                Titular = string.IsNullOrWhiteSpace(titular) ? "Sin nombre" : titular.Trim(),
                Tipo = tipo == "Corriente" ? "Corriente" : "Ahorros",
                Saldo = montoInicial < 0 ? 0 : montoInicial,
                Estado = "Activa",
                FechaApertura = DateTime.Now
            };
            _db.Cuentas.Add(cuenta);
            _db.SaveChanges();

            if (cuenta.Saldo > 0)
            {
                _db.Movimientos.Add(new MovimientoBancario
                {
                    CuentaId = cuenta.Id,
                    Fecha = DateTime.Now,
                    Tipo = "Depósito",
                    Descripcion = "Apertura de cuenta",
                    Monto = cuenta.Saldo,
                    SaldoResultante = cuenta.Saldo
                });
                _db.SaveChanges();
            }

            Logger.Instancia.Auditoria($"Banca: cuenta {cuenta.Numero} abierta para {cuenta.Titular} (saldo {cuenta.Saldo:N0})");
            return cuenta;
        }

        public (bool ok, string mensaje) RegistrarMovimiento(int cuentaId, string tipo, decimal monto, string? descripcion)
        {
            var cuenta = Cuenta(cuentaId);
            if (cuenta == null) return (false, "La cuenta no existe.");
            if (cuenta.Estado != "Activa") return (false, $"La cuenta está {cuenta.Estado}; no admite movimientos.");
            if (monto <= 0) return (false, "El monto debe ser mayor que cero.");

            // --- Evaluación antifraude en tiempo real (reglas de riesgo) ---
            var resultado = _motor.Evaluar(ConstruirContexto(cuenta, tipo, monto, DateTime.Now));
            if (resultado.Decision == "Bloqueada")
            {
                GuardarAlerta(cuenta, tipo, monto, resultado);
                Logger.Instancia.Auditoria($"Fraude: transacción BLOQUEADA en {cuenta.Numero} (puntaje {resultado.Puntaje})");
                return (false, "Transacción bloqueada por el motor antifraude: " + string.Join("; ", resultado.Motivos));
            }

            // --- Fondos y aplicación ---
            if (tipo == "Depósito")
            {
                cuenta.Saldo += monto;
            }
            else // Retiro / Transferencia
            {
                if (monto > cuenta.Saldo) return (false, "Fondos insuficientes para la operación.");
                cuenta.Saldo -= monto;
            }

            _db.Movimientos.Add(new MovimientoBancario
            {
                CuentaId = cuenta.Id,
                Fecha = DateTime.Now,
                Tipo = tipo,
                Descripcion = string.IsNullOrWhiteSpace(descripcion) ? tipo : descripcion.Trim(),
                Monto = monto,
                SaldoResultante = cuenta.Saldo
            });
            _db.SaveChanges();

            Logger.Instancia.Auditoria($"Banca: {tipo} de {monto:N0} en {cuenta.Numero}. Saldo {cuenta.Saldo:N0}");
            var mensaje = $"{tipo} registrado. Nuevo saldo: {cuenta.Saldo:N0}.";
            if (resultado.Decision == "Revisar")
            {
                GuardarAlerta(cuenta, tipo, monto, resultado);
                mensaje += " ⚠ Marcada para revisión por el motor antifraude.";
            }
            return (true, mensaje);
        }

        // ---------------- Detección de fraude ----------------
        public IReadOnlyList<string> ReglasAntifraude => _motor.ReglasConfiguradas;

        public List<AlertaFraude> AlertasFraude() => _db.AlertasFraude.OrderByDescending(a => a.Id).ToList();

        /// <summary>Evalúa una transacción sin aplicarla (simulador de la pantalla de fraude).</summary>
        public (ResultadoFraude resultado, string cuentaNumero) EvaluarSimulacion(int cuentaId, string tipo, decimal monto, int? hora)
        {
            var cuenta = Cuenta(cuentaId);
            var fecha = hora.HasValue ? DateTime.Today.AddHours(hora.Value) : DateTime.Now;
            var ctx = ConstruirContexto(cuenta, tipo, monto, fecha, cuentaId);
            return (_motor.Evaluar(ctx), cuenta?.Numero ?? "(cuenta no encontrada)");
        }

        public void MarcarRevisada(int id)
        {
            var a = _db.AlertasFraude.FirstOrDefault(x => x.Id == id);
            if (a != null)
            {
                a.Estado = "Revisada";
                _db.SaveChanges();
                Logger.Instancia.Auditoria($"Fraude: alerta {a.Id} marcada como revisada");
            }
        }

        private ContextoFraude ConstruirContexto(Cuenta? cuenta, string tipo, decimal monto, DateTime fecha, int? cuentaIdOverride = null)
        {
            int cuentaId = cuenta?.Id ?? cuentaIdOverride ?? 0;
            int recientes = cuentaId == 0 ? 0 : _db.Movimientos.Count(m => m.CuentaId == cuentaId && m.Fecha >= DateTime.Now.AddMinutes(-10));
            var montos = cuentaId == 0 ? new List<decimal>() : _db.Movimientos.Where(m => m.CuentaId == cuentaId).Select(m => m.Monto).ToList();
            decimal promedio = montos.Count > 0 ? montos.Average() : 0m;
            return new ContextoFraude
            {
                CuentaId = cuentaId,
                CuentaNumero = cuenta?.Numero ?? "(cuenta nueva)",
                Tipo = tipo,
                Monto = monto,
                Fecha = fecha,
                MovimientosRecientes = recientes,
                PromedioHistorico = promedio
            };
        }

        private void GuardarAlerta(Cuenta cuenta, string tipo, decimal monto, ResultadoFraude r)
        {
            _db.AlertasFraude.Add(new AlertaFraude
            {
                CuentaId = cuenta.Id,
                CuentaNumero = cuenta.Numero,
                Fecha = DateTime.Now,
                Tipo = tipo,
                Monto = monto,
                Puntaje = r.Puntaje,
                Decision = r.Decision,
                Motivos = r.Motivos.Count > 0 ? string.Join("; ", r.Motivos) : "—",
                Estado = "Pendiente"
            });
            _db.SaveChanges();
        }

        public List<MovimientoBancario> Movimientos(int cuentaId) =>
            _db.Movimientos.Where(m => m.CuentaId == cuentaId)
                           .OrderBy(m => m.Fecha).ThenBy(m => m.Id).ToList();

        // ---------------- Préstamos ----------------
        public List<PrestamoBancario> Prestamos() => _db.Prestamos.OrderBy(p => p.Id).ToList();

        public PrestamoBancario CrearPrestamo(string titular, decimal monto, decimal tasaMensual, int plazoMeses)
        {
            var prestamo = new PrestamoBancario
            {
                Numero = $"PRE-{(_db.Prestamos.Count() + 1):0000}",
                Titular = string.IsNullOrWhiteSpace(titular) ? "Sin nombre" : titular.Trim(),
                Monto = monto,
                TasaMensual = tasaMensual,
                PlazoMeses = plazoMeses,
                Estado = "Radicada",
                FechaSolicitud = DateTime.Now
            };
            _db.Prestamos.Add(prestamo);
            _db.SaveChanges();
            Logger.Instancia.Auditoria($"Banca: préstamo {prestamo.Numero} radicado para {prestamo.Titular} (monto {prestamo.Monto:N0})");
            return prestamo;
        }

        // ---------------- Inversiones ----------------
        public List<Inversion> Inversiones() => _db.Inversiones.OrderBy(i => i.Id).ToList();

        public Inversion CrearInversion(string titular, decimal monto, decimal tasaAnual, int plazoMeses)
        {
            var inversion = new Inversion
            {
                Numero = $"CDT-{(_db.Inversiones.Count() + 1):0000}",
                Titular = string.IsNullOrWhiteSpace(titular) ? "Sin nombre" : titular.Trim(),
                Monto = monto,
                TasaAnual = tasaAnual,
                PlazoMeses = plazoMeses,
                FechaApertura = DateTime.Now
            };
            _db.Inversiones.Add(inversion);
            _db.SaveChanges();
            Logger.Instancia.Auditoria($"Banca: inversión {inversion.Numero} abierta para {inversion.Titular} (monto {inversion.Monto:N0})");
            return inversion;
        }
    }
}
