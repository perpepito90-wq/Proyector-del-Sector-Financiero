using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Models;
using SistemaBancarioCore.Services;
using SistemaBancarioCore.Services.Notificaciones;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Permite ver y modificar la configuracion SMTP desde el navegador, sin tener
    /// que editar la tabla a mano. Solo accesible para usuarios autenticados.
    /// </summary>
    [Authorize]
    public class ConfiguracionCorreoController : Controller
    {
        private readonly UsuarioContext _context;

        public ConfiguracionCorreoController(UsuarioContext context)
        {
            _context = context;
        }

        // GET: muestra el formulario con la configuracion activa. Si aun no existe
        // ninguna, presenta valores por defecto de Gmail.
        public IActionResult Index()
        {
            ConfiguracionCorreo? config =
                _context.ConfiguracionesCorreo.FirstOrDefault(c => c.Activo)
                ?? _context.ConfiguracionesCorreo.FirstOrDefault();

            if (config == null)
            {
                config = new ConfiguracionCorreo
                {
                    Host = "smtp.gmail.com",
                    Puerto = 587,
                    UsarSsl = true,
                    Activo = true,
                    NombreRemitente = "Sistema Bancario Core"
                };
            }

            // Por seguridad no se muestra la clave en el formulario.
            config.ClaveAplicacion = string.Empty;

            return View(config);
        }

        // POST: crea o actualiza la configuracion.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Guardar(ConfiguracionCorreo modelo)
        {
            if (modelo.Id == 0)
            {
                // Nueva configuracion.
                modelo.Activo = true;
                _context.ConfiguracionesCorreo.Add(modelo);
            }
            else
            {
                ConfiguracionCorreo? existente = _context.ConfiguracionesCorreo.Find(modelo.Id);
                if (existente == null)
                {
                    TempData["Error"] = "No se encontro la configuracion a actualizar.";
                    return RedirectToAction("Index");
                }

                existente.Host = modelo.Host;
                existente.Puerto = modelo.Puerto;
                existente.CorreoRemitente = modelo.CorreoRemitente;
                existente.NombreRemitente = modelo.NombreRemitente;
                existente.UsarSsl = modelo.UsarSsl;
                existente.Activo = modelo.Activo;

                // La clave solo se reemplaza si el usuario escribio una nueva. Si el
                // campo llega vacio, se conserva la que ya estaba guardada.
                if (!string.IsNullOrWhiteSpace(modelo.ClaveAplicacion))
                    existente.ClaveAplicacion = modelo.ClaveAplicacion;
            }

            _context.SaveChanges();
            Logger.Instancia.Auditoria("Configuracion SMTP actualizada desde la aplicacion");

            TempData["Mensaje"] = "Configuracion guardada correctamente.";
            return RedirectToAction("Index");
        }

        // POST: envia un correo de prueba usando la configuracion activa.
        // Reutiliza el patron Factory Method (ServicioNotificacionEmail).
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Probar(string? correoPrueba)
        {
            ConfiguracionCorreo? config = _context.ConfiguracionesCorreo.FirstOrDefault(c => c.Activo);

            if (config == null)
            {
                TempData["Error"] = "Primero guarda una configuracion de correo.";
                return RedirectToAction("Index");
            }

            // Si no se indica destino, se envia al propio correo remitente.
            string destino = string.IsNullOrWhiteSpace(correoPrueba) ? config.CorreoRemitente : correoPrueba;

            ServicioNotificacion notificacion = new ServicioNotificacionEmail(config);
            ResultadoNotificacion resultado = notificacion.Notificar(
                destino,
                "Correo de prueba - Sistema Bancario Core",
                "Este es un correo de prueba. Si lo recibes, la configuracion SMTP funciona correctamente.");

            if (resultado.Exito)
                TempData["Mensaje"] = $"Correo de prueba enviado a {destino}.";
            else
                TempData["Error"] = $"No se pudo enviar el correo de prueba: {resultado.Detalle}";

            return RedirectToAction("Index");
        }
    }
}
