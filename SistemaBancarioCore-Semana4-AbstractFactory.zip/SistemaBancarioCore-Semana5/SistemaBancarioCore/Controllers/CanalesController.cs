using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Models;
using SistemaBancarioCore.Services.Canales;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Pagina para enviar un aviso a traves de un canal de atencion. Demuestra el
    /// patron Abstract Factory: segun el canal elegido se usa una familia coherente
    /// de piezas (formateador + notificador).
    /// </summary>
    [Authorize]
    public class CanalesController : Controller
    {
        private readonly UsuarioContext _context;

        public CanalesController(UsuarioContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Enviar(string canal, string destinatario, string titulo, string mensaje)
        {
            if (string.IsNullOrWhiteSpace(canal) || string.IsNullOrWhiteSpace(destinatario)
                || string.IsNullOrWhiteSpace(titulo) || string.IsNullOrWhiteSpace(mensaje))
            {
                TempData["Error"] = "Completa el canal, el destinatario, el titulo y el mensaje.";
                return RedirectToAction("Index");
            }

            try
            {
                // El canal Web usa correo, por lo que necesita la configuracion SMTP activa.
                ConfiguracionCorreo? configCorreo = _context.ConfiguracionesCorreo.FirstOrDefault(c => c.Activo);

                ICanalFactory factory = CanalFactoryProducer.Obtener(canal, configCorreo);
                ServicioCanal servicio = new ServicioCanal(factory);
                ResultadoCanal resultado = servicio.EnviarPorCanal(destinatario, titulo, mensaje);

                TempData["r_canal"] = resultado.Canal;
                TempData["r_transporte"] = resultado.CanalNotificador;
                TempData["r_mensaje"] = resultado.MensajeFormateado;
                TempData["r_ok"] = resultado.EnvioExitoso ? "1" : "0";
                TempData["r_detalle"] = resultado.DetalleEnvio;
            }
            catch (ArgumentException ex)
            {
                TempData["Error"] = ex.Message;
            }

            return RedirectToAction("Index");
        }
    }
}
