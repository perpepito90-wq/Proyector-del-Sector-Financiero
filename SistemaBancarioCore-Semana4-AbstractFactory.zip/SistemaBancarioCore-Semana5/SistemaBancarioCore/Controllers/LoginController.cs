using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Models;
using SistemaBancarioCore.Services;
using SistemaBancarioCore.Services.Notificaciones;
using System.Security.Claims;

namespace SistemaBancarioCore.Controllers
{

    public class LoginController : Controller
    {
        private readonly IUsuarioService _usuarioService;
        private readonly IFilesService _filesService;
        private readonly UsuarioContext _context;

        public LoginController(IUsuarioService usuarioService, IFilesService filesService, UsuarioContext context)
        {
            _usuarioService = usuarioService;
            _filesService = filesService;
            _context = context;
        }

        // Lee de la tabla ConfiguracionesCorreo la configuracion SMTP marcada como
        // activa. Devuelve null si aun no hay ninguna configurada.
        private ConfiguracionCorreo? ObtenerConfiguracionCorreo()
        {
            return _context.ConfiguracionesCorreo.FirstOrDefault(c => c.Activo);
        }

        public IActionResult Registro()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Registro(Usuario usuario, IFormFile? Imagen)
        {
            // Se registra el intento usando la UNICA instancia del Logger (Singleton).
            Logger.Instancia.Info($"Intento de registro para el correo: {usuario.Correo}");

            try
            {
                // La foto es opcional: solo se sube si el usuario eligio un archivo.
                if (Imagen != null && Imagen.Length > 0)
                {
                    Stream image = Imagen.OpenReadStream();
                    string urlImagen = await _filesService.SubirArchivo(image, Imagen.FileName);
                    usuario.URLFotoPerfil = urlImagen;
                    Logger.Instancia.Info($"Foto de perfil guardada para {usuario.Correo}: {urlImagen}");
                }

                usuario.Clave = Utilidades.EncriptarClave(usuario.Clave);

                Usuario usuarioCreado = await _usuarioService.SaveUsuario(usuario);

                if (usuarioCreado.Id > 0)
                {
                    Logger.Instancia.Auditoria($"Nuevo cliente registrado (Id={usuarioCreado.Id}, correo={usuario.Correo})");

                    // Semana 4 - Factory Method: se notifica la creacion de la cuenta.
                    // El controlador solo elige el CREADOR concreto (Email) y llama a
                    // Notificar; no conoce la clase concreta del notificador.
                    ServicioNotificacion notificacion = new ServicioNotificacionEmail(ObtenerConfiguracionCorreo());
                    notificacion.Notificar(
                        usuario.Correo,
                        "Bienvenido al Sistema Bancario Core",
                        "Tu registro se completo correctamente. Conserva este mensaje como comprobante.");

                    return RedirectToAction("IniciarSesion", "Login");
                }

                Logger.Instancia.Advertencia($"No se pudo crear el usuario con correo {usuario.Correo}");
                ViewData["Mensaje"] = "No se pudo crear el usuario";
                return View();
            }
            catch (Exception ex)
            {
                // Cualquier fallo inesperado queda registrado en el log central.
                Logger.Instancia.Error($"Error al registrar al usuario {usuario.Correo}: {ex.Message}");
                ViewData["Mensaje"] = "Ocurrio un error al registrar el usuario";
                return View();
            }
        }

        public IActionResult IniciarSesion()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> IniciarSesion(string correo, string clave)
        {
            Logger.Instancia.Info($"Intento de inicio de sesion para: {correo}");

            Usuario usuarioEncontrado = await _usuarioService.GetUsuario(correo, Utilidades.EncriptarClave(clave));

            if (usuarioEncontrado == null)
            {
                Logger.Instancia.Auditoria($"Acceso DENEGADO: {correo} (credenciales incorrectas)");

                // Semana 4 - Factory Method: ante un intento fallido se genera una
                // alerta para el area de seguridad usando el canal Interno. Se usa
                // OTRO creador concreto sin cambiar la logica de notificacion.
                ServicioNotificacion alerta = new ServicioNotificacionInterno();
                alerta.Notificar(
                    correo,
                    "Intento de acceso fallido",
                    $"Se detecto un intento de acceso con credenciales incorrectas para {correo}.");

                ViewData["Mensaje"] = "Usuario no encontrado";
                return View();
            }

            List<Claim> claims = new List<Claim>()
            {
                new Claim(ClaimTypes.Name, usuarioEncontrado.NombreUsuario),
                new Claim("FotoPerfil", usuarioEncontrado.URLFotoPerfil ?? ""),
            };

            ClaimsIdentity claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            AuthenticationProperties properties = new AuthenticationProperties()
            {
                AllowRefresh = true,
            };

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity),
                properties
                );

            Logger.Instancia.Auditoria($"Acceso exitoso al sistema: {correo} (usuario={usuarioEncontrado.NombreUsuario})");

            // Semana 4 - Factory Method: alerta de seguridad al cliente por Email
            // avisando que se registro un nuevo acceso a su cuenta.
            ServicioNotificacion notificacion = new ServicioNotificacionEmail(ObtenerConfiguracionCorreo());
            notificacion.Notificar(
                correo,
                "Nuevo acceso a tu cuenta",
                $"Se registro un acceso exitoso el {DateTime.Now:yyyy-MM-dd HH:mm}. Si no fuiste tu, contacta al banco.");

            return RedirectToAction("Index", "Home");
        }
    }
}
