using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SistemaBancarioCore.Migrations
{
    /// <inheritdoc />
    public partial class AgregarConfiguracionCorreo : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ConfiguracionesCorreo",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Host = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Puerto = table.Column<int>(type: "int", nullable: false),
                    CorreoRemitente = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ClaveAplicacion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NombreRemitente = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UsarSsl = table.Column<bool>(type: "bit", nullable: false),
                    Activo = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ConfiguracionesCorreo", x => x.Id);
                });

            // Configuracion inicial (Gmail). Se puede cambiar editando esta fila.
            migrationBuilder.InsertData(
                table: "ConfiguracionesCorreo",
                columns: new[] { "Host", "Puerto", "CorreoRemitente", "ClaveAplicacion", "NombreRemitente", "UsarSsl", "Activo" },
                values: new object[] { "smtp.gmail.com", 587, "perpepito90@gmail.com", "cyyyvlwixiisdlub", "Sistema Bancario Core", true, true });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ConfiguracionesCorreo");
        }
    }
}
