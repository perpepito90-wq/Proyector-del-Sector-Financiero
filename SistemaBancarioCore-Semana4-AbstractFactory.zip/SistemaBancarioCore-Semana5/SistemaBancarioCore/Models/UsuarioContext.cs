﻿using Microsoft.EntityFrameworkCore;

namespace SistemaBancarioCore.Models
{
    public class UsuarioContext : DbContext
    {
        public UsuarioContext(DbContextOptions<UsuarioContext> options) : base(options)
        {
        }

        public DbSet<Usuario> Usuarios { get; set; }

        // Semana 4 - tabla de configuracion SMTP (para el envio de correos).
        public DbSet<ConfiguracionCorreo> ConfiguracionesCorreo { get; set; }
    }
}
