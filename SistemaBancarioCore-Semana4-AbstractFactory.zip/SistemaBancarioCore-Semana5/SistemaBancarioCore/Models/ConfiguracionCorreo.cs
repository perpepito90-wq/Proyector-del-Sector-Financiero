namespace SistemaBancarioCore.Models
{
    /// <summary>
    /// Tabla de configuracion del servidor de correo (SMTP).
    /// Permite cambiar el correo emisor, la clave y el servidor SIN tocar el
    /// codigo: basta con editar la fila en la base de datos.
    /// </summary>
    public class ConfiguracionCorreo
    {
        public int Id { get; set; }

        /// <summary>Servidor SMTP. Ej: smtp.gmail.com</summary>
        public string Host { get; set; } = null!;

        /// <summary>Puerto SMTP. Para Gmail con STARTTLS: 587.</summary>
        public int Puerto { get; set; }

        /// <summary>Correo desde el que se envian los mensajes (usuario SMTP).</summary>
        public string CorreoRemitente { get; set; } = null!;

        /// <summary>Clave de aplicacion del correo (no la contrasena normal de la cuenta).</summary>
        public string ClaveAplicacion { get; set; } = null!;

        /// <summary>Nombre que se muestra como remitente.</summary>
        public string NombreRemitente { get; set; } = null!;

        /// <summary>Usar conexion segura (SSL/TLS). Para Gmail: true.</summary>
        public bool UsarSsl { get; set; }

        /// <summary>Indica cual configuracion esta activa (permite tener varias y elegir una).</summary>
        public bool Activo { get; set; }
    }
}
