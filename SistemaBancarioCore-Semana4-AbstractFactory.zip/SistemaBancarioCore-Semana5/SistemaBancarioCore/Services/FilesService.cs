using Microsoft.AspNetCore.Hosting;

namespace SistemaBancarioCore.Services
{
    public class FilesService : IFilesService
    {
        private readonly IWebHostEnvironment _env;

        public FilesService(IWebHostEnvironment env)
        {
            _env = env;
        }

        public async Task<string> SubirArchivo(Stream archivo, string nombre)
        {
            // Carpeta fisica donde se guardaran las fotos: wwwroot/images/perfiles
            string carpeta = Path.Combine(_env.WebRootPath, "images", "perfiles");

            if (!Directory.Exists(carpeta))
                Directory.CreateDirectory(carpeta);

            // Nombre unico para evitar que dos archivos se pisen
            string extension = Path.GetExtension(nombre);
            string nombreUnico = $"{Guid.NewGuid()}{extension}";
            string rutaFisica = Path.Combine(carpeta, nombreUnico);

            // Guardar el archivo en disco
            using (var fileStream = new FileStream(rutaFisica, FileMode.Create))
            {
                await archivo.CopyToAsync(fileStream);
            }

            // Se devuelve la URL relativa que se guarda en la BD y se usa en el <img>
            return $"/images/perfiles/{nombreUnico}";
        }
    }
}
