﻿using SistemaBancarioCore.Models;

namespace SistemaBancarioCore.Services
{
    public interface IUsuarioService
    {
        Task<Usuario> GetUsuario(string correo, string clave);
        Task<Usuario> SaveUsuario(Usuario usuario);
    }
}
