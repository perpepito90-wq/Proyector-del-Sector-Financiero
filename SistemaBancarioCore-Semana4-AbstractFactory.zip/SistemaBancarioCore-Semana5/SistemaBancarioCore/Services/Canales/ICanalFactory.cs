using SistemaBancarioCore.Services.Notificaciones;

namespace SistemaBancarioCore.Services.Canales
{
    /// <summary>
    /// FABRICA ABSTRACTA (Abstract Factory).
    /// Crea la familia de piezas que necesita un canal de atencion del banco.
    /// Todas las piezas que devuelve una misma fabrica son coherentes entre si:
    /// el notificador y el formateador corresponden al mismo canal.
    ///
    /// Nota: el notificador es un producto del patron Factory Method (semana 4);
    /// aqui Abstract Factory lo reutiliza como parte de la familia.
    /// </summary>
    public interface ICanalFactory
    {
        string Canal { get; }

        /// <summary>Producto A de la familia: el notificador (transporte del canal).</summary>
        INotificador CrearNotificador();

        /// <summary>Producto B de la familia: el formateador de mensaje del canal.</summary>
        IFormateadorMensaje CrearFormateador();
    }
}
