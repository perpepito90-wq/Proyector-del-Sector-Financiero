using SistemaBancarioCore.Models;
using SistemaBancarioCore.Services.Notificaciones;

namespace SistemaBancarioCore.Services.Canales
{
    /// <summary>
    /// FABRICA CONCRETA: canal Web (banca en linea).
    /// Notifica por correo y presenta el mensaje con formato HTML.
    /// Recibe la configuracion SMTP porque el notificador de correo la necesita.
    /// </summary>
    public class CanalWebFactory : ICanalFactory
    {
        private readonly ConfiguracionCorreo? _configCorreo;

        public CanalWebFactory(ConfiguracionCorreo? configCorreo)
        {
            _configCorreo = configCorreo;
        }

        public string Canal => "Web";
        public INotificador CrearNotificador() => new NotificadorEmail(_configCorreo);
        public IFormateadorMensaje CrearFormateador() => new FormateadorWeb();
    }

    /// <summary>
    /// FABRICA CONCRETA: canal Movil (app).
    /// Notifica por push y presenta el mensaje de forma breve.
    /// </summary>
    public class CanalMovilFactory : ICanalFactory
    {
        public string Canal => "Movil";
        public INotificador CrearNotificador() => new NotificadorPush();
        public IFormateadorMensaje CrearFormateador() => new FormateadorMovil();
    }

    /// <summary>
    /// FABRICA CONCRETA: canal Cajero automatico.
    /// Deja el aviso en la bandeja interna y presenta un tique imprimible.
    /// </summary>
    public class CanalCajeroFactory : ICanalFactory
    {
        public string Canal => "Cajero";
        public INotificador CrearNotificador() => new NotificadorInterno();
        public IFormateadorMensaje CrearFormateador() => new FormateadorCajero();
    }

    /// <summary>
    /// FABRICA CONCRETA: canal Sucursal (atencion presencial).
    /// Registra el aviso internamente y presenta un documento formal.
    /// </summary>
    public class CanalSucursalFactory : ICanalFactory
    {
        public string Canal => "Sucursal";
        public INotificador CrearNotificador() => new NotificadorInterno();
        public IFormateadorMensaje CrearFormateador() => new FormateadorSucursal();
    }
}
