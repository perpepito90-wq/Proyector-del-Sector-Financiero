namespace SistemaBancarioCore.Services.Canales
{
    /// <summary>
    /// PRODUCTO ABSTRACTO (Abstract Factory).
    /// Da formato a un mensaje segun el canal de atencion. Cada canal presenta la
    /// informacion de forma distinta (HTML en web, texto corto en movil, tique en
    /// cajero, documento formal en sucursal).
    /// </summary>
    public interface IFormateadorMensaje
    {
        string Canal { get; }
        string Formatear(string titulo, string cuerpo);
    }
}
