namespace SistemaBancarioCore.Services.Canales
{
    /// <summary>Resultado de procesar un mensaje a traves de un canal de atencion.</summary>
    public class ResultadoCanal
    {
        public string Canal { get; set; } = string.Empty;
        public string CanalNotificador { get; set; } = string.Empty;
        public string MensajeFormateado { get; set; } = string.Empty;
        public bool EnvioExitoso { get; set; }
        public string DetalleEnvio { get; set; } = string.Empty;
    }
}
