using SistemaBancarioCore.Services.Notificaciones;

namespace SistemaBancarioCore.Services.Canales
{
    /// <summary>
    /// CLIENTE del Abstract Factory. Recibe una fabrica de canal y usa la familia
    /// completa (formateador + notificador) sin conocer sus clases concretas. Si
    /// se agrega un canal nuevo, esta clase no cambia.
    /// </summary>
    public class ServicioCanal
    {
        private readonly ICanalFactory _factory;

        public ServicioCanal(ICanalFactory factory)
        {
            _factory = factory;
        }

        public ResultadoCanal EnviarPorCanal(string destinatario, string titulo, string cuerpo)
        {
            // Ambas piezas provienen de la MISMA fabrica: quedan coherentes por canal.
            IFormateadorMensaje formateador = _factory.CrearFormateador();
            INotificador notificador = _factory.CrearNotificador();

            string mensajeFormateado = formateador.Formatear(titulo, cuerpo);

            Logger.Instancia.Info(
                $"Canal {_factory.Canal}: formateando con {formateador.Canal} y enviando por {notificador.Canal}");

            ResultadoNotificacion envio = notificador.Enviar(destinatario, titulo, mensajeFormateado);

            return new ResultadoCanal
            {
                Canal = _factory.Canal,
                CanalNotificador = notificador.Canal,
                MensajeFormateado = mensajeFormateado,
                EnvioExitoso = envio.Exito,
                DetalleEnvio = envio.Detalle
            };
        }
    }
}
