using System.Text;

namespace SistemaBancarioCore.Services.Canales
{
    /// <summary>PRODUCTO CONCRETO: formato para banca en linea (web), con marcado HTML.</summary>
    public class FormateadorWeb : IFormateadorMensaje
    {
        public string Canal => "Web";

        public string Formatear(string titulo, string cuerpo)
        {
            return $"<div class=\"aviso-banca\">" +
                   $"<h3>{titulo}</h3>" +
                   $"<p>{cuerpo}</p>" +
                   $"<small>Banca en linea - Sistema Bancario Core</small>" +
                   $"</div>";
        }
    }

    /// <summary>PRODUCTO CONCRETO: formato para app movil, breve como una notificacion push.</summary>
    public class FormateadorMovil : IFormateadorMensaje
    {
        public string Canal => "Movil";

        public string Formatear(string titulo, string cuerpo)
        {
            string resumen = cuerpo.Length > 120 ? cuerpo.Substring(0, 117) + "..." : cuerpo;
            return $"[APP] {titulo}: {resumen}";
        }
    }

    /// <summary>PRODUCTO CONCRETO: formato tipo tique impreso para cajero automatico.</summary>
    public class FormateadorCajero : IFormateadorMensaje
    {
        public string Canal => "Cajero";

        public string Formatear(string titulo, string cuerpo)
        {
            const int ancho = 32;
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(new string('=', ancho));
            sb.AppendLine("  SISTEMA BANCARIO CORE");
            sb.AppendLine(new string('-', ancho));
            sb.AppendLine(titulo.ToUpper());
            sb.AppendLine(new string('-', ancho));
            sb.AppendLine(cuerpo);
            sb.AppendLine(new string('=', ancho));
            sb.AppendLine("  CONSERVE ESTE COMPROBANTE");
            return sb.ToString();
        }
    }

    /// <summary>PRODUCTO CONCRETO: formato de carta formal para atencion en sucursal.</summary>
    public class FormateadorSucursal : IFormateadorMensaje
    {
        public string Canal => "Sucursal";

        public string Formatear(string titulo, string cuerpo)
        {
            return $"Estimado cliente:\n\n" +
                   $"Asunto: {titulo}\n\n" +
                   $"{cuerpo}\n\n" +
                   $"Atentamente,\n" +
                   $"Atencion en Sucursal - Sistema Bancario Core";
        }
    }
}
