using SistemaBancarioCore.Models;

namespace SistemaBancarioCore.Services.Canales
{
    /// <summary>
    /// Selecciona la FABRICA CONCRETA segun el canal solicitado (equivalente al
    /// "FactoryProducer" del patron). El cliente solo indica el canal y recibe una
    /// ICanalFactory; no conoce las clases concretas de cada canal.
    /// </summary>
    public static class CanalFactoryProducer
    {
        public static ICanalFactory Obtener(string canal, ConfiguracionCorreo? configCorreo)
        {
            return (canal ?? string.Empty).Trim().ToLower() switch
            {
                "web"      => new CanalWebFactory(configCorreo),
                "movil"    => new CanalMovilFactory(),
                "cajero"   => new CanalCajeroFactory(),
                "sucursal" => new CanalSucursalFactory(),
                _ => throw new ArgumentException($"Canal no soportado: {canal}")
            };
        }
    }
}
