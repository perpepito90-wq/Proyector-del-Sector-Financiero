namespace SistemaBancarioCore.Services.Notificaciones
{
    /// <summary>
    /// PRODUCTO (Factory Method).
    /// Interfaz comun para todos los notificadores del sistema. El codigo que
    /// envia una notificacion trabaja siempre contra esta abstraccion y nunca
    /// contra una clase concreta (Email, SMS, etc.).
    /// </summary>
    public interface INotificador
    {
        /// <summary>Nombre del canal (Email, SMS, Push, Interno). Util para el log.</summary>
        string Canal { get; }

        /// <summary>Envia la notificacion al destinatario indicado.</summary>
        ResultadoNotificacion Enviar(string destinatario, string asunto, string mensaje);
    }
}
