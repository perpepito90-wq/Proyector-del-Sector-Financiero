using System.Net;
using System.Net.Mail;
using SistemaBancarioCore.Models;

namespace SistemaBancarioCore.Services.Notificaciones
{
    /// <summary>
    /// PRODUCTO CONCRETO: notificador por correo electronico.
    /// Envia correos reales mediante SMTP usando la configuracion guardada en la
    /// tabla ConfiguracionesCorreo. Cada envio queda registrado en la bitacora
    /// central (Logger Singleton de la semana 3), que sirve como auditoria.
    /// </summary>
    public class NotificadorEmail : INotificador
    {
        private readonly ConfiguracionCorreo? _config;

        public NotificadorEmail(ConfiguracionCorreo? config)
        {
            _config = config;
        }

        public string Canal => "Email";

        public ResultadoNotificacion Enviar(string destinatario, string asunto, string mensaje)
        {
            // Sin configuracion valida no se puede enviar: se deja constancia y se
            // devuelve fallo, pero NO se lanza excepcion para no romper el flujo.
            if (_config == null
                || string.IsNullOrWhiteSpace(_config.Host)
                || string.IsNullOrWhiteSpace(_config.CorreoRemitente))
            {
                Logger.Instancia.Error("[Email] No hay configuracion SMTP valida. No se envio el correo.");
                return new ResultadoNotificacion
                {
                    Exito = false,
                    Canal = Canal,
                    Detalle = "Configuracion SMTP no disponible"
                };
            }

            try
            {
                using SmtpClient cliente = new SmtpClient(_config.Host, _config.Puerto)
                {
                    EnableSsl = _config.UsarSsl,
                    Credentials = new NetworkCredential(
                        _config.CorreoRemitente,
                        // La clave de aplicacion puede venir con espacios; se quitan.
                        _config.ClaveAplicacion.Replace(" ", string.Empty))
                };

                using MailMessage correo = new MailMessage
                {
                    From = new MailAddress(_config.CorreoRemitente, _config.NombreRemitente),
                    Subject = asunto,
                    Body = mensaje,
                    IsBodyHtml = false
                };
                correo.To.Add(destinatario);

                cliente.Send(correo);

                Logger.Instancia.Info($"[Email] Correo enviado a {destinatario} | Asunto: {asunto}");
                Logger.Instancia.Auditoria($"Notificacion Email enviada a {destinatario}: {asunto}");

                return new ResultadoNotificacion
                {
                    Exito = true,
                    Canal = Canal,
                    Detalle = $"Correo enviado a {destinatario}"
                };
            }
            catch (Exception ex)
            {
                // Un fallo de correo (clave incorrecta, sin internet, etc.) se registra
                // pero no interrumpe el registro ni el inicio de sesion del usuario.
                Logger.Instancia.Error($"[Email] Error al enviar a {destinatario}: {ex.Message}");
                return new ResultadoNotificacion
                {
                    Exito = false,
                    Canal = Canal,
                    Detalle = $"Error al enviar: {ex.Message}"
                };
            }
        }
    }
}
