namespace SistemaBancarioCore.Services.Notificaciones
{
    /// <summary>
    /// PRODUCTO CONCRETO: notificador por SMS.
    /// En produccion se conectaria a una pasarela de mensajeria. Aqui se simula
    /// el envio y se registra en la bitacora central (Logger Singleton).
    /// </summary>
    public class NotificadorSMS : INotificador
    {
        public string Canal => "SMS";

        public ResultadoNotificacion Enviar(string destinatario, string asunto, string mensaje)
        {
            Logger.Instancia.Info($"[SMS] Enviando mensaje de texto a {destinatario}");
            Logger.Instancia.Auditoria($"Notificacion SMS enviada a {destinatario}: {mensaje}");

            return new ResultadoNotificacion
            {
                Exito = true,
                Canal = Canal,
                Detalle = $"SMS enviado a {destinatario}"
            };
        }
    }
}
