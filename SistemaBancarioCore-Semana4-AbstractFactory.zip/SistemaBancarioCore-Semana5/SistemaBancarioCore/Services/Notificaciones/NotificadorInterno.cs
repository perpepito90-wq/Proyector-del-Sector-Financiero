using System.Text;

namespace SistemaBancarioCore.Services.Notificaciones
{
    /// <summary>
    /// PRODUCTO CONCRETO: notificador interno.
    /// Pensado para alertas dirigidas al area de seguridad / monitoreo de fraude
    /// del banco (no al cliente). Escribe en una bandeja interna y ademas deja
    /// el evento en la bitacora central (Logger Singleton).
    /// </summary>
    public class NotificadorInterno : INotificador
    {
        public string Canal => "Interno";

        public ResultadoNotificacion Enviar(string destinatario, string asunto, string mensaje)
        {
            string carpeta = Path.Combine(AppContext.BaseDirectory, "Notificaciones");
            if (!Directory.Exists(carpeta))
                Directory.CreateDirectory(carpeta);

            string ruta = Path.Combine(carpeta, "bandeja_interna.txt");
            string linea = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | Para: {destinatario} | {asunto} | {mensaje}";

            File.AppendAllText(ruta, linea + Environment.NewLine, Encoding.UTF8);

            Logger.Instancia.Auditoria($"Notificacion interna registrada para {destinatario}: {asunto}");

            return new ResultadoNotificacion
            {
                Exito = true,
                Canal = Canal,
                Detalle = "Notificacion interna registrada en la bandeja de seguridad"
            };
        }
    }
}
