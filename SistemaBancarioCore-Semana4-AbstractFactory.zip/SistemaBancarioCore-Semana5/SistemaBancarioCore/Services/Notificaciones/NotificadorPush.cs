namespace SistemaBancarioCore.Services.Notificaciones
{
    /// <summary>
    /// PRODUCTO CONCRETO: notificador push (notificacion movil).
    /// En produccion se conectaria a un servicio de push (por ejemplo, el de la
    /// app movil del banco). Aqui se simula el envio y se registra en la bitacora.
    /// </summary>
    public class NotificadorPush : INotificador
    {
        public string Canal => "Push";

        public ResultadoNotificacion Enviar(string destinatario, string asunto, string mensaje)
        {
            Logger.Instancia.Info($"[Push] Enviando notificacion movil a {destinatario}");
            Logger.Instancia.Auditoria($"Notificacion Push enviada a {destinatario}: {mensaje}");

            return new ResultadoNotificacion
            {
                Exito = true,
                Canal = Canal,
                Detalle = $"Push enviado a {destinatario}"
            };
        }
    }
}
