namespace SistemaBancarioCore.Services.Notificaciones
{
    /// <summary>
    /// CREADOR (Factory Method).
    /// Declara el metodo fabrica <see cref="CrearNotificador"/> que las subclases
    /// implementan para decidir QUE notificador concreto se usa. La logica de
    /// negocio comun (Notificar) queda aqui y NO cambia cuando se agrega un canal
    /// nuevo: por eso el sistema cumple el principio Abierto/Cerrado (OCP).
    /// </summary>
    public abstract class ServicioNotificacion
    {
        /// <summary>
        /// FACTORY METHOD: cada creador concreto devuelve el notificador que le
        /// corresponde (Email, SMS, Push, Interno...).
        /// </summary>
        protected abstract INotificador CrearNotificador();

        /// <summary>
        /// Logica de negocio comun a todos los canales. Usa el producto creado por
        /// el metodo fabrica sin conocer su clase concreta.
        /// </summary>
        public ResultadoNotificacion Notificar(string destinatario, string asunto, string mensaje)
        {
            INotificador notificador = CrearNotificador();

            Logger.Instancia.Info(
                $"Preparando notificacion por canal {notificador.Canal} para {destinatario}");

            ResultadoNotificacion resultado = notificador.Enviar(destinatario, asunto, mensaje);

            if (!resultado.Exito)
                Logger.Instancia.Advertencia(
                    $"Fallo la notificacion por {notificador.Canal} a {destinatario}");

            return resultado;
        }
    }
}
