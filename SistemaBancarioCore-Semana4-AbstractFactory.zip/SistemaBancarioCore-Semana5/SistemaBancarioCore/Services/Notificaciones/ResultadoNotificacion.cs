namespace SistemaBancarioCore.Services.Notificaciones
{
    /// <summary>
    /// Pequeno objeto que describe el resultado de un envio de notificacion.
    /// Permite que quien la solicita sepa si el envio fue exitoso y por que canal.
    /// </summary>
    public class ResultadoNotificacion
    {
        public bool Exito { get; set; }
        public string Canal { get; set; } = string.Empty;
        public string Detalle { get; set; } = string.Empty;
    }
}
