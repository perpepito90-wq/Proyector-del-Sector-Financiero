using SistemaBancarioCore.Models;

namespace SistemaBancarioCore.Services.Notificaciones
{
    /// <summary>
    /// CREADOR CONCRETO: crea un notificador de Email.
    /// Recibe la configuracion SMTP (leida de la tabla ConfiguracionesCorreo) y
    /// se la entrega al notificador que fabrica.
    /// </summary>
    public class ServicioNotificacionEmail : ServicioNotificacion
    {
        private readonly ConfiguracionCorreo? _config;

        public ServicioNotificacionEmail(ConfiguracionCorreo? config)
        {
            _config = config;
        }

        protected override INotificador CrearNotificador() => new NotificadorEmail(_config);
    }

    /// <summary>CREADOR CONCRETO: crea un notificador de SMS.</summary>
    public class ServicioNotificacionSMS : ServicioNotificacion
    {
        protected override INotificador CrearNotificador() => new NotificadorSMS();
    }

    /// <summary>CREADOR CONCRETO: crea un notificador Push (movil).</summary>
    public class ServicioNotificacionPush : ServicioNotificacion
    {
        protected override INotificador CrearNotificador() => new NotificadorPush();
    }

    /// <summary>CREADOR CONCRETO: crea un notificador Interno (seguridad).</summary>
    public class ServicioNotificacionInterno : ServicioNotificacion
    {
        protected override INotificador CrearNotificador() => new NotificadorInterno();
    }
}
