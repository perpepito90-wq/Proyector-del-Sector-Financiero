using System.Text;

namespace SistemaBancarioCore.Services
{
   
    public sealed class Logger
    {
        // 1) Instancia unica. Se crea de forma "perezosa" (lazy): solo cuando
        //    se usa por primera vez. Lazy<T> ademas es seguro entre hilos.
        private static readonly Lazy<Logger> _instancia =
            new Lazy<Logger>(() => new Logger());

        // 2) Punto de acceso global: la unica forma de obtener el Logger.
        public static Logger Instancia => _instancia.Value;

        private readonly string _rutaArchivo;

        // 3) Candado para que dos operaciones simultaneas (de distintos canales
        //    o usuarios) no escriban a la vez y corrompan la bitacora.
        private readonly object _bloqueo = new object();

        // 4) Constructor PRIVADO: impide que otras clases hagan "new Logger()".
        private Logger()
        {
            string carpeta = Path.Combine(AppContext.BaseDirectory, "Logs");

            if (!Directory.Exists(carpeta))
                Directory.CreateDirectory(carpeta);

            // Una bitacora por dia, p.ej: Logs/log_2025-08-29.txt
            _rutaArchivo = Path.Combine(carpeta, $"log_{DateTime.Now:yyyy-MM-dd}.txt");
        }

        /// <summary>Escribe una linea en la bitacora con un nivel dado.</summary>
        public void Log(string mensaje, string nivel = "INFO")
        {
            string linea = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} [{nivel}] {mensaje}";

            lock (_bloqueo)
            {
                File.AppendAllText(_rutaArchivo, linea + Environment.NewLine, Encoding.UTF8);
            }

            // Tambien se muestra en consola para verlo durante el desarrollo.
            Console.WriteLine(linea);
        }

        // Metodos de conveniencia por nivel.
        public void Info(string mensaje) => Log(mensaje, "INFO");
        public void Advertencia(string mensaje) => Log(mensaje, "WARN");
        public void Error(string mensaje) => Log(mensaje, "ERROR");

        public void Auditoria(string mensaje) => Log(mensaje, "AUDIT");
    }
}
