namespace SistemaBancarioCore.Services.Operaciones
{
    // ============================================================================
    //  SUBSISTEMAS del Facade.
    //  Cada clase resuelve UNA parte del problema y no conoce a las demás. El
    //  Facade (CentroOperacionesFacade) es quien las coordina en el orden correcto.
    //  Son los módulos que antes figuraban como "Próximamente": Cumplimiento
    //  (KYC/AML) y Detección de fraude.
    // ============================================================================

    /// <summary>Resultado del subsistema de cumplimiento (KYC/AML).</summary>
    public class ResultadoCumplimiento
    {
        public bool KycVigente { get; set; }
        public bool CoincideListasRestrictivas { get; set; }
        public bool PaisSancionado { get; set; }
        public List<string> Hallazgos { get; } = new List<string>();

        public bool Aprobado => KycVigente && !CoincideListasRestrictivas && !PaisSancionado;
    }

    /// <summary>
    /// SUBSISTEMA 1 — Cumplimiento KYC/AML. Verifica que el cliente tenga su
    /// identidad validada (KYC) y hace el screening antilavado (AML) del país de
    /// destino y de las listas restrictivas (sancionados / PEP). Objetivo del
    /// proyecto: "cumplimiento regulatorio (KYC/AML)".
    /// </summary>
    public class CumplimientoService
    {
        // En un sistema real provendrían de listas oficiales (OFAC, ONU, UIAF).
        // Aquí se usan muestras fijas para la simulación académica.
        private static readonly string[] PaisesSancionados =
            { "corea del norte", "iran", "irán", "siria", "cuba" };

        private static readonly string[] ListasRestrictivas =
            { "juan perez sancionado", "empresa fantasma sa" };

        public ResultadoCumplimiento VerificarKycAml(SolicitudOperacion s)
        {
            var r = new ResultadoCumplimiento();

            // KYC: el cliente debe tener la verificación de identidad vigente.
            string cliente = (s.Cliente ?? string.Empty).Trim();
            r.KycVigente = cliente.Length > 0 && !cliente.ToLower().Contains("sin kyc");
            if (!r.KycVigente)
                r.Hallazgos.Add("El cliente no tiene la verificación de identidad (KYC) vigente.");

            // AML: screening del país de destino.
            r.PaisSancionado = PaisesSancionados.Contains((s.PaisDestino ?? string.Empty).Trim().ToLower());
            if (r.PaisSancionado)
                r.Hallazgos.Add($"País de destino bajo sanción: {s.PaisDestino}.");

            // AML: screening del cliente contra listas restrictivas (sancionados / PEP).
            r.CoincideListasRestrictivas = ListasRestrictivas.Contains(cliente.ToLower());
            if (r.CoincideListasRestrictivas)
                r.Hallazgos.Add("Coincidencia del cliente en listas restrictivas (sancionados / PEP).");

            return r;
        }
    }

    /// <summary>Resultado del subsistema de detección de fraude.</summary>
    public class ResultadoFraude
    {
        public int Puntaje { get; set; }
        public List<string> Reglas { get; } = new List<string>();
    }

    /// <summary>
    /// SUBSISTEMA 2 — Detección de fraude en tiempo real. Aplica reglas sobre la
    /// operación (monto, país, canal, horario) y devuelve un puntaje de riesgo de
    /// 0 a 100. Objetivo del proyecto: "detección de fraude en tiempo real".
    /// </summary>
    public class DeteccionFraudeService
    {
        private const decimal UmbralMontoAlto = 10_000_000m;   // COP

        private static readonly string[] PaisesAltoRiesgo =
            { "nigeria", "rusia", "venezuela" };

        public ResultadoFraude Analizar(SolicitudOperacion s)
        {
            var r = new ResultadoFraude();
            string canal = (s.Canal ?? string.Empty).ToLower();
            string pais = (s.PaisDestino ?? string.Empty).Trim().ToLower();

            if (s.Monto >= UmbralMontoAlto)
            {
                r.Puntaje += 40;
                r.Reglas.Add($"Monto inusualmente alto (≥ {UmbralMontoAlto:N0}).");
            }

            if (PaisesAltoRiesgo.Contains(pais))
            {
                r.Puntaje += 30;
                r.Reglas.Add($"País de destino de alto riesgo: {s.PaisDestino}.");
            }

            if (canal == "cajero" && s.Monto >= 3_000_000m)
            {
                r.Puntaje += 15;
                r.Reglas.Add("Retiro elevado por cajero automático.");
            }

            int hora = DateTime.Now.Hour;
            if (hora >= 0 && hora < 5)
            {
                r.Puntaje += 10;
                r.Reglas.Add("Operación en horario de madrugada (00:00–05:00).");
            }

            if (r.Puntaje > 100) r.Puntaje = 100;
            if (r.Reglas.Count == 0) r.Reglas.Add("Sin señales de fraude detectadas.");
            return r;
        }
    }

    /// <summary>Resultado del subsistema de límites.</summary>
    public class ResultadoLimite
    {
        public decimal LimiteAplicable { get; set; }
        public bool DentroDelLimite { get; set; }
    }

    /// <summary>
    /// SUBSISTEMA 3 — Límites por canal. Verifica que el monto no supere el máximo
    /// permitido para el canal de la operación.
    /// </summary>
    public class LimitesService
    {
        public ResultadoLimite Verificar(SolicitudOperacion s)
        {
            decimal limite = (s.Canal ?? string.Empty).ToLower() switch
            {
                "cajero" => 3_000_000m,
                "movil" => 20_000_000m,
                "web" => 20_000_000m,
                "sucursal" => 100_000_000m,
                _ => 10_000_000m
            };

            return new ResultadoLimite
            {
                LimiteAplicable = limite,
                DentroDelLimite = s.Monto <= limite
            };
        }
    }

    /// <summary>
    /// SUBSISTEMA 4 — Autorización. Toma los resultados de los demás subsistemas y
    /// decide el veredicto final. No calcula riesgo ni hace screening: solo decide.
    /// </summary>
    public class AutorizacionService
    {
        public EstadoOperacion Decidir(ResultadoCumplimiento cumplimiento,
                                       ResultadoFraude fraude,
                                       ResultadoLimite limite)
        {
            if (!cumplimiento.Aprobado) return EstadoOperacion.Rechazada;
            if (!limite.DentroDelLimite) return EstadoOperacion.Rechazada;
            if (fraude.Puntaje >= 70) return EstadoOperacion.Rechazada;
            if (fraude.Puntaje >= 40) return EstadoOperacion.EnRevision;
            return EstadoOperacion.Aprobada;
        }
    }
}
