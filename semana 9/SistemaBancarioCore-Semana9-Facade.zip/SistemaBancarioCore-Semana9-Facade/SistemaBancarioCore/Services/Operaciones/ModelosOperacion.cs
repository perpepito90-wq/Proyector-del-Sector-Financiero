namespace SistemaBancarioCore.Services.Operaciones
{
    /// <summary>
    /// ENTRADA del Facade. Describe la operación que el cliente desea realizar.
    /// Es un objeto simple: el cliente solo llena estos datos y no conoce los
    /// subsistemas que luego la evalúan.
    /// </summary>
    public class SolicitudOperacion
    {
        public string Cliente { get; set; } = string.Empty;
        public string TipoOperacion { get; set; } = "transferencia"; // retiro | transferencia | pago
        public decimal Monto { get; set; }
        public string PaisDestino { get; set; } = "Colombia";
        public string Canal { get; set; } = "web";                   // web | movil | cajero | sucursal
    }

    /// <summary>Resultado de la decisión final sobre la operación.</summary>
    public enum EstadoOperacion
    {
        Aprobada,
        EnRevision,
        Rechazada
    }

    /// <summary>
    /// SALIDA del Facade. Reúne en un solo objeto el veredicto, el puntaje de
    /// riesgo, los motivos y la traza de los subsistemas consultados. El cliente
    /// recibe esto sin haber tenido que llamar a cada subsistema por separado.
    /// </summary>
    public class ResultadoOperacion
    {
        public string Referencia { get; set; } = string.Empty;
        public EstadoOperacion Estado { get; set; }
        public int PuntajeRiesgo { get; set; }

        /// <summary>Motivos que explican la decisión (hallazgos de cumplimiento y fraude).</summary>
        public List<string> Motivos { get; } = new List<string>();

        /// <summary>Traza de los subsistemas que el Facade coordinó (útil para la demo).</summary>
        public List<string> Traza { get; } = new List<string>();

        public string EstadoTexto => Estado switch
        {
            EstadoOperacion.Aprobada => "APROBADA",
            EstadoOperacion.EnRevision => "EN REVISIÓN",
            _ => "RECHAZADA"
        };
    }
}
