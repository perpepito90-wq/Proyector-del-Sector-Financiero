using SistemaBancarioCore.Services;
using SistemaBancarioCore.Services.Notificaciones;

namespace SistemaBancarioCore.Services.Operaciones
{
    /// <summary>
    /// FACADE (Fachada). Ofrece una PUERTA DE ENTRADA ÚNICA para evaluar y
    /// autorizar una operación bancaria. El cliente (el controlador / la UI) llama
    /// a un solo método —EvaluarOperacion— y recibe un resultado simple, sin
    /// necesidad de conocer ni orquestar los subsistemas internos:
    ///
    ///   CumplimientoService (KYC/AML) → DeteccionFraudeService →
    ///   LimitesService → AutorizacionService → auditoría (Logger, Singleton) →
    ///   notificación interna de seguridad (Factory Method).
    ///
    /// El Facade solo COORDINA; la lógica de negocio vive en cada subsistema.
    /// </summary>
    public class CentroOperacionesFacade
    {
        private readonly CumplimientoService _cumplimiento = new CumplimientoService();
        private readonly DeteccionFraudeService _fraude = new DeteccionFraudeService();
        private readonly LimitesService _limites = new LimitesService();
        private readonly AutorizacionService _autorizacion = new AutorizacionService();

        public ResultadoOperacion EvaluarOperacion(SolicitudOperacion s)
        {
            var resultado = new ResultadoOperacion
            {
                Referencia = $"OP-{DateTime.Now:yyyyMMdd-HHmmss}"
            };
            resultado.Traza.Add(
                $"Solicitud recibida: {s.TipoOperacion} por {s.Monto:N0} hacia {s.PaisDestino} (canal {s.Canal}).");

            // 1) Cumplimiento KYC/AML
            ResultadoCumplimiento cumplimiento = _cumplimiento.VerificarKycAml(s);
            resultado.Traza.Add(
                $"CumplimientoService → KYC vigente: {(cumplimiento.KycVigente ? "sí" : "no")}; " +
                $"screening AML: {(cumplimiento.Aprobado ? "sin alertas" : "con alertas")}.");
            Logger.Instancia.Auditoria(
                $"[{resultado.Referencia}] Verificación KYC/AML ejecutada para '{s.Cliente}'");

            // 2) Detección de fraude en tiempo real
            ResultadoFraude fraude = _fraude.Analizar(s);
            resultado.Traza.Add($"DeteccionFraudeService → puntaje de riesgo: {fraude.Puntaje}/100.");
            Logger.Instancia.Auditoria(
                $"[{resultado.Referencia}] Análisis de fraude: puntaje {fraude.Puntaje}");

            // 3) Límites por canal
            ResultadoLimite limite = _limites.Verificar(s);
            resultado.Traza.Add(
                $"LimitesService → límite del canal {s.Canal}: {limite.LimiteAplicable:N0}; " +
                $"dentro del límite: {(limite.DentroDelLimite ? "sí" : "no")}.");

            // 4) Autorización (decisión final)
            EstadoOperacion estado = _autorizacion.Decidir(cumplimiento, fraude, limite);
            resultado.Estado = estado;
            resultado.PuntajeRiesgo = fraude.Puntaje;
            resultado.Traza.Add($"AutorizacionService → decisión: {resultado.EstadoTexto}.");

            // Motivos agregados que explican la decisión
            resultado.Motivos.AddRange(cumplimiento.Hallazgos);
            resultado.Motivos.AddRange(fraude.Reglas);
            if (!limite.DentroDelLimite)
                resultado.Motivos.Add(
                    $"La operación excede el límite del canal ({limite.LimiteAplicable:N0}).");

            // 5) Auditoría central (Singleton)
            Logger.Instancia.Auditoria(
                $"[{resultado.Referencia}] Operación {resultado.EstadoTexto} " +
                $"(riesgo {fraude.Puntaje}) para '{s.Cliente}'");

            // 6) Notificación interna de seguridad si la operación NO fue aprobada.
            //    Reutiliza el subsistema de notificaciones (Factory Method).
            if (estado != EstadoOperacion.Aprobada)
            {
                ServicioNotificacion alerta = new ServicioNotificacionInterno();
                alerta.Notificar(
                    "unidad.seguridad@bancocore",
                    $"Operación {resultado.EstadoTexto}: {resultado.Referencia}",
                    $"Cliente '{s.Cliente}', monto {s.Monto:N0}, riesgo {fraude.Puntaje}.");
                resultado.Traza.Add("NotificadorInterno → alerta enviada a la unidad de seguridad.");
            }

            return resultado;
        }
    }
}
