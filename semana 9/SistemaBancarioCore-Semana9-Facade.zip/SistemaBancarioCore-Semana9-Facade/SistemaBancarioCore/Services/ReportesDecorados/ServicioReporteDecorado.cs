using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.ReportesDecorados
{
    /// <summary>
    /// CLIENTE del Decorator. Arma dinámicamente el reporte de auditoría
    /// envolviendo el reporte base con los decoradores que el usuario elija
    /// (membrete, firma, marca de confidencialidad, observaciones).
    /// </summary>
    public class ServicioReporteDecorado
    {
        public IReporteAuditoria Construir(bool encabezado, bool firma, string firmante,
                                           bool confidencial, bool observaciones)
        {
            IReporteAuditoria reporte = new ReporteAuditoriaBase();

            if (encabezado) reporte = new EncabezadoInstitucional(reporte);
            if (firma) reporte = new PieConFirma(reporte, string.IsNullOrWhiteSpace(firmante) ? "Responsable de auditoría" : firmante);
            if (observaciones)
                reporte = new NotasAlMargen(reporte)
                    .AgregarObservacion("Revisión de accesos y eventos del período.")
                    .AgregarObservacion("Sin hallazgos críticos al momento de la emisión.");
            if (confidencial) reporte = new MarcaConfidencial(reporte);

            Logger.Instancia.Auditoria($"Reporte de auditoría decorado generado ({reporte.Descripcion()})");
            return reporte;
        }
    }
}
