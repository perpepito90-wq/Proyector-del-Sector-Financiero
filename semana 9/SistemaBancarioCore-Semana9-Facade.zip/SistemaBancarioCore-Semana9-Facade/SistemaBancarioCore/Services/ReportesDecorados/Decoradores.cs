using System.Text;

namespace SistemaBancarioCore.Services.ReportesDecorados
{
    /// <summary>
    /// DECORADOR (abstracto). Mantiene una referencia al reporte que decora y
    /// delega en él. Los decoradores concretos añaden su elemento (membrete,
    /// firma, marca, observaciones) antes o después de delegar, y se pueden anidar.
    /// </summary>
    public abstract class ReporteDecorator : IReporteAuditoria
    {
        protected readonly IReporteAuditoria Reporte;

        protected ReporteDecorator(IReporteAuditoria reporte)
        {
            Reporte = reporte;
        }

        public virtual string Generar() => Reporte.Generar();
        public virtual string Descripcion() => Reporte.Descripcion();
    }

    /// <summary>DECORADOR CONCRETO 1: encabezado institucional (membrete).</summary>
    public class EncabezadoInstitucional : ReporteDecorator
    {
        private const string MEMBRETE =
            "============================================================\n" +
            "              SISTEMA BANCARIO CORE\n" +
            "         Unidad de Auditoría y Cumplimiento\n" +
            "============================================================\n\n";

        public EncabezadoInstitucional(IReporteAuditoria reporte) : base(reporte) { }

        public override string Generar() => MEMBRETE + Reporte.Generar();
        public override string Descripcion() => Reporte.Descripcion() + " + encabezado institucional";
    }

    /// <summary>DECORADOR CONCRETO 2: pie con firma del responsable.</summary>
    public class PieConFirma : ReporteDecorator
    {
        private readonly string _firmante;

        public PieConFirma(IReporteAuditoria reporte, string firmante) : base(reporte)
        {
            _firmante = firmante;
        }

        public override string Generar()
        {
            StringBuilder sb = new StringBuilder(Reporte.Generar());
            sb.AppendLine();
            sb.AppendLine("____________________________________________");
            sb.AppendLine($"Firma autorizada: {_firmante}");
            sb.AppendLine($"Fecha de firma: {DateTime.Now:yyyy-MM-dd}");
            return sb.ToString();
        }

        public override string Descripcion() => Reporte.Descripcion() + $" + firma de {_firmante}";
    }

    /// <summary>DECORADOR CONCRETO 3: marca de confidencialidad en cada línea.</summary>
    public class MarcaConfidencial : ReporteDecorator
    {
        private readonly string _texto;

        public MarcaConfidencial(IReporteAuditoria reporte, string texto = "CONFIDENCIAL") : base(reporte)
        {
            _texto = texto;
        }

        public override string Generar()
        {
            string contenido = Reporte.Generar();
            // Inserta la marca al inicio de cada línea (simulación de marca de agua).
            var lineas = contenido.Split('\n').Select(l => $"[{_texto}] {l}");
            return string.Join("\n", lineas);
        }

        public override string Descripcion() => Reporte.Descripcion() + $" + marca '{_texto}'";
    }

    /// <summary>DECORADOR CONCRETO 4: observaciones al final del reporte.</summary>
    public class NotasAlMargen : ReporteDecorator
    {
        private readonly List<string> _observaciones = new List<string>();

        public NotasAlMargen(IReporteAuditoria reporte) : base(reporte) { }

        public NotasAlMargen AgregarObservacion(string obs)
        {
            _observaciones.Add(obs);
            return this;
        }

        public override string Generar()
        {
            StringBuilder sb = new StringBuilder(Reporte.Generar());
            sb.AppendLine();
            sb.AppendLine("--- OBSERVACIONES ---");
            if (_observaciones.Count == 0)
                sb.AppendLine("(sin observaciones)");
            else
                foreach (var o in _observaciones) sb.AppendLine("• " + o);
            return sb.ToString();
        }

        public override string Descripcion() => Reporte.Descripcion() + $" + {_observaciones.Count} observaciones";
    }
}
