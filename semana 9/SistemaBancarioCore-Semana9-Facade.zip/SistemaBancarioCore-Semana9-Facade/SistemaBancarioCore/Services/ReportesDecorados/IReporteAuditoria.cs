using System.Text;
using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.ReportesDecorados
{
    /// <summary>
    /// COMPONENTE (Decorator). Define la operación que los decoradores pueden
    /// envolver: generar el contenido del reporte y describir qué contiene.
    /// </summary>
    public interface IReporteAuditoria
    {
        string Generar();
        string Descripcion();
    }

    /// <summary>
    /// COMPONENTE CONCRETO. Reporte base de auditoría: el contenido mínimo
    /// (los eventos registrados en la bitácora), sin membrete ni firma todavía.
    /// Reutiliza el Logger (Singleton) como fuente de datos.
    /// </summary>
    public class ReporteAuditoriaBase : IReporteAuditoria
    {
        private readonly int _maxEventos;

        public ReporteAuditoriaBase(int maxEventos = 15)
        {
            _maxEventos = maxEventos;
        }

        public string Generar()
        {
            var eventos = Logger.Instancia.LeerEventos().TakeLast(_maxEventos).ToList();

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("REPORTE DE AUDITORÍA");
            sb.AppendLine($"Generado: {DateTime.Now:yyyy-MM-dd HH:mm}");
            sb.AppendLine($"Total de eventos mostrados: {eventos.Count}");
            sb.AppendLine(new string('-', 60));
            if (eventos.Count == 0)
                sb.AppendLine("(sin eventos registrados)");
            else
                foreach (var e in eventos) sb.AppendLine(e);
            return sb.ToString();
        }

        public string Descripcion() => "Reporte base de auditoría";
    }
}
