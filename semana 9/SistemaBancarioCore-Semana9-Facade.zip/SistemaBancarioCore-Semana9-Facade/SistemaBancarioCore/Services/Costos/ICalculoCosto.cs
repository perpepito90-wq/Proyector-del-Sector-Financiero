using System.Globalization;

namespace SistemaBancarioCore.Services.Costos
{
    /// <summary>
    /// COMPONENTE (Decorator). Define la operación que los decoradores pueden
    /// envolver: calcular el costo total y describir su desglose.
    /// </summary>
    public interface ICalculoCosto
    {
        decimal Calcular();
        string Detalle();
    }

    /// <summary>
    /// COMPONENTE CONCRETO. El costo base (por ejemplo, el monto del préstamo),
    /// sin cargos todavía. Es el objeto al que los decoradores añaden cargos.
    /// </summary>
    public class CostoBase : ICalculoCosto
    {
        private readonly decimal _montoBase;

        public CostoBase(decimal montoBase)
        {
            _montoBase = montoBase;
        }

        public decimal Calcular() => _montoBase;

        public string Detalle() => $"Monto base: {Moneda.F(_montoBase)}";
    }

    internal static class Moneda
    {
        private static readonly CultureInfo CO = new CultureInfo("es-CO");
        public static string F(decimal valor) => valor.ToString("C0", CO);
    }
}
