namespace SistemaBancarioCore.Services.Costos
{
    /// <summary>
    /// DECORADOR (abstracto). Mantiene una referencia a un ICalculoCosto y delega
    /// en él. Los decoradores concretos heredan de aquí y añaden su cargo antes o
    /// después de delegar, por lo que se pueden combinar envolviendo unos a otros.
    /// </summary>
    public abstract class CargoDecorator : ICalculoCosto
    {
        protected readonly ICalculoCosto Componente;

        protected CargoDecorator(ICalculoCosto componente)
        {
            Componente = componente;
        }

        public virtual decimal Calcular() => Componente.Calcular();
        public virtual string Detalle() => Componente.Detalle();
    }

    /// <summary>DECORADOR CONCRETO: comisión de apertura (+2%).</summary>
    public class ComisionApertura : CargoDecorator
    {
        private const decimal PCT = 0.02m;
        public ComisionApertura(ICalculoCosto c) : base(c) { }
        public override decimal Calcular() => Componente.Calcular() * (1 + PCT);
        public override string Detalle() =>
            Componente.Detalle() + $"\n+ Comisión de apertura (2%): {Moneda.F(Componente.Calcular() * PCT)}";
    }

    /// <summary>DECORADOR CONCRETO: seguro de vida (monto fijo).</summary>
    public class SeguroVida : CargoDecorator
    {
        private const decimal MONTO = 15000m;
        public SeguroVida(ICalculoCosto c) : base(c) { }
        public override decimal Calcular() => Componente.Calcular() + MONTO;
        public override string Detalle() =>
            Componente.Detalle() + $"\n+ Seguro de vida: {Moneda.F(MONTO)}";
    }

    /// <summary>DECORADOR CONCRETO: recargo por plazo extendido (+5%).</summary>
    public class RecargoPlazo : CargoDecorator
    {
        private const decimal PCT = 0.05m;
        public RecargoPlazo(ICalculoCosto c) : base(c) { }
        public override decimal Calcular() => Componente.Calcular() * (1 + PCT);
        public override string Detalle() =>
            Componente.Detalle() + $"\n+ Recargo por plazo extendido (5%): {Moneda.F(Componente.Calcular() * PCT)}";
    }

    /// <summary>DECORADOR CONCRETO: descuento para cliente preferente (-10%).</summary>
    public class DescuentoPreferente : CargoDecorator
    {
        private const decimal PCT = 0.10m;
        public DescuentoPreferente(ICalculoCosto c) : base(c) { }
        public override decimal Calcular() => Componente.Calcular() * (1 - PCT);
        public override string Detalle() =>
            Componente.Detalle() + $"\n- Descuento cliente preferente (10%): {Moneda.F(Componente.Calcular() * PCT)}";
    }
}
