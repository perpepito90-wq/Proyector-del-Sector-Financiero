namespace SistemaBancarioCore.Services.Costos
{
    /// <summary>
    /// CLIENTE del Decorator. Arma dinámicamente la cadena de cargos según lo que
    /// el usuario elija, envolviendo el costo base con los decoradores necesarios.
    /// El orden importa: primero se aplican los cargos y al final el descuento.
    /// </summary>
    public class ServicioCostos
    {
        public ICalculoCosto Construir(decimal montoBase, bool comision, bool seguro, bool recargo, bool descuento)
        {
            ICalculoCosto costo = new CostoBase(montoBase);

            if (comision) costo = new ComisionApertura(costo);
            if (seguro) costo = new SeguroVida(costo);
            if (recargo) costo = new RecargoPlazo(costo);
            if (descuento) costo = new DescuentoPreferente(costo);

            return costo;
        }
    }
}
