using System.Text;

namespace SistemaBancarioCore.Services.Estructura
{
    /// <summary>
    /// COMPOSITE. Un grupo de la estructura (una sucursal, una región o el banco
    /// completo). Contiene hijos, que pueden ser cuentas (hojas) u otros grupos
    /// (composites). Las operaciones se resuelven delegando recursivamente en los
    /// hijos, de modo que el cliente no necesita saber de cuántos niveles se trata.
    /// </summary>
    public class GrupoFinanciero : IComponenteFinanciero
    {
        private readonly List<IComponenteFinanciero> _hijos = new List<IComponenteFinanciero>();

        public string Nombre { get; }

        public GrupoFinanciero(string nombre)
        {
            Nombre = nombre;
        }

        public void Agregar(IComponenteFinanciero componente) => _hijos.Add(componente);
        public void Quitar(IComponenteFinanciero componente) => _hijos.Remove(componente);
        public IEnumerable<IComponenteFinanciero> Hijos => _hijos;

        public decimal SaldoTotal() => _hijos.Sum(h => h.SaldoTotal());

        public int ContarCuentas() => _hijos.Sum(h => h.ContarCuentas());

        public string Mostrar(string indentacion)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"{indentacion}+ {Nombre}  ({Moneda.F(SaldoTotal())} · {ContarCuentas()} cuentas)\n");
            foreach (var h in _hijos)
                sb.Append(h.Mostrar(indentacion + "   "));
            return sb.ToString();
        }
    }
}
