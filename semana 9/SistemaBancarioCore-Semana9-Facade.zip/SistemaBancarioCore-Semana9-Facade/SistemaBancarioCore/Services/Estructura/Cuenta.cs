namespace SistemaBancarioCore.Services.Estructura
{
    /// <summary>
    /// HOJA (Composite). Una cuenta individual: no tiene hijos. Es el caso base de
    /// las operaciones recursivas (su saldo es él mismo y cuenta como una cuenta).
    /// </summary>
    public class Cuenta : IComponenteFinanciero
    {
        private readonly decimal _saldo;

        public string Nombre { get; }

        public Cuenta(string nombre, decimal saldo)
        {
            Nombre = nombre;
            _saldo = saldo;
        }

        public decimal SaldoTotal() => _saldo;

        public int ContarCuentas() => 1;

        public string Mostrar(string indentacion) =>
            $"{indentacion}- Cuenta: {Nombre} ({Moneda.F(_saldo)})\n";
    }
}
