namespace SistemaBancarioCore.Services.Estructura
{
    /// <summary>
    /// CLIENTE del Composite. Arma una estructura de ejemplo del banco
    /// (Banco → Sucursales → Cuentas) y permite consultar cualquier nodo. Gracias
    /// al Composite, el saldo y el número de cuentas se calculan igual para una
    /// cuenta, una sucursal o el banco entero.
    /// </summary>
    public class ServicioEstructura
    {
        public GrupoFinanciero ConstruirBanco()
        {
            GrupoFinanciero banco = new GrupoFinanciero("Banco Nacional");

            GrupoFinanciero centro = new GrupoFinanciero("Sucursal Centro");
            centro.Agregar(new Cuenta("Ahorros - Ana", 2_000_000m));
            centro.Agregar(new Cuenta("Corriente - Luis", 5_500_000m));

            GrupoFinanciero norte = new GrupoFinanciero("Sucursal Norte");
            norte.Agregar(new Cuenta("Ahorros - Pedro", 1_200_000m));
            norte.Agregar(new Cuenta("Corriente - Carla", 8_000_000m));
            norte.Agregar(new Cuenta("Ahorros - Marta", 3_300_000m));

            banco.Agregar(centro);
            banco.Agregar(norte);
            return banco;
        }

        /// <summary>Busca un nodo por nombre dentro del árbol (o devuelve la raíz).</summary>
        public IComponenteFinanciero Buscar(GrupoFinanciero raiz, string? nombre)
        {
            if (string.IsNullOrWhiteSpace(nombre) || raiz.Nombre == nombre) return raiz;
            foreach (var h in raiz.Hijos)
            {
                if (h.Nombre == nombre) return h;
                if (h is GrupoFinanciero g)
                {
                    var r = Buscar(g, nombre);
                    if (r.Nombre == nombre) return r;
                }
            }
            return raiz;
        }
    }
}
