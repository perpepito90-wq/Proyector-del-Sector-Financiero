using System.Globalization;

namespace SistemaBancarioCore.Services.Estructura
{
    /// <summary>
    /// COMPONENTE (Composite). Interfaz común para los elementos individuales
    /// (cuentas) y las composiciones (grupos: sucursales, el banco). El cliente
    /// las trata de la misma forma, sin distinguir hojas de ramas.
    /// </summary>
    public interface IComponenteFinanciero
    {
        string Nombre { get; }
        decimal SaldoTotal();
        int ContarCuentas();
        string Mostrar(string indentacion);
    }

    /// <summary>Formato de moneda en pesos colombianos para la salida.</summary>
    internal static class Moneda
    {
        private static readonly CultureInfo CO = new CultureInfo("es-CO");
        public static string F(decimal valor) => valor.ToString("C0", CO);
    }
}
