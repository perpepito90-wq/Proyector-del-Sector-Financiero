using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services;
using SistemaBancarioCore.Services.Estructura;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Página de la estructura organizacional del banco. Demuestra el patrón
    /// Composite: el saldo total y el número de cuentas se calculan de la misma
    /// forma para una cuenta, una sucursal o el banco completo.
    /// </summary>
    [Authorize]
    public class EstructuraController : Controller
    {
        private readonly ServicioEstructura _servicio = new ServicioEstructura();

        public IActionResult Index(string? nodo)
        {
            GrupoFinanciero banco = _servicio.ConstruirBanco();
            IComponenteFinanciero seleccionado = _servicio.Buscar(banco, nodo);

            Logger.Instancia.Info($"Consulta de estructura: {seleccionado.Nombre} (saldo {seleccionado.SaldoTotal()})");

            ViewData["arbol"] = banco.Mostrar("");
            ViewData["nombreSel"] = seleccionado.Nombre;
            ViewData["saldoSel"] = Moneda.F(seleccionado.SaldoTotal());
            ViewData["cuentasSel"] = seleccionado.ContarCuentas();
            ViewData["nodoSel"] = seleccionado.Nombre;
            return View();
        }
    }
}
