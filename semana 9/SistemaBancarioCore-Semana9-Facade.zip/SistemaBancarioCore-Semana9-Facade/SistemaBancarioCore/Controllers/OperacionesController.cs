using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Operaciones;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Centro de operaciones seguras. Demuestra el patrón Facade: el controlador
    /// (cliente) solo conoce el <see cref="CentroOperacionesFacade"/> y llama a un
    /// único método; la fachada coordina por dentro los subsistemas de
    /// cumplimiento (KYC/AML), detección de fraude, límites, autorización,
    /// auditoría y notificación.
    /// </summary>
    [Authorize]
    public class OperacionesController : Controller
    {
        private readonly CentroOperacionesFacade _facade = new CentroOperacionesFacade();

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Evaluar(string cliente, string tipoOperacion, decimal monto,
                                     string paisDestino, string canal)
        {
            var solicitud = new SolicitudOperacion
            {
                Cliente = cliente ?? string.Empty,
                TipoOperacion = string.IsNullOrWhiteSpace(tipoOperacion) ? "transferencia" : tipoOperacion,
                Monto = monto,
                PaisDestino = string.IsNullOrWhiteSpace(paisDestino) ? "Colombia" : paisDestino,
                Canal = string.IsNullOrWhiteSpace(canal) ? "web" : canal
            };

            ResultadoOperacion resultado = _facade.EvaluarOperacion(solicitud);

            ViewData["resultado"] = resultado;
            ViewData["solicitud"] = solicitud;
            return View("Index");
        }
    }
}
