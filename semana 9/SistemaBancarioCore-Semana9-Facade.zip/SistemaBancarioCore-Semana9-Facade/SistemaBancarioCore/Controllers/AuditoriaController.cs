using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.ReportesDecorados;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Página para emitir el reporte oficial de auditoría. Demuestra el patrón
    /// Decorator: sobre un reporte base se añaden elementos combinables (membrete,
    /// firma, marca de confidencialidad y observaciones) envolviendo el objeto,
    /// sin crear una clase por cada combinación.
    /// </summary>
    [Authorize]
    public class AuditoriaController : Controller
    {
        private readonly ServicioReporteDecorado _servicio = new ServicioReporteDecorado();

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Generar(bool encabezado, bool firma, string firmante,
                                     bool confidencial, bool observaciones)
        {
            IReporteAuditoria reporte = _servicio.Construir(encabezado, firma, firmante, confidencial, observaciones);

            ViewData["contenido"] = reporte.Generar();
            ViewData["descripcion"] = reporte.Descripcion();
            return View("Index");
        }
    }
}
