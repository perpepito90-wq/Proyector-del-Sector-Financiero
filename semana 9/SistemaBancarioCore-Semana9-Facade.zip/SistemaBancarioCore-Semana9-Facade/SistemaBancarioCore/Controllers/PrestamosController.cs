using System.Globalization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services;
using SistemaBancarioCore.Services.Costos;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Simulador de costo de un préstamo. Demuestra el patrón Decorator: sobre un
    /// costo base se añaden cargos combinables (comisión, seguro, recargo) y un
    /// descuento, envolviendo el objeto dinámicamente sin crear una clase por
    /// cada combinación.
    /// </summary>
    [Authorize]
    public class PrestamosController : Controller
    {
        private readonly ServicioCostos _servicio = new ServicioCostos();

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Calcular(string monto, bool comision, bool seguro, bool recargo, bool descuento)
        {
            if (!decimal.TryParse(monto, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal baseM) || baseM <= 0)
            {
                TempData["Error"] = "Ingresa un monto válido mayor que cero.";
                return RedirectToAction("Index");
            }

            ICalculoCosto costo = _servicio.Construir(baseM, comision, seguro, recargo, descuento);

            Logger.Instancia.Auditoria($"Simulación de costo de préstamo: base {baseM}, total {costo.Calcular()}");

            TempData["detalle"] = costo.Detalle();
            TempData["total"] = Moneda.F(costo.Calcular());
            return RedirectToAction("Index");
        }
    }
}
