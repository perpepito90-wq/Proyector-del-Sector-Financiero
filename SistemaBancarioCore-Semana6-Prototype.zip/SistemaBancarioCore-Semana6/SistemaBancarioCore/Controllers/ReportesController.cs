using System.Globalization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Reportes;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Pagina para generar reportes de auditoria. Demuestra el patron Builder:
    /// el reporte se arma por partes segun el tipo y los filtros elegidos.
    /// </summary>
    [Authorize]
    public class ReportesController : Controller
    {
        private readonly ServicioReportes _servicio = new ServicioReportes();

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Generar(string tipo, string? desde, string? hasta, string? usuario)
        {
            DateTime? fDesde = ParseFecha(desde, false);
            DateTime? fHasta = ParseFecha(hasta, true);

            // Se genera el reporte a partir de una plantilla (Prototype) y se
            // exporta a Excel para descargar.
            ReporteAuditoria reporte = _servicio.GenerarDesdePlantilla(tipo ?? "completo", fDesde, fHasta, usuario);
            byte[] excel = new ExportadorReporteExcel().Exportar(reporte);

            string nombre = $"reporte-auditoria-{DateTime.Now:yyyyMMdd-HHmm}.xlsx";
            return File(excel,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                nombre);
        }

        // Convierte una fecha "yyyy-MM-dd" del selector. Para "hasta" toma el final del dia.
        private static DateTime? ParseFecha(string? valor, bool finDelDia)
        {
            if (string.IsNullOrWhiteSpace(valor)) return null;
            if (DateTime.TryParse(valor, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime f))
                return finDelDia ? f.Date.AddDays(1).AddSeconds(-1) : f.Date;
            return null;
        }
    }
}
