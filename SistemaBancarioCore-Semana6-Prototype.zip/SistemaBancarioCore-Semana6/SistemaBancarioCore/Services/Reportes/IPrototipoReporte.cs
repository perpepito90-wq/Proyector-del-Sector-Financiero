namespace SistemaBancarioCore.Services.Reportes
{
    /// <summary>
    /// PROTOTIPO (Prototype). Contrato para clonar un reporte ya configurado.
    /// Permite crear reportes nuevos copiando una plantilla en lugar de armarlos
    /// desde cero cada vez.
    /// </summary>
    public interface IPrototipoReporte
    {
        /// <summary>Devuelve una copia independiente (clon) de este reporte.</summary>
        ReporteAuditoria Clonar();
    }
}
