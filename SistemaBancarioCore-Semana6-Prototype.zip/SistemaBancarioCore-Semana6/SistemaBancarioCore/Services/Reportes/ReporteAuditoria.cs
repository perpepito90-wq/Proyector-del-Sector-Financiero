using System.Text;

namespace SistemaBancarioCore.Services.Reportes
{
    /// <summary>
    /// PRODUCTO (Builder) y PROTOTIPO (Prototype). Objeto complejo que se arma por
    /// partes (encabezado, periodo, filtro, resumen, lista de eventos y nota legal)
    /// y que ademas puede clonarse para reutilizar plantillas ya configuradas.
    /// </summary>
    public class ReporteAuditoria : IPrototipoReporte
    {
        public string Titulo { get; set; } = "Reporte de auditoría";
        public string Entidad { get; set; } = "Sistema Bancario Core";
        public DateTime FechaGeneracion { get; set; } = DateTime.Now;

        public DateTime? PeriodoDesde { get; set; }
        public DateTime? PeriodoHasta { get; set; }
        public string? FiltroUsuario { get; set; }

        public List<EventoAuditoria> Eventos { get; } = new List<EventoAuditoria>();

        public bool IncluirResumen { get; set; }
        public string? NotaLegal { get; set; }

        /// <summary>Compone el texto final del reporte con las partes presentes.</summary>
        public string Render()
        {
            const int ancho = 64;
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(new string('=', ancho));
            sb.AppendLine(Entidad.ToUpper());
            sb.AppendLine(Titulo);
            sb.AppendLine($"Generado: {FechaGeneracion:yyyy-MM-dd HH:mm}");
            if (PeriodoDesde.HasValue && PeriodoHasta.HasValue)
                sb.AppendLine($"Período: {PeriodoDesde:yyyy-MM-dd} a {PeriodoHasta:yyyy-MM-dd}");
            if (!string.IsNullOrWhiteSpace(FiltroUsuario))
                sb.AppendLine($"Filtro por usuario: {FiltroUsuario}");
            sb.AppendLine(new string('=', ancho));

            if (IncluirResumen)
            {
                sb.AppendLine("RESUMEN");
                sb.AppendLine($"  Total de eventos: {Eventos.Count}");
                foreach (var grupo in Eventos.GroupBy(e => e.Nivel).OrderBy(g => g.Key))
                    sb.AppendLine($"  {grupo.Key}: {grupo.Count()}");
                sb.AppendLine(new string('-', ancho));
            }

            sb.AppendLine("EVENTOS");
            if (Eventos.Count == 0)
            {
                sb.AppendLine("  (sin eventos para los criterios indicados)");
            }
            else
            {
                foreach (var e in Eventos)
                    sb.AppendLine($"  {e.Fecha:yyyy-MM-dd HH:mm:ss} [{e.Nivel}] {e.Mensaje}");
            }

            if (!string.IsNullOrWhiteSpace(NotaLegal))
            {
                sb.AppendLine(new string('-', ancho));
                sb.AppendLine(NotaLegal);
            }

            sb.AppendLine(new string('=', ancho));
            return sb.ToString();
        }

        /// <summary>
        /// PROTOTYPE: devuelve una copia independiente de este reporte. Copia todas
        /// las partes fijas y crea una NUEVA lista de eventos (copia profunda), de
        /// modo que modificar el clon no afecta a la plantilla original.
        /// </summary>
        public ReporteAuditoria Clonar()
        {
            ReporteAuditoria copia = new ReporteAuditoria
            {
                Titulo = this.Titulo,
                Entidad = this.Entidad,
                FechaGeneracion = DateTime.Now,   // el clon se genera ahora
                PeriodoDesde = this.PeriodoDesde,
                PeriodoHasta = this.PeriodoHasta,
                FiltroUsuario = this.FiltroUsuario,
                IncluirResumen = this.IncluirResumen,
                NotaLegal = this.NotaLegal,
            };

            // Copia profunda de la lista de eventos: el clon tiene su propia lista.
            foreach (var e in this.Eventos)
                copia.Eventos.Add(new EventoAuditoria { Fecha = e.Fecha, Nivel = e.Nivel, Mensaje = e.Mensaje });

            return copia;
        }
    }
}
