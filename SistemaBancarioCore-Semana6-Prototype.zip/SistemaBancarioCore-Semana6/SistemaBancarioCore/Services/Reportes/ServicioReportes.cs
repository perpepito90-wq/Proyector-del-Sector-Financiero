using SistemaBancarioCore.Services;

namespace SistemaBancarioCore.Services.Reportes
{
    /// <summary>
    /// CLIENTE del Builder. Obtiene los eventos de la bitacora (Logger Singleton),
    /// aplica los filtros y usa el Director + el Builder para construir el reporte.
    /// El resto del sistema no necesita conocer como se arma el reporte.
    /// </summary>
    public class ServicioReportes
    {
        public ReporteAuditoria ConstruirReporte(string tipo, DateTime? desde, DateTime? hasta, string? usuario)
        {
            // 1) Leer y parsear los eventos de la bitacora (reutiliza el Singleton).
            IEnumerable<EventoAuditoria> eventos = Logger.Instancia.LeerEventos()
                .Select(EventoAuditoria.Parse)
                .Where(e => e != null)
                .Select(e => e!);

            // 2) Aplicar filtros (logica de negocio, separada de la construccion).
            if (desde.HasValue) eventos = eventos.Where(e => e.Fecha >= desde.Value);
            if (hasta.HasValue) eventos = eventos.Where(e => e.Fecha <= hasta.Value);
            if (!string.IsNullOrWhiteSpace(usuario))
                eventos = eventos.Where(e => e.Mensaje.Contains(usuario, StringComparison.OrdinalIgnoreCase));

            List<EventoAuditoria> lista = eventos.OrderBy(e => e.Fecha).ToList();

            // 3) Construir el reporte con el Director y el Builder.
            ReporteAuditoriaBuilder builder = new ReporteAuditoriaBuilder();
            DirectorReportes director = new DirectorReportes();

            ReporteAuditoria reporte = (tipo == "completo")
                ? director.ReporteCompleto(builder, lista, desde, hasta, usuario)
                : director.ReporteRapido(builder, lista);

            // 4) Dejar constancia en la bitacora y devolver el reporte construido.
            Logger.Instancia.Auditoria($"Reporte de auditoria generado (tipo={tipo}, eventos={lista.Count})");

            return reporte;
        }

        /// <summary>
        /// Genera un reporte a partir de una PLANTILLA (Prototype): clona la plantilla
        /// ya configurada y solo rellena las partes variables (eventos y período).
        /// </summary>
        public ReporteAuditoria GenerarDesdePlantilla(string plantilla, DateTime? desde, DateTime? hasta, string? usuario)
        {
            // 1) Clonar la plantilla elegida (Prototype). El clon trae ya el título,
            //    la entidad, el resumen y la nota legal configurados.
            ReporteAuditoria reporte = RegistroPlantillasReporte.Instancia.ObtenerClon(plantilla);

            // 2) Leer y filtrar los eventos de la bitácora (reutiliza el Singleton).
            IEnumerable<EventoAuditoria> eventos = Logger.Instancia.LeerEventos()
                .Select(EventoAuditoria.Parse)
                .Where(e => e != null)
                .Select(e => e!);

            if (desde.HasValue) eventos = eventos.Where(e => e.Fecha >= desde.Value);
            if (hasta.HasValue) eventos = eventos.Where(e => e.Fecha <= hasta.Value);
            if (!string.IsNullOrWhiteSpace(usuario))
                eventos = eventos.Where(e => e.Mensaje.Contains(usuario, StringComparison.OrdinalIgnoreCase));

            List<EventoAuditoria> lista = eventos.OrderBy(e => e.Fecha).ToList();

            // 3) Rellenar el clon con los datos variables (no toca la plantilla original).
            reporte.Eventos.AddRange(lista);
            if (desde.HasValue && hasta.HasValue) { reporte.PeriodoDesde = desde; reporte.PeriodoHasta = hasta; }
            if (!string.IsNullOrWhiteSpace(usuario)) reporte.FiltroUsuario = usuario;

            Logger.Instancia.Auditoria($"Reporte generado desde plantilla '{plantilla}' (eventos={lista.Count})");

            return reporte;
        }
    }
}
