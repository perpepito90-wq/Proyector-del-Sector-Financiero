namespace SistemaBancarioCore.Services.Reportes
{
    /// <summary>
    /// REGISTRO DE PROTOTIPOS (Prototype). Guarda plantillas de reporte ya
    /// configuradas y entrega un CLON cada vez que se pide una. Las plantillas se
    /// construyen una sola vez (aquí, con el Builder y el Director) y luego se
    /// clonan, en lugar de armarlas de nuevo en cada generación.
    ///
    /// Es un Singleton para que exista un único catálogo de plantillas en toda la
    /// aplicación.
    /// </summary>
    public sealed class RegistroPlantillasReporte
    {
        private static readonly Lazy<RegistroPlantillasReporte> _instancia =
            new Lazy<RegistroPlantillasReporte>(() => new RegistroPlantillasReporte());

        public static RegistroPlantillasReporte Instancia => _instancia.Value;

        private readonly Dictionary<string, ReporteAuditoria> _plantillas =
            new Dictionary<string, ReporteAuditoria>();

        private RegistroPlantillasReporte()
        {
            DirectorReportes director = new DirectorReportes();

            // Plantilla "Completo": armada con el Director (resumen + nota legal).
            // Se crea sin eventos ni período; esos datos se rellenan al clonar.
            _plantillas["completo"] = director.ReporteCompleto(
                new ReporteAuditoriaBuilder(), new List<EventoAuditoria>(), null, null, null);

            // Plantilla "Diario": armada con el Builder.
            _plantillas["diario"] = new ReporteAuditoriaBuilder()
                .ConTitulo("Reporte diario de auditoría")
                .ConEntidad("Sistema Bancario Core")
                .IncluirResumen()
                .ConNotaLegal("Documento generado automáticamente para fines de auditoría y cumplimiento (KYC / AML).")
                .Construir();

            // Plantilla "Seguridad": orientada a accesos y eventos de seguridad.
            _plantillas["seguridad"] = new ReporteAuditoriaBuilder()
                .ConTitulo("Reporte de seguridad de accesos")
                .ConEntidad("Sistema Bancario Core")
                .IncluirResumen()
                .ConNotaLegal("Reporte orientado a los eventos de acceso y seguridad del sistema.")
                .Construir();
        }

        /// <summary>Devuelve un CLON de la plantilla indicada (o de la completa por defecto).</summary>
        public ReporteAuditoria ObtenerClon(string nombre)
        {
            string clave = (nombre ?? string.Empty).Trim().ToLower();
            if (!_plantillas.TryGetValue(clave, out ReporteAuditoria? prototipo))
                prototipo = _plantillas["completo"];

            return prototipo.Clonar();
        }

        public IEnumerable<string> NombresPlantillas() => _plantillas.Keys;
    }
}
