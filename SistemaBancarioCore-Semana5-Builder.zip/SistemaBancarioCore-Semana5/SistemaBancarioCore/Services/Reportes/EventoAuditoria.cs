using System.Globalization;

namespace SistemaBancarioCore.Services.Reportes
{
    /// <summary>
    /// Representa un evento leido de la bitacora. Sirve para filtrar por fecha o
    /// nivel y para construir el reporte de auditoria.
    /// </summary>
    public class EventoAuditoria
    {
        public DateTime Fecha { get; set; }
        public string Nivel { get; set; } = "INFO";
        public string Mensaje { get; set; } = string.Empty;

        /// <summary>
        /// Convierte una linea de bitacora con formato
        /// "yyyy-MM-dd HH:mm:ss [NIVEL] mensaje" en un EventoAuditoria.
        /// Devuelve null si la linea no tiene el formato esperado.
        /// </summary>
        public static EventoAuditoria? Parse(string linea)
        {
            if (string.IsNullOrWhiteSpace(linea) || linea.Length < 21)
                return null;

            string fechaStr = linea.Substring(0, 19);
            if (!DateTime.TryParseExact(fechaStr, "yyyy-MM-dd HH:mm:ss",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime fecha))
                return null;

            int ini = linea.IndexOf('[');
            int fin = linea.IndexOf(']');
            string nivel = (ini >= 0 && fin > ini) ? linea.Substring(ini + 1, fin - ini - 1) : "INFO";
            string mensaje = (fin >= 0 && fin + 1 < linea.Length) ? linea.Substring(fin + 1).Trim() : string.Empty;

            return new EventoAuditoria { Fecha = fecha, Nivel = nivel, Mensaje = mensaje };
        }
    }
}
