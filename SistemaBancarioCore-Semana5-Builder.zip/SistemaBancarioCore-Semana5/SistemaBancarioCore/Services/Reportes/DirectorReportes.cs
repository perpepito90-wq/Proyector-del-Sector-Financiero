namespace SistemaBancarioCore.Services.Reportes
{
    /// <summary>
    /// DIRECTOR (Builder). Conoce el "orden de armado" de reportes tipicos y usa
    /// el builder para producirlos. Con el mismo builder se obtienen distintas
    /// representaciones del reporte (rapido o completo) sin repetir la logica de
    /// construccion en el resto del sistema.
    /// </summary>
    public class DirectorReportes
    {
        /// <summary>Reporte breve: solo encabezado y lista de eventos.</summary>
        public ReporteAuditoria ReporteRapido(
            ReporteAuditoriaBuilder builder, IEnumerable<EventoAuditoria> eventos)
        {
            return builder
                .ConTitulo("Reporte rápido de auditoría")
                .ConEntidad("Sistema Bancario Core")
                .ConEventos(eventos)
                .Construir();
        }

        /// <summary>Reporte extenso: encabezado, periodo, filtro, resumen, eventos y nota legal.</summary>
        public ReporteAuditoria ReporteCompleto(
            ReporteAuditoriaBuilder builder, IEnumerable<EventoAuditoria> eventos,
            DateTime? desde, DateTime? hasta, string? usuario)
        {
            builder
                .ConTitulo("Reporte completo de auditoría")
                .ConEntidad("Sistema Bancario Core");

            if (desde.HasValue && hasta.HasValue)
                builder.ConPeriodo(desde.Value, hasta.Value);

            if (!string.IsNullOrWhiteSpace(usuario))
                builder.ConFiltroUsuario(usuario);

            return builder
                .ConEventos(eventos)
                .IncluirResumen()
                .ConNotaLegal("Documento generado automáticamente para fines de auditoría y cumplimiento (KYC / AML).")
                .Construir();
        }
    }
}
