using ClosedXML.Excel;

namespace SistemaBancarioCore.Services.Reportes
{
    /// <summary>
    /// Toma un ReporteAuditoria ya construido (por el Builder) y lo escribe en un
    /// archivo Excel (.xlsx). Devuelve el contenido del archivo en bytes para
    /// poder descargarlo desde el navegador.
    /// </summary>
    public class ExportadorReporteExcel
    {
        public byte[] Exportar(ReporteAuditoria reporte)
        {
            using XLWorkbook libro = new XLWorkbook();
            IXLWorksheet hoja = libro.Worksheets.Add("Auditoría");

            int fila = 1;

            // ----- Encabezado -----
            hoja.Cell(fila, 1).Value = reporte.Entidad;
            hoja.Cell(fila, 1).Style.Font.Bold = true;
            hoja.Cell(fila, 1).Style.Font.FontSize = 14;
            fila++;

            hoja.Cell(fila, 1).Value = reporte.Titulo;
            hoja.Cell(fila, 1).Style.Font.Bold = true;
            fila++;

            hoja.Cell(fila, 1).Value = $"Generado: {reporte.FechaGeneracion:yyyy-MM-dd HH:mm}";
            fila++;

            if (reporte.PeriodoDesde.HasValue && reporte.PeriodoHasta.HasValue)
            {
                hoja.Cell(fila, 1).Value = $"Período: {reporte.PeriodoDesde:yyyy-MM-dd} a {reporte.PeriodoHasta:yyyy-MM-dd}";
                fila++;
            }

            if (!string.IsNullOrWhiteSpace(reporte.FiltroUsuario))
            {
                hoja.Cell(fila, 1).Value = $"Filtro por usuario: {reporte.FiltroUsuario}";
                fila++;
            }

            fila++; // fila en blanco

            // ----- Resumen -----
            if (reporte.IncluirResumen)
            {
                hoja.Cell(fila, 1).Value = "RESUMEN";
                hoja.Cell(fila, 1).Style.Font.Bold = true;
                fila++;

                hoja.Cell(fila, 1).Value = "Total de eventos";
                hoja.Cell(fila, 2).Value = reporte.Eventos.Count;
                fila++;

                foreach (var grupo in reporte.Eventos.GroupBy(e => e.Nivel).OrderBy(g => g.Key))
                {
                    hoja.Cell(fila, 1).Value = grupo.Key;
                    hoja.Cell(fila, 2).Value = grupo.Count();
                    fila++;
                }

                fila++; // fila en blanco
            }

            // ----- Tabla de eventos -----
            hoja.Cell(fila, 1).Value = "Fecha";
            hoja.Cell(fila, 2).Value = "Nivel";
            hoja.Cell(fila, 3).Value = "Mensaje";
            IXLRange encabezado = hoja.Range(fila, 1, fila, 3);
            encabezado.Style.Font.Bold = true;
            encabezado.Style.Font.FontColor = XLColor.White;
            encabezado.Style.Fill.BackgroundColor = XLColor.FromHtml("#0B1F3A");
            fila++;

            if (reporte.Eventos.Count == 0)
            {
                hoja.Cell(fila, 1).Value = "(sin eventos para los criterios indicados)";
                fila++;
            }
            else
            {
                foreach (var e in reporte.Eventos)
                {
                    hoja.Cell(fila, 1).Value = e.Fecha;
                    hoja.Cell(fila, 1).Style.DateFormat.Format = "yyyy-mm-dd hh:mm:ss";
                    hoja.Cell(fila, 2).Value = e.Nivel;
                    hoja.Cell(fila, 3).Value = e.Mensaje;
                    fila++;
                }
            }

            // ----- Nota legal -----
            if (!string.IsNullOrWhiteSpace(reporte.NotaLegal))
            {
                fila++;
                hoja.Cell(fila, 1).Value = reporte.NotaLegal;
                hoja.Cell(fila, 1).Style.Font.Italic = true;
            }

            hoja.Columns().AdjustToContents();
            // Evita que la columna del mensaje quede demasiado ancha.
            if (hoja.Column(3).Width > 90) hoja.Column(3).Width = 90;

            using MemoryStream memoria = new MemoryStream();
            libro.SaveAs(memoria);
            return memoria.ToArray();
        }
    }
}
