namespace SistemaBancarioCore.Services.Reportes
{
    /// <summary>
    /// BUILDER. Construye un ReporteAuditoria paso a paso. Cada metodo agrega una
    /// parte y devuelve el propio builder, de modo que las llamadas se pueden
    /// encadenar (interfaz fluida). Al final, Construir() entrega el objeto listo.
    /// </summary>
    public class ReporteAuditoriaBuilder
    {
        private readonly ReporteAuditoria _reporte = new ReporteAuditoria();

        public ReporteAuditoriaBuilder ConTitulo(string titulo)
        {
            _reporte.Titulo = titulo;
            return this;
        }

        public ReporteAuditoriaBuilder ConEntidad(string entidad)
        {
            _reporte.Entidad = entidad;
            return this;
        }

        public ReporteAuditoriaBuilder ConPeriodo(DateTime desde, DateTime hasta)
        {
            _reporte.PeriodoDesde = desde;
            _reporte.PeriodoHasta = hasta;
            return this;
        }

        public ReporteAuditoriaBuilder ConFiltroUsuario(string usuario)
        {
            _reporte.FiltroUsuario = usuario;
            return this;
        }

        public ReporteAuditoriaBuilder ConEventos(IEnumerable<EventoAuditoria> eventos)
        {
            _reporte.Eventos.AddRange(eventos);
            return this;
        }

        public ReporteAuditoriaBuilder IncluirResumen()
        {
            _reporte.IncluirResumen = true;
            return this;
        }

        public ReporteAuditoriaBuilder ConNotaLegal(string nota)
        {
            _reporte.NotaLegal = nota;
            return this;
        }

        /// <summary>Devuelve el reporte ya construido.</summary>
        public ReporteAuditoria Construir()
        {
            _reporte.FechaGeneracion = DateTime.Now;
            return _reporte;
        }
    }
}
