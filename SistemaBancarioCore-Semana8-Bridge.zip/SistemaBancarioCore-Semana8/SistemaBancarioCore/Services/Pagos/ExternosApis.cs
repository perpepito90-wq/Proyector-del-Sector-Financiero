namespace SistemaBancarioCore.Services.Pagos.Externos
{
    /// <summary>Respuesta propia de la API de PayPal (formato del proveedor).</summary>
    public class RespuestaPayPal
    {
        public string Estado { get; set; } = string.Empty;   // "COMPLETED" / "FAILED"
        public string TransaccionId { get; set; } = string.Empty;
    }

    /// <summary>
    /// ADAPTEE. Representa la API externa de PayPal. Tiene su propia interfaz
    /// (nombres de métodos, tipos y respuesta distintos a los del sistema). En un
    /// caso real vendría en una librería de terceros que no se puede modificar.
    /// </summary>
    public class ApiPayPal
    {
        // Recibe el monto en dólares (double) y el número de factura.
        public RespuestaPayPal Cobrar(double dolares, string factura)
        {
            // Simulación del cobro (en un caso real se llamaría al servicio de PayPal).
            return new RespuestaPayPal
            {
                Estado = "COMPLETED",
                TransaccionId = "PP-" + Guid.NewGuid().ToString("N").Substring(0, 10).ToUpper()
            };
        }
    }

    /// <summary>
    /// ADAPTEE. Servicio externo de transferencias bancarias, con otra interfaz
    /// distinta: recibe la cuenta destino y devuelve un código como texto.
    /// </summary>
    public class ServicioTransferenciaBancaria
    {
        public string RealizarTransferencia(decimal valor, string cuentaDestino)
        {
            // Simulación: devuelve un comprobante de transferencia.
            return "TRF-" + Guid.NewGuid().ToString("N").Substring(0, 10).ToUpper();
        }
    }
}
