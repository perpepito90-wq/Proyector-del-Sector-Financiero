using SistemaBancarioCore.Services.Pagos.Externos;

namespace SistemaBancarioCore.Services.Pagos
{
    /// <summary>
    /// ADAPTADOR. Hace que la API externa de PayPal (ApiPayPal) funcione como una
    /// IPasarelaPago. Traduce la llamada Pagar(...) del sistema a la llamada
    /// Cobrar(...) de PayPal y convierte su respuesta al formato ResultadoPago.
    /// </summary>
    public class AdaptadorPayPal : IPasarelaPago
    {
        private readonly ApiPayPal _paypal;

        public AdaptadorPayPal(ApiPayPal paypal)
        {
            _paypal = paypal;
        }

        public string Nombre => "PayPal";

        public ResultadoPago Pagar(decimal monto, string referencia)
        {
            // Adapta: decimal -> double, y la respuesta de PayPal -> ResultadoPago.
            RespuestaPayPal r = _paypal.Cobrar((double)monto, referencia);

            return new ResultadoPago
            {
                Exito = r.Estado == "COMPLETED",
                Proveedor = Nombre,
                Referencia = r.TransaccionId,
                Detalle = $"Pago procesado por PayPal (estado: {r.Estado})"
            };
        }
    }

    /// <summary>
    /// ADAPTADOR. Hace que el servicio externo de transferencias funcione como una
    /// IPasarelaPago, traduciendo la llamada y su resultado (un código de texto).
    /// </summary>
    public class AdaptadorTransferencia : IPasarelaPago
    {
        private readonly ServicioTransferenciaBancaria _servicio;

        public AdaptadorTransferencia(ServicioTransferenciaBancaria servicio)
        {
            _servicio = servicio;
        }

        public string Nombre => "Transferencia bancaria";

        public ResultadoPago Pagar(decimal monto, string referencia)
        {
            string comprobante = _servicio.RealizarTransferencia(monto, referencia);

            return new ResultadoPago
            {
                Exito = !string.IsNullOrEmpty(comprobante),
                Proveedor = Nombre,
                Referencia = comprobante,
                Detalle = "Transferencia bancaria realizada"
            };
        }
    }
}
