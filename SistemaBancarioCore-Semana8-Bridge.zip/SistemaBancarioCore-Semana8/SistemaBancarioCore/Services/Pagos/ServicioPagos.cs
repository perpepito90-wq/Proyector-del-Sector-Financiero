using SistemaBancarioCore.Services;
using SistemaBancarioCore.Services.Pagos.Externos;

namespace SistemaBancarioCore.Services.Pagos
{
    /// <summary>
    /// CLIENTE del Adapter. Procesa un pago usando siempre la interfaz IPasarelaPago,
    /// sin conocer los detalles de cada proveedor externo. Según el proveedor elegido
    /// crea el adaptador correspondiente.
    /// </summary>
    public class ServicioPagos
    {
        public ResultadoPago ProcesarPago(string proveedor, decimal monto, string referencia)
        {
            IPasarelaPago pasarela = ObtenerPasarela(proveedor);

            Logger.Instancia.Info($"Procesando pago de {monto:C} por {pasarela.Nombre} (ref: {referencia})");

            ResultadoPago resultado = pasarela.Pagar(monto, referencia);

            if (resultado.Exito)
                Logger.Instancia.Auditoria($"Pago exitoso por {resultado.Proveedor}: {resultado.Referencia} (monto {monto:C})");
            else
                Logger.Instancia.Advertencia($"Pago fallido por {resultado.Proveedor} (monto {monto:C})");

            return resultado;
        }

        private static IPasarelaPago ObtenerPasarela(string proveedor)
        {
            return (proveedor ?? string.Empty).Trim().ToLower() switch
            {
                "transferencia" => new AdaptadorTransferencia(new ServicioTransferenciaBancaria()),
                _ => new AdaptadorPayPal(new ApiPayPal()),
            };
        }
    }
}
