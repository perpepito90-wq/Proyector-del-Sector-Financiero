namespace SistemaBancarioCore.Services.Pagos
{
    /// <summary>Resultado unificado de un intento de pago.</summary>
    public class ResultadoPago
    {
        public bool Exito { get; set; }
        public string Proveedor { get; set; } = string.Empty;
        public string Referencia { get; set; } = string.Empty;
        public string Detalle { get; set; } = string.Empty;
    }

    /// <summary>
    /// OBJETIVO (Adapter). Es la interfaz que el sistema espera para cobrar, sin
    /// importar qué proveedor externo se use por debajo. Cada pasarela externa se
    /// integra a través de un adaptador que implementa esta misma interfaz.
    /// </summary>
    public interface IPasarelaPago
    {
        string Nombre { get; }
        ResultadoPago Pagar(decimal monto, string referencia);
    }
}
