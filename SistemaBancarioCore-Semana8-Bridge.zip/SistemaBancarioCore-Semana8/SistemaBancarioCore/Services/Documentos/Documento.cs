using System.Text;

namespace SistemaBancarioCore.Services.Documentos
{
    /// <summary>
    /// ABSTRACCIÓN (Bridge). Un documento del banco. Mantiene una referencia a un
    /// IFormatoDocumento (el "puente"): delega en él la forma de representarse, de
    /// modo que el tipo de documento y el formato de salida varían por separado.
    /// </summary>
    public abstract class Documento
    {
        protected readonly IFormatoDocumento Formato;

        protected Documento(IFormatoDocumento formato)
        {
            Formato = formato;
        }

        public abstract string Generar();
    }

    /// <summary>ABSTRACCIÓN REFINADA: estado de cuenta del cliente.</summary>
    public class EstadoDeCuenta : Documento
    {
        private readonly string _titular;
        private readonly string _periodo;
        private readonly IEnumerable<string> _movimientos;

        public EstadoDeCuenta(IFormatoDocumento formato, string titular, string periodo, IEnumerable<string> movimientos)
            : base(formato)
        {
            _titular = titular;
            _periodo = periodo;
            _movimientos = movimientos;
        }

        public override string Generar()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(Formato.Encabezado("Estado de cuenta", "Sistema Bancario Core"));
            sb.Append(Formato.Parrafo($"Titular: {_titular}"));
            sb.Append(Formato.Parrafo($"Período: {_periodo}"));
            sb.Append(Formato.Parrafo("Actividad reciente:"));
            sb.Append(Formato.Lista(_movimientos));
            return Formato.Envolver(sb.ToString());
        }
    }

    /// <summary>ABSTRACCIÓN REFINADA: certificado bancario.</summary>
    public class CertificadoBancario : Documento
    {
        private readonly string _titular;

        public CertificadoBancario(IFormatoDocumento formato, string titular) : base(formato)
        {
            _titular = titular;
        }

        public override string Generar()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(Formato.Encabezado("Certificado bancario", "Sistema Bancario Core"));
            sb.Append(Formato.Parrafo($"La entidad certifica que {_titular} es cliente registrado del Sistema Bancario Core y se encuentra en estado activo."));
            sb.Append(Formato.Parrafo($"Este documento se expide a solicitud del interesado el {DateTime.Now:yyyy-MM-dd}."));
            return Formato.Envolver(sb.ToString());
        }
    }
}
