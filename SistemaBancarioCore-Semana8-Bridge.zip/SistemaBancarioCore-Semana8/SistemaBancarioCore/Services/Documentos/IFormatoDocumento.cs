using System.Text;

namespace SistemaBancarioCore.Services.Documentos
{
    /// <summary>
    /// IMPLEMENTADOR (Bridge). Define las operaciones de formato que usa un
    /// documento para representarse, sin importar de qué tipo de documento se trate.
    /// Cada formato de salida (texto, HTML...) es una implementación distinta.
    /// </summary>
    public interface IFormatoDocumento
    {
        string Nombre { get; }
        string Encabezado(string titulo, string subtitulo);
        string Parrafo(string texto);
        string Lista(IEnumerable<string> items);
        string Envolver(string cuerpo);
    }

    /// <summary>IMPLEMENTACIÓN CONCRETA: documento en texto plano.</summary>
    public class FormatoTexto : IFormatoDocumento
    {
        public string Nombre => "Texto";
        public string Encabezado(string titulo, string subtitulo) =>
            new string('=', 52) + "\n" + titulo.ToUpper() + "\n" + subtitulo + "\n" + new string('=', 52) + "\n";
        public string Parrafo(string texto) => texto + "\n";
        public string Lista(IEnumerable<string> items) =>
            string.Join("\n", items.Select(i => "  - " + i)) + "\n";
        public string Envolver(string cuerpo) => cuerpo + new string('=', 52) + "\n";
    }

    /// <summary>IMPLEMENTACIÓN CONCRETA: documento en HTML.</summary>
    public class FormatoHtml : IFormatoDocumento
    {
        public string Nombre => "HTML";
        public string Encabezado(string titulo, string subtitulo) =>
            $"<h1>{titulo}</h1>\n<h3>{subtitulo}</h3>\n";
        public string Parrafo(string texto) => $"<p>{texto}</p>\n";
        public string Lista(IEnumerable<string> items)
        {
            StringBuilder sb = new StringBuilder("<ul>\n");
            foreach (var i in items) sb.Append($"  <li>{i}</li>\n");
            sb.Append("</ul>\n");
            return sb.ToString();
        }
        public string Envolver(string cuerpo) => $"<div class=\"documento\">\n{cuerpo}</div>\n";
    }
}
