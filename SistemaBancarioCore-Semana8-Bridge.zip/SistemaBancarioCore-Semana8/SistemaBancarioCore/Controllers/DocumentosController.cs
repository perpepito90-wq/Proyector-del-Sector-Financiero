using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services;
using SistemaBancarioCore.Services.Documentos;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Página para emitir documentos del cliente. Demuestra el patrón Bridge:
    /// el tipo de documento (abstracción) y el formato de salida (implementación)
    /// se combinan libremente en tiempo de ejecución.
    /// </summary>
    [Authorize]
    public class DocumentosController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Generar(string tipo, string formato)
        {
            // Se elige la IMPLEMENTACIÓN (formato) y la ABSTRACCIÓN (tipo) por separado.
            IFormatoDocumento fmt = (formato == "html") ? new FormatoHtml() : new FormatoTexto();
            string titular = User.Identity?.Name ?? "Cliente";

            Documento documento;
            if (tipo == "certificado")
            {
                documento = new CertificadoBancario(fmt, titular);
            }
            else
            {
                var movimientos = Logger.Instancia.LeerEventos().TakeLast(8).ToList();
                if (movimientos.Count == 0) movimientos.Add("(sin actividad registrada)");
                documento = new EstadoDeCuenta(fmt, titular, DateTime.Now.ToString("yyyy-MM"), movimientos);
            }

            string contenido = documento.Generar();
            Logger.Instancia.Auditoria($"Documento generado: {tipo} en formato {fmt.Nombre} para {titular}");

            ViewData["contenido"] = contenido;
            ViewData["formato"] = fmt.Nombre;
            ViewData["tipo"] = tipo;
            return View("Index");
        }
    }
}
