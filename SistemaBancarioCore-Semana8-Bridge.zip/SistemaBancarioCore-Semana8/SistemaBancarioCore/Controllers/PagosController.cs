using System.Globalization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SistemaBancarioCore.Services.Pagos;

namespace SistemaBancarioCore.Controllers
{
    /// <summary>
    /// Página para procesar pagos a través de pasarelas externas. Demuestra el
    /// patrón Adapter: cada proveedor (PayPal, transferencia) tiene su propia API
    /// incompatible, y se usa mediante un adaptador que la unifica bajo IPasarelaPago.
    /// </summary>
    [Authorize]
    public class PagosController : Controller
    {
        private readonly ServicioPagos _servicio = new ServicioPagos();

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Procesar(string proveedor, string monto, string referencia)
        {
            if (!decimal.TryParse(monto, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal valor) || valor <= 0)
            {
                TempData["Error"] = "Ingresa un monto válido mayor que cero.";
                return RedirectToAction("Index");
            }

            ResultadoPago r = _servicio.ProcesarPago(proveedor ?? "paypal", valor, referencia ?? string.Empty);

            TempData["ok"] = r.Exito ? "1" : "0";
            TempData["proveedor"] = r.Proveedor;
            TempData["referencia"] = r.Referencia;
            TempData["detalle"] = r.Detalle;
            TempData["monto"] = valor.ToString("0.00", CultureInfo.InvariantCulture);
            return RedirectToAction("Index");
        }
    }
}
